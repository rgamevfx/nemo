import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

Rectangle {
    id: panelRoot

    property var panel           // { id, type, group }
    property string leafId
    property var workspace
    property var drag            // the DockDrag coordinator

    readonly property string panelId: panel ? panel.id : ""
    readonly property string panelType: panel ? panel.type : "viewer"
    readonly property string panelGroup: panel ? panel.group : "A"

    color: theme.panel
    radius: theme.radius
    border.color: theme.border
    clip: true

    function displayType(t) {
        if (t === "viewer")
            return "Viewer";
        if (t === "nodegraph")
            return "Node graph";
        if (t === "timeline")
            return "Timeline";
        if (t === "parameters")
            return "Parameters";
        if (t === "animation")
            return "Animation";
        if (t === "mediabin")
            return "Media Bin";
        return t;
    }

    ColumnLayout {
        anchors.fill: parent
        anchors.margins: 1
        spacing: 0

        Rectangle {
            id: header
            Layout.fillWidth: true
            Layout.preferredHeight: panelRoot.panelType === "viewer" && panelBody.item && panelBody.item.headerPreferredHeight !== undefined
                                     ? Math.max(panelBody.item.headerPreferredHeight, panelTools.item ? panelTools.item.implicitHeight + 4 : 0)
                                     : 36
            color: theme.header
            objectName: "panelHeader_" + panelRoot.panelId
            // Keep one drag recognizer on the complete header.  DragHandler
            // waits for the platform threshold, so buttons and menus retain
            // ordinary clicks while every blank/title area can dock.
            PanelDragHandler {
                id: headerDragHandler
                panelId: panelRoot.panelId
                leafId: panelRoot.leafId
                panelType: panelRoot.panelType
                drag: panelRoot.drag
            }
            RowLayout {
                anchors.fill: parent
                anchors.margins: 2
                spacing: 2

                Button {
                    id: typeButton
                    flat: true
                    padding: 6
                    implicitWidth: contentItem.implicitWidth + 16
                    implicitHeight: 24
                    font.pixelSize: 12
                    text: panelRoot.displayType(panelRoot.panelType)
                    background: Rectangle {
                        radius: theme.smallRadius
                        color: typeButton.hovered ? theme.hover : "transparent"
                    }
                    onClicked: typeMenu.open()
                    Accessible.name: "Panel type. Opens the panel menu."
                    objectName: "panelType_" + panelRoot.panelId


                    Menu {
                        id: typeMenu
                        objectName: "panelTypeMenu_" + panelRoot.panelId
                        x: 0
                        y: parent.height
                        MenuItem {
                            text: "Viewer"
                            checkable: true
                            checked: panelRoot.panelType === "viewer"
                            onTriggered: panelRoot.workspace.setPanelType(panelRoot.panelId, "viewer")
                        }
                        MenuItem {
                            text: "Nodegraph"
                            checkable: true
                            checked: panelRoot.panelType === "nodegraph"
                            onTriggered: panelRoot.workspace.setPanelType(panelRoot.panelId, "nodegraph")
                        }
                        MenuItem {
                            text: "Timeline"
                            checkable: true
                            checked: panelRoot.panelType === "timeline"
                            onTriggered: panelRoot.workspace.setPanelType(panelRoot.panelId, "timeline")
                        }
                        MenuItem {
                            text: "Parameters"
                            checkable: true
                            checked: panelRoot.panelType === "parameters"
                            onTriggered: panelRoot.workspace.setPanelType(panelRoot.panelId, "parameters")
                        }
                        MenuItem {
                            text: "Animation"
                            checkable: true
                            checked: panelRoot.panelType === "animation"
                            onTriggered: panelRoot.workspace.setPanelType(panelRoot.panelId, "animation")
                        }
                        MenuItem {
                            text: "Media Bin"
                            checkable: true
                            checked: panelRoot.panelType === "mediabin"
                            onTriggered: panelRoot.workspace.setPanelType(panelRoot.panelId, "mediabin")
                        }
                        MenuSeparator {
                        }
                        MenuItem {
                            text: "Split Horizontal"
                            onTriggered: panelRoot.workspace.split(panelRoot.leafId, "horizontal")
                        }
                        MenuItem {
                            text: "Split Vertical"
                            onTriggered: panelRoot.workspace.split(panelRoot.leafId, "vertical")
                        }
                        MenuItem {
                            text: "Add Tab"
                            onTriggered: panelRoot.workspace.addTab(panelRoot.leafId, panelRoot.panelType)
                        }
                        MenuSeparator {
                        }
                        MenuItem {
                            text: "Close Panel"
                            onTriggered: panelRoot.workspace.closePanel(panelRoot.panelId)
                        }
                        MenuSeparator {
                        }
                        MenuItem {
                            text: "Reset Layout"
                            onTriggered: panelRoot.workspace.reset()
                        }
                    }
                }

                Button {
                    id: groupButton
                    flat: true
                    padding: 6
                    implicitWidth: 26
                    implicitHeight: 24
                    font.pixelSize: 12
                    text: panelRoot.panelGroup
                    background: Rectangle {
                        radius: theme.smallRadius
                        color: groupButton.hovered ? theme.hover : "transparent"
                    }
                    contentItem: Text {
                        text: groupButton.text
                        color: theme.muted
                        font.pixelSize: 10
                        horizontalAlignment: Text.AlignHCenter
                        verticalAlignment: Text.AlignVCenter
                    }
                    onClicked: groupMenu.open()
                    Accessible.name: "Panel display group. Opens the group menu."
                    objectName: "panelGroup_" + panelRoot.panelId
                    ToolTip.visible: hovered
                    ToolTip.text: "Panel group"

                    Menu {
                        id: groupMenu
                        x: 0
                        y: parent.height
                        MenuItem {
                            text: "A"
                            checkable: true
                            checked: panelRoot.panelGroup === "A"
                            onTriggered: panelRoot.workspace.setGroup(panelRoot.panelId, "A")
                        }
                        MenuItem {
                            text: "B"
                            checkable: true
                            checked: panelRoot.panelGroup === "B"
                            onTriggered: panelRoot.workspace.setGroup(panelRoot.panelId, "B")
                        }
                        MenuItem {
                            text: "C"
                            checkable: true
                            checked: panelRoot.panelGroup === "C"
                            onTriggered: panelRoot.workspace.setGroup(panelRoot.panelId, "C")
                        }
                        MenuItem {
                            text: "D"
                            checkable: true
                            checked: panelRoot.panelGroup === "D"
                            onTriggered: panelRoot.workspace.setGroup(panelRoot.panelId, "D")
                        }
                        MenuItem {
                            text: "E"
                            checkable: true
                            checked: panelRoot.panelGroup === "E"
                            onTriggered: panelRoot.workspace.setGroup(panelRoot.panelId, "E")
                        }
                    }
                }
                Item {
                    Layout.fillWidth: panelRoot.panelType !== "viewer"
                    Layout.fillHeight: true
                }
                Loader {
                    id: panelTools
                    Layout.preferredWidth: panelRoot.panelType === "viewer" ? 0 : (item ? item.implicitWidth : 0)
                    Layout.minimumWidth: 0
                    Layout.fillWidth: panelRoot.panelType === "viewer"
                    Layout.fillHeight: true
                    sourceComponent: panelBody.item && panelBody.item.headerTools !== undefined ? panelBody.item.headerTools : null
                }

            }
        }
        Item {
            Layout.fillWidth: true
            Layout.fillHeight: true

            Loader {
                id: panelBody
                anchors.fill: parent
                source: panelRoot.panelType === "viewer" ? "ViewerPanel.qml" : panelRoot.panelType === "nodegraph" ? "GraphPanel.qml" : panelRoot.panelType === "parameters" ? "ParametersPanel.qml" : panelRoot.panelType === "animation" ? "AnimationPanel.qml" : panelRoot.panelType === "timeline" ? "TimelinePanel.qml" : panelRoot.panelType === "mediabin" ? "MediaBinPanel.qml" : ""
                onLoaded: {
                    if ("panelId" in item)
                        item.panelId = Qt.binding(function () {
                                return panelRoot.panelId;
                            });
                    if ("panelGroup" in item)
                        item.panelGroup = Qt.binding(function () {
                                return panelRoot.panelGroup;
                            });
                }
            }
        }
    }
}
