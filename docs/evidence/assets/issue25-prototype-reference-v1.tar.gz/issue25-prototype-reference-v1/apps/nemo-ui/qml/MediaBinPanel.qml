import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

FocusScope {
    id: root

    objectName: "mediaBinPrototype"
    focus: true
    activeFocusOnTab: true
    clip: true

    property string panelId: ""
    property string panelGroup: "A"
    property var catalog: (typeof studio !== "undefined" && studio) ? studio.media : null
    property string currentParentId: "root"
    property string currentSmartBinId: ""
    property real treeWidth: 184
    property bool treeCollapsed: false
    property bool treeDragging: false
    property bool projectScope: false
    property string searchText: ""
    property string kindFilter: "all"
    property bool unusedOnly: false
    property bool offlineOnly: false
    property string viewMode: "list"
    property string sortField: "name"
    property bool sortDescending: false
    property var expandedBins: ({
            "root": true
        })
    property var selectedIds: []
    property string anchorId: ""
    property string renameId: ""
    property var clipboardIds: []
    property bool clipboardCut: false
    property string statusMessage: ""
    property bool statusError: false
    property string hoverDropBinId: ""
    property string pendingHoverBinId: ""
    property var labelOptions: ["", "#d9855d", "#d6b65d", "#86aa72", "#6b9fc1", "#9b83b4", "#b87991"]
    property int catalogRevision: catalog ? Number(catalog.revision || 0) : 0
    property int smartBinRevision: 0
    property var smartBins: [{
            "id": "smart-offline",
            "name": "Offline",
            "builtIn": true,
            "query": {
                "parentId": "project",
                "projectScope": true,
                "searchText": "",
                "kindFilter": "all",
                "mediaOnly": true,
                "unusedOnly": false,
                "offlineOnly": true
            }
        }, {
            "id": "smart-unused",
            "name": "Unused",
            "builtIn": true,
            "query": {
                "parentId": "project",
                "projectScope": true,
                "searchText": "",
                "kindFilter": "all",
                "mediaOnly": true,
                "unusedOnly": true,
                "offlineOnly": false
            }
        }]
    readonly property Item dragOverlay: Overlay.overlay
    property var selectedRecord: selectedIds.length > 0 ? itemById(selectedIds[0]) : null
    property Component headerTools: mediaHeaderTools

    function arrayValue(value) {
        return value && value.length !== undefined ? value : [];
    }

    function itemById(id) {
        if (!catalog || !catalog.item || id === undefined || id === null)
            return null;
        return catalog.item(String(id));
    }

    function isBin(item) {
        return !!item && String(item.kind || "") === "bin";
    }

    function currentPath() {
        if (!catalog || !catalog.path)
            return [{
                    "id": "root",
                    "name": "Project",
                    "kind": "bin"
                }];
        return catalog.path(currentParentId) || [{
                "id": "root",
                "name": "Project",
                "kind": "bin"
            }];
    }

    function currentName() {
        var item = itemById(currentParentId);
        return item && item.name ? String(item.name) : "Project";
    }

    function smartBinById(id) {
        var key = String(id || "");
        for (var i = 0; i < smartBins.length; ++i)
            if (smartBins[i] && String(smartBins[i].id) === key)
                return smartBins[i];
        return null;
    }

    function activeQuery() {
        var smart = smartBinById(currentSmartBinId);
        if (smart && smart.query)
            return smart.query;
        return {
            "parentId": projectScope ? "project" : currentParentId,
            "projectScope": projectScope,
            "searchText": searchText,
            "kindFilter": kindFilter,
            "mediaOnly": false,
            "unusedOnly": unusedOnly,
            "offlineOnly": offlineOnly
        };
    }

    function leaveSmartBin() {
        if (currentSmartBinId)
            currentSmartBinId = "";
    }

    function queryFilter(query) {
        var filter = {};
        if (query.kindFilter && query.kindFilter !== "all")
            filter.kind = query.kindFilter;
        if (query.mediaOnly)
            filter.kind = ["video", "audio", "still"];
        if (query.unusedOnly)
            filter.unused = true;
        if (query.offlineOnly)
            filter.offline = true;
        return filter;
    }

    function visibleItems() {
        var revision = catalogRevision + smartBinRevision;
        var query = activeQuery();
        if (!catalog || !catalog.query)
            return [];
        var result = catalog.query(query.parentId, query.searchText, query.projectScope, queryFilter(query)) || [];
        result = arrayValue(result).slice(0);
        result.sort(function (a, b) {
                if (a.kind === "bin" && b.kind !== "bin")
                    return -1;
                if (a.kind !== "bin" && b.kind === "bin")
                    return 1;
                var av;
                var bv;
                if (sortField === "kind") {
                    av = String(a.kind || "");
                    bv = String(b.kind || "");
                } else if (sortField === "duration") {
                    av = Number(a.duration || 0);
                    bv = Number(b.duration || 0);
                } else {
                    av = String(a.name || "").toLowerCase();
                    bv = String(b.name || "").toLowerCase();
                }
                var order = av < bv ? -1 : av > bv ? 1 : String(a.id).localeCompare(String(b.id));
                return sortDescending ? -order : order;
            });
        return result;
    }

    function smartRows() {
        var revision = smartBinRevision;
        var rows = [];
        for (var i = 0; i < smartBins.length; ++i) {
            var smart = smartBins[i];
            if (smart)
                rows.push({
                        "smart": true,
                        "smartId": String(smart.id),
                        "name": String(smart.name || smart.id),
                        "depth": 1
                    });
        }
        return rows;
    }

    function treeRows() {
        var revision = catalogRevision + smartBinRevision;
        var rows = [];
        var seen = {};
        function add(parentId, depth) {
            var children = catalog && catalog.children ? arrayValue(catalog.children(parentId)) : [];
            for (var i = 0; i < children.length; ++i) {
                var child = children[i];
                if (!child || !isBin(child) || seen[child.id])
                    continue;
                seen[child.id] = true;
                var open = !!expandedBins[String(child.id)];
                rows.push({
                        "record": child,
                        "depth": depth,
                        "open": open
                    });
                if (open)
                    add(String(child.id), depth + 1);
            }
        }
        var rootRecord = itemById("root") || {
            "id": "root",
            "parentId": "",
            "kind": "bin",
            "name": "Project"
        };
        rows.push({
                "record": rootRecord,
                "depth": 0,
                "open": !!expandedBins.root
            });
        if (expandedBins.root)
            add("root", 1);
        rows.push({
                "section": true,
                "name": "Smart Bins",
                "depth": 0,
                "open": true
            });
        return rows.concat(smartRows());
    }

    function openSmartBin(id) {
        var smart = smartBinById(id);
        if (!smart || !smart.query)
            return;
        var query = smart.query;
        currentSmartBinId = String(id);
        currentParentId = String(query.parentId || "root");
        projectScope = !!query.projectScope;
        searchText = String(query.searchText || "");
        kindFilter = query.kindFilter || "all";
        unusedOnly = !!query.unusedOnly;
        offlineOnly = !!query.offlineOnly;
        clearSelection();
    }

    function beginSaveSmartBin() {
        var query = activeQuery();
        smartDialog.mode = "save";
        smartDialog.smartId = "";
        smartDialog.name = "Saved search";
        smartDialog.query = {
            "parentId": String(query.parentId || currentParentId),
            "projectScope": !!query.projectScope,
            "searchText": String(query.searchText || ""),
            "kindFilter": query.kindFilter || "all",
            "mediaOnly": !!query.mediaOnly,
            "unusedOnly": !!query.unusedOnly,
            "offlineOnly": !!query.offlineOnly
        };
        smartNameField.text = smartDialog.name;
        smartDialog.open();
        smartNameField.forceActiveFocus();
        smartNameField.selectAll();
    }

    function beginRenameSmartBin(id) {
        var smart = smartBinById(id);
        if (!smart || smart.builtIn)
            return;
        smartDialog.mode = "rename";
        smartDialog.smartId = String(id);
        smartDialog.name = String(smart.name || "");
        smartDialog.query = smart.query;
        smartNameField.text = smartDialog.name;
        smartDialog.open();
        smartNameField.forceActiveFocus();
        smartNameField.selectAll();
    }

    function finishSmartDialog() {
        var name = String(smartNameField.text || "").trim();
        if (!name)
            return;
        var next = smartBins.slice(0);
        if (smartDialog.mode === "rename") {
            for (var i = 0; i < next.length; ++i) {
                if (String(next[i].id) === smartDialog.smartId) {
                    next[i] = Object.assign({}, next[i], {
                            "name": name
                        });
                    break;
                }
            }
        } else {
            var id = "smart-" + panelGroup + "-" + Date.now();
            next.push({
                    "id": id,
                    "name": name,
                    "builtIn": false,
                    "query": smartDialog.query
                });
            currentSmartBinId = id;
        }
        smartBins = next;
        smartBinRevision += 1;
    }

    function deleteSmartBin(id) {
        var smart = smartBinById(id);
        if (!smart || smart.builtIn)
            return;
        var next = [];
        for (var i = 0; i < smartBins.length; ++i)
            if (String(smartBins[i].id) !== String(id))
                next.push(smartBins[i]);
        smartBins = next;
        smartBinRevision += 1;
        if (currentSmartBinId === String(id))
            currentSmartBinId = "";
    }

    function setStatus(message, error) {
        if (!error) {
            statusMessage = "";
            statusError = false;
            statusTimer.stop();
            return;
        }
        statusMessage = message ? String(message) : "";
        statusError = true;
        statusTimer.restart();
    }

    function catalogError(fallback) {
        return catalog && catalog.error ? String(catalog.error) : String(fallback || "Media catalog operation failed");
    }

    function applyCatalog(operation, successText) {
        if (!catalog || !catalog.apply) {
            setStatus("Media catalog is unavailable", true);
            return false;
        }
        var ok = !!catalog.apply(operation);
        if (ok)
            setStatus(successText || "", false);
        else
            setStatus(catalogError(), true);
        return ok;
    }

    function normalizeIds(ids) {
        var result = [];
        var values = arrayValue(ids);
        for (var i = 0; i < values.length; ++i) {
            var id = String(values[i]);
            if (id !== "root" && result.indexOf(id) < 0 && itemById(id))
                result.push(id);
        }
        return result;
    }

    function isSelected(id) {
        return selectedIds.indexOf(String(id)) >= 0;
    }

    function selectOne(id, modifiers) {
        id = String(id);
        var additive = !!(modifiers & Qt.ControlModifier);
        var range = !!(modifiers & Qt.ShiftModifier);
        var next = additive ? selectedIds.slice(0) : [];
        if (range && anchorId) {
            var rows = visibleItems();
            var a = -1;
            var b = -1;
            for (var i = 0; i < rows.length; ++i) {
                if (String(rows[i].id) === anchorId)
                    a = i;
                if (String(rows[i].id) === id)
                    b = i;
            }
            if (a >= 0 && b >= 0) {
                var from = Math.min(a, b);
                var to = Math.max(a, b);
                next = additive ? next : [];
                for (var n = from; n <= to; ++n)
                    if (next.indexOf(String(rows[n].id)) < 0)
                        next.push(String(rows[n].id));
                selectedIds = normalizeIds(next);
                anchorId = id;
                return;
            }
        }
        var at = next.indexOf(id);
        if (additive && at >= 0)
            next.splice(at, 1);
        else if (at < 0)
            next.push(id);
        selectedIds = normalizeIds(next);
        anchorId = id;
    }

    function selectAll() {
        selectedIds = normalizeIds(visibleItems().map(function (item) {
                    return item.id;
                }));
        if (selectedIds.length)
            anchorId = selectedIds[0];
    }

    function clearSelection() {
        selectedIds = [];
        anchorId = "";
        renameId = "";
    }

    function openBin(id) {
        forceActiveFocus();
        var record = itemById(id);
        if (!isBin(record))
            return;
        currentSmartBinId = "";
        currentParentId = String(id);
        projectScope = false;
        clearSelection();
        var next = Object.assign({}, expandedBins);
        next[String(id)] = true;
        expandedBins = next;
    }

    function toggleBin(id) {
        id = String(id);
        var next = Object.assign({}, expandedBins);
        next[id] = !expandedBins[id];
        expandedBins = next;
    }

    function navigateBreadcrumb(id) {
        openBin(id);
    }

    function beginCreate(parentId, fromSelection) {
        createBinDialog.parentId = parentId || currentParentId;
        createBinDialog.fromSelection = !!fromSelection;
        createBinField.text = "New bin";
        createBinDialog.open();
        createBinField.forceActiveFocus();
        createBinField.selectAll();
    }

    function finishCreate() {
        var name = createBinField.text.trim();
        if (!name)
            return;
        var parent = createBinDialog.parentId || currentParentId;
        var chosen = normalizeIds(selectedIds);
        if (createBinDialog.fromSelection && chosen.length && catalog && catalog.newBinFromSelection) {
            if (catalog.newBinFromSelection(chosen, name, parent)) {
                setStatus("Created bin from selection", false);
                return;
            }
            setStatus(catalogError(), true);
            return;
        }
        if (applyCatalog({
                "type": "createBin",
                "parentId": parent,
                "name": name
            }, "Created bin")) {
            var nextExpanded = Object.assign({}, expandedBins);
            nextExpanded[parent] = true;
            expandedBins = nextExpanded;
            var children = catalog.children(parent) || [];
            for (var i = children.length - 1; i >= 0; --i) {
                if (children[i].name === name && children[i].kind === "bin") {
                    currentParentId = String(children[i].id);
                    break;
                }
            }
            if (createBinDialog.fromSelection && chosen.length) {
                applyCatalog({
                        "type": "move",
                        "ids": chosen,
                        "parentId": currentParentId
                    }, "Created bin from selection");
            }
        }
    }

    function startRename(id) {
        var item = itemById(id);
        if (!item || String(id) === "root")
            return;
        renameId = String(id);
        renameDialog.recordId = renameId;
        renameDialogField.text = String(item.name || "");
        renameDialog.open();
        renameDialogField.forceActiveFocus();
        renameDialogField.selectAll();
    }

    function commitRename(id, value) {
        var name = String(value || "").trim();
        renameId = "";
        if (name)
            applyCatalog({
                    "type": "rename",
                    "id": String(id),
                    "name": name
                }, "Renamed item");
    }

    function requestDelete(ids) {
        var chosen = normalizeIds(ids);
        if (!chosen.length)
            return;
        var nonempty = false;
        for (var i = 0; i < chosen.length; ++i) {
            var item = itemById(chosen[i]);
            if (isBin(item) && catalog.children && catalog.children(chosen[i]).length > 0)
                nonempty = true;
        }
        if (nonempty) {
            deleteDialog.ids = chosen;
            deleteDialog.open();
            return;
        }
        applyCatalog({
                "type": "remove",
                "ids": chosen,
                "keepContents": false
            }, "Deleted selection");
        clearSelection();
    }

    function deleteSelection() {
        requestDelete(selectedIds);
    }

    function copySelection(cut) {
        var chosen = normalizeIds(selectedIds);
        if (!chosen.length)
            return;
        clipboardIds = chosen;
        clipboardCut = !!cut;
        setStatus(cut ? "Cut " + chosen.length + " item(s)" : "Copied " + chosen.length + " item(s)", false);
    }

    function pasteSelection() {
        if (!clipboardIds.length)
            return;
        if (clipboardCut) {
            if (applyCatalog({
                    "type": "move",
                    "ids": clipboardIds,
                    "parentId": currentParentId
                }, "Moved selection")) {
                selectedIds = normalizeIds(clipboardIds);
                clipboardIds = [];
                clipboardCut = false;
            }
        } else {
            if (applyCatalog({
                    "type": "duplicate",
                    "ids": clipboardIds,
                    "parentId": currentParentId
                }, "Duplicated selection"))
                clearSelection();
        }
    }

    function applyMetadata(id, changes) {
        id = String(id || "");
        if (!id || !itemById(id))
            return;
        applyCatalog({
                "type": "metadata",
                "ids": [id],
                "changes": changes
            }, "Updated metadata");
    }
    function openMetadata(id) {
        var item = itemById(id);
        if (!item)
            return;
        selectedIds = [String(id)];
        metadataDialog.recordId = String(id);
        metadataDialogField.text = recordTags(item);
        metadataDescriptionField.text = String(item.description || "");
        metadataLabelCombo.currentIndex = Math.max(0, labelOptions.indexOf(item.color ? String(item.color) : ""));
        metadataDialog.open();
    }

    function selectedSourceId() {
        var item = selectedRecord;
        return item && !isBin(item) && item.sourceId ? String(item.sourceId) : "";
    }

    function openSelected() {
        if (isBin(selectedRecord)) {
            openBin(selectedRecord.id);
            return;
        }
        var sourceId = selectedSourceId();
        if (!sourceId)
            return;
        if (studio && studio.openMedia)
            studio.openMedia(panelGroup, sourceId);
    }

    function sourceIdsForItemIds(ids) {
        var result = [];
        var values = arrayValue(ids);
        var rows = visibleItems();
        for (var i = 0; i < rows.length; ++i) {
            var item = rows[i];
            var sourceId = !isBin(item) && item.sourceId ? String(item.sourceId) : "";
            if (sourceId && values.indexOf(item.id) >= 0)
                result.push(sourceId);
        }
        return result;
    }

    function dragIds(drag) {
        var result = [];
        if (drag && drag.source && drag.source.itemIds)
            result = arrayValue(drag.source.itemIds);
        if (!result.length && drag && drag.mimeData && drag.mimeData.itemIds)
            result = arrayValue(drag.mimeData.itemIds);
        if (!result.length && drag && drag.source && drag.source.itemId)
            result = [drag.source.itemId];
        if (!result.length && drag && drag.mimeData && drag.mimeData.itemId)
            result = [drag.mimeData.itemId];
        return normalizeIds(result);
    }

    function revealOriginalBin(drag) {
        var ids = dragIds(drag);
        if (!ids.length)
            return;
        var item = itemById(ids[0]);
        if (item && item.parentId)
            openBin(item.parentId);
    }

    function handleSmartDrop(smartId, drag) {
        if (drag)
            drag.accepted = false;
        revealOriginalBin(drag);
        setStatus("Smart bins are read-only", true);
    }

    function handleDrop(parentId, drag) {
        var destination = itemById(parentId);
        if (!isBin(destination)) {
            if (drag)
                drag.accepted = false;
            return false;
        }
        var ids = dragIds(drag);
        if (!ids.length) {
            if (drag)
                drag.accepted = false;
            return false;
        }
        var ok = applyCatalog({
                "type": "move",
                "ids": ids,
                "parentId": String(parentId)
            }, "Moved selection");
        if (drag && ok)
            drag.accept(Qt.MoveAction);
        else if (drag)
            drag.accepted = false;
        hoverDropBinId = "";
        pendingHoverBinId = "";
        if (ok)
            selectedIds = ids;
        return ok;
    }

    function beginDropHover(id) {
        id = String(id);
        hoverDropBinId = id;
        pendingHoverBinId = id;
        hoverExpandTimer.restart();
    }

    function endDropHover(id) {
        if (hoverDropBinId === String(id))
            hoverDropBinId = "";
        if (pendingHoverBinId === String(id))
            pendingHoverBinId = "";
        hoverExpandTimer.stop();
    }

    function durationText(item) {
        var duration = Number(item && item.duration || 0);
        if (!isFinite(duration) || duration <= 0)
            return "";
        var fps = studio.timeline.fps;
        var frames = Math.round(duration);
        function pad(value) {
            return String(value).padStart(2, "0");
        }
        return pad(Math.floor(frames / (fps * 3600))) + ":" + pad(Math.floor(frames / (fps * 60)) % 60) + ":" + pad(Math.floor(frames / fps) % 60) + ":" + pad(frames % fps);
    }

    function kindGlyph(item) {
        if (!item)
            return "?";
        if (item.kind === "bin")
            return "▱";
        if (item.kind === "video")
            return "V";
        if (item.kind === "audio")
            return "A";
        if (item.kind === "still")
            return "S";
        return "•";
    }

    function kindColor(item) {
        if (item && item.color)
            return item.color;
        if (item && item.kind === "bin")
            return theme.muted;
        return theme.accent;
    }

    function recordTags(item) {
        if (!item || !item.tags)
            return "";
        return item.tags.length !== undefined && typeof item.tags !== "string" ? item.tags.join(", ") : String(item.tags);
    }

    Component {
        id: mediaHeaderTools
        Row {
            spacing: 2
            CompactButton {
                id: viewButton
                objectName: "mediaViewToggleButton"
                glyph: root.viewMode === "list" ? "▦" : "☷"
                activeMode: true
                ToolTip.text: root.viewMode === "list" ? "Switch to grid view" : "Switch to list view"
                Accessible.name: ToolTip.text
                onClicked: root.viewMode = root.viewMode === "list" ? "grid" : "list"
            }
            CompactButton {
                objectName: "mediaTreeToggleButton"
                glyph: "▤"
                activeMode: !root.treeCollapsed
                ToolTip.text: root.treeCollapsed ? "Show bins" : "Hide bins"
                Accessible.name: ToolTip.text
                onClicked: root.treeCollapsed = !root.treeCollapsed
            }
            CompactButton {
                objectName: "mediaAddBinButton"
                glyph: "+"
                ToolTip.text: "Create bin"
                Accessible.name: "Create bin"
                onClicked: root.beginCreate(root.currentParentId, false)
            }
            CompactButton {
                id: filterButton
                objectName: "mediaFilterButton"
                glyph: "≡"
                ToolTip.text: "Filter or save search"
                Accessible.name: "Filter or save search"
                onClicked: filterMenu.open()
            }
        }
    }
    component CompactButton: Button {
        id: compactButton
        property string glyph: ""
        property bool activeMode: false
        implicitWidth: 24
        implicitHeight: 24
        width: 24
        height: 24
        padding: 0
        flat: true
        background: Rectangle {
            radius: theme.smallRadius
            color: compactButton.activeMode ? Qt.rgba(theme.accent.r, theme.accent.g, theme.accent.b, 0.16) : compactButton.hovered ? theme.hover : "transparent"
            border.width: compactButton.activeFocus ? 1 : 0
            border.color: theme.accent
        }
        contentItem: Text {
            text: compactButton.glyph
            color: compactButton.activeMode ? theme.accent : compactButton.enabled ? theme.muted : theme.disabled
            font.pixelSize: 15
            horizontalAlignment: Text.AlignHCenter
            verticalAlignment: Text.AlignVCenter
        }
        ToolTip.visible: hovered
        ToolTip.delay: 450
    }

    ColumnLayout {
        anchors.fill: parent
        anchors.margins: 6
        spacing: 5

        RowLayout {
            Layout.fillWidth: true
            spacing: 4
            TextField {
                id: searchField
                objectName: "mediaSearchField"
                Layout.fillWidth: true
                implicitHeight: 26
                placeholderTextColor: theme.muted
                placeholderText: "Search media"
                text: root.searchText
                readOnly: !!root.currentSmartBinId
                onActiveFocusChanged: if (activeFocus && root.currentSmartBinId)
                    root.leaveSmartBin()
                onTextChanged: if (!root.currentSmartBinId)
                    root.searchText = text
                selectByMouse: true
            }
            StudioComboBox {
                id: scopeCombo
                objectName: "mediaScopeCombo"
                implicitWidth: 110
                implicitHeight: 26
                model: ["This Bin", "Project"]
                currentIndex: root.projectScope ? 1 : 0
                enabled: !root.currentSmartBinId
                onActivated: {
                    root.leaveSmartBin();
                    root.projectScope = currentIndex === 1;
                }
            }
        }

        RowLayout {
            Layout.fillWidth: true
            spacing: 4
            Text {
                objectName: "mediaBreadcrumbs"
                text: ""
                visible: false
            }
            Repeater {
                model: root.currentPath()
                delegate: Item {
                    required property var modelData
                    implicitWidth: breadcrumbText.implicitWidth + 14
                    implicitHeight: 24
                    Button {
                        id: breadcrumbButton
                        anchors.fill: parent
                        objectName: "mediaBreadcrumb_" + String(modelData.id)
                        text: String(modelData.name || modelData.id)
                        flat: true
                        padding: 4
                        onClicked: root.navigateBreadcrumb(modelData.id)
                        contentItem: Text {
                            text: breadcrumbButton.text
                            color: theme.text
                            font.pixelSize: theme.fontSize
                            elide: Text.ElideRight
                            verticalAlignment: Text.AlignVCenter
                        }
                    }
                    Text {
                        id: breadcrumbText
                        visible: false
                        text: String(modelData.name || modelData.id)
                    }
                    DropArea {
                        anchors.fill: parent
                        objectName: "mediaBreadcrumbDrop_" + String(modelData.id)
                        keys: ["application/x-nemo-source", "application/x-nemo-source-id", "text/plain"]
                        onEntered: root.beginDropHover(modelData.id)
                        onExited: root.endDropHover(modelData.id)
                        onDropped: function (drop) {
                            root.handleDrop(modelData.id, drop);
                        }
                    }
                }
            }
        }
        RowLayout {
            Layout.fillWidth: true
            Layout.fillHeight: true
            spacing: 5

            Item {
                id: treePane
                Layout.preferredWidth: root.treeCollapsed ? 0 : Math.min(root.treeWidth, Math.max(120, root.width * 0.4))
                Layout.minimumWidth: root.treeCollapsed ? 0 : Math.min(120, Math.max(80, root.width * 0.4))
                Layout.fillHeight: true
                clip: true
                visible: !root.treeCollapsed
                Rectangle {
                    anchors.fill: parent
                    color: theme.field
                    radius: theme.smallRadius
                    border.color: theme.border
                    border.width: 1
                }
                ListView {
                    id: treeView
                    objectName: "mediaTreeView"
                    anchors.fill: parent
                    anchors.margins: 2
                    clip: true
                    model: root.treeRows()
                    boundsBehavior: Flickable.StopAtBounds
                    delegate: Item {
                        id: treeRow
                        required property var modelData
                        property bool sectionRow: !!modelData.section
                        property bool smartRow: !!modelData.smart
                        property var record: modelData.record || ({
                                "id": "",
                                "kind": "",
                                "name": modelData.name || ""
                            })
                        property int depth: Number(modelData.depth || 0)
                        property bool expanded: !!modelData.open
                        width: treeView.width
                        height: sectionRow ? 23 : 27
                        objectName: sectionRow ? "mediaSmartBinsHeader" : smartRow ? "mediaSmartBin_" + String(modelData.smartId) : "mediaTreeItem_" + String(record.id)
                        Rectangle {
                            anchors.fill: parent
                            radius: theme.smallRadius
                            color: sectionRow ? theme.header : smartRow && root.hoverDropBinId === String(modelData.smartId) ? Qt.rgba(theme.accent.r, theme.accent.g, theme.accent.b, 0.24) : smartRow && root.currentSmartBinId === String(modelData.smartId) ? theme.nodeSelected : !smartRow && root.hoverDropBinId === String(record.id) ? Qt.rgba(theme.accent.r, theme.accent.g, theme.accent.b, 0.24) : !smartRow && !root.currentSmartBinId && root.currentParentId === String(record.id) ? theme.nodeSelected : !smartRow && root.isSelected(record.id) ? theme.hover : "transparent"
                            border.color: !sectionRow && ((smartRow && root.hoverDropBinId === String(modelData.smartId)) || (!smartRow && root.hoverDropBinId === String(record.id))) ? theme.accent : "transparent"
                            border.width: 1
                        }
                        Text {
                            visible: !sectionRow && !smartRow
                            x: 5 + treeRow.depth * 13
                            width: 12
                            height: parent.height
                            text: root.catalog && root.catalog.children && root.catalog.children(record.id).length > 0 ? (treeRow.expanded ? "⌄" : "›") : ""
                            color: theme.muted
                            horizontalAlignment: Text.AlignHCenter
                            verticalAlignment: Text.AlignVCenter
                            font.pixelSize: 13
                        }
                        Text {
                            x: sectionRow ? 8 : smartRow ? 20 : 20 + treeRow.depth * 13
                            width: Math.max(30, parent.width - x - 5)
                            height: parent.height
                            text: sectionRow ? String(modelData.name) : smartRow ? "⌾ " + String(modelData.name) : String(record.name || record.id)
                            color: sectionRow ? theme.muted : theme.text
                            elide: Text.ElideRight
                            verticalAlignment: Text.AlignVCenter
                            font.pixelSize: sectionRow ? theme.fontSize - 1 : theme.fontSize
                            font.bold: sectionRow
                        }
                        MouseArea {
                            anchors.fill: parent
                            z: 1
                            objectName: sectionRow ? "mediaSmartBinsHeaderInput" : smartRow ? "mediaSmartBinInput_" + String(modelData.smartId) : "mediaTreeInput_" + String(record.id)
                            acceptedButtons: Qt.LeftButton | Qt.RightButton
                            onClicked: function (mouse) {
                                if (sectionRow)
                                    return;
                                if (smartRow) {
                                    if (mouse.button === Qt.RightButton) {
                                        smartMenu.smartId = String(modelData.smartId);
                                        smartMenu.x = mouse.x;
                                        smartMenu.y = mouse.y;
                                        smartMenu.open();
                                    } else {
                                        root.openSmartBin(modelData.smartId);
                                    }
                                    return;
                                }
                                root.selectOne(record.id, mouse.modifiers);
                                if (mouse.button === Qt.RightButton) {
                                    treeMenu.x = mouse.x;
                                    treeMenu.y = mouse.y;
                                    treeMenu.recordId = String(record.id);
                                    treeMenu.open();
                                } else if (mouse.x < 25 + treeRow.depth * 13 && root.catalog.children(record.id).length > 0) {
                                    root.toggleBin(record.id);
                                } else {
                                    root.openBin(record.id);
                                }
                            }
                        }
                        DropArea {
                            visible: !sectionRow
                            anchors.fill: parent
                            z: 2
                            objectName: smartRow ? "mediaSmartBinDrop_" + String(modelData.smartId) : "mediaTreeDrop_" + String(record.id)
                            keys: ["application/x-nemo-source", "application/x-nemo-source-id", "text/plain"]
                            onEntered: if (smartRow)
                                root.hoverDropBinId = String(modelData.smartId)
                            else
                                root.beginDropHover(record.id)
                            onExited: if (smartRow)
                                root.hoverDropBinId = ""
                            else
                                root.endDropHover(record.id)
                            onDropped: function (drop) {
                                if (smartRow)
                                    root.handleSmartDrop(modelData.smartId, drop);
                                else
                                    root.handleDrop(record.id, drop);
                            }
                        }
                    }
                }
            }

            Rectangle {
                id: treeSplitter
                visible: !root.treeCollapsed
                Layout.preferredWidth: 4
                Layout.fillHeight: true
                color: splitterMouse.containsMouse || root.treeDragging ? theme.accent : theme.border
                MouseArea {
                    id: splitterMouse
                    property real pressX: 0
                    property real pressWidth: 0
                    anchors.fill: parent
                    cursorShape: Qt.SizeHorCursor
                    hoverEnabled: true
                    onPressed: {
                        pressX = mouse.x;
                        pressWidth = root.treeWidth;
                        root.treeDragging = true;
                    }
                    onPositionChanged: function (mouse) {
                        if (pressed)
                            root.treeWidth = Math.max(80, Math.min(320, root.width * 0.4, pressWidth + mouse.x - pressX));
                    }
                    onReleased: root.treeDragging = false
                    onCanceled: root.treeDragging = false
                }
            }

            Item {
                id: contentPane
                Layout.fillWidth: true
                Layout.fillHeight: true
                clip: true
                Rectangle {
                    anchors.fill: parent
                    color: theme.panel
                    radius: theme.smallRadius
                    border.color: theme.border
                    border.width: 1
                }
                Item {
                    id: listHeader
                    objectName: "mediaListHeader"
                    visible: root.viewMode === "list" && contentPane.width >= 420
                    anchors.top: parent.top
                    anchors.left: parent.left
                    anchors.right: parent.right
                    height: visible ? 20 : 0
                    Text {
                        x: 37
                        width: Math.max(40, parent.width - 190)
                        height: parent.height
                        text: "Name"
                        color: theme.muted
                        font.pixelSize: theme.fontSize - 2
                        verticalAlignment: Text.AlignVCenter
                    }
                    Text {
                        x: parent.width - 180
                        width: 94
                        height: parent.height
                        text: "Duration"
                        color: theme.muted
                        font.pixelSize: theme.fontSize - 2
                        verticalAlignment: Text.AlignVCenter
                    }
                    Text {
                        x: parent.width - 84
                        width: 72
                        height: parent.height
                        text: "Type"
                        color: theme.muted
                        font.pixelSize: theme.fontSize - 2
                        verticalAlignment: Text.AlignVCenter
                    }
                }
                ListView {
                    id: listView
                    z: 1
                    objectName: "mediaListView"
                    visible: root.viewMode === "list"
                    anchors.top: listHeader.bottom
                    anchors.left: parent.left
                    anchors.right: parent.right
                    anchors.bottom: parent.bottom
                    anchors.margins: 2
                    clip: true
                    focus: true
                    model: root.visibleItems()
                    boundsBehavior: Flickable.StopAtBounds
                    delegate: Item {
                        id: listRow
                        required property var modelData
                        property var record: modelData
                        property string itemId: String(record.id)
                        property string sourceId: record.sourceId ? String(record.sourceId) : ""
                        property string sourceGroup: root.panelGroup
                        property var itemIds: root.selectedIds
                        property var sourceIds: root.sourceIdsForItemIds(root.selectedIds)
                        property bool selected: root.isSelected(itemId)
                        width: listView.width
                        height: 34
                        objectName: "mediaItem_" + itemId
                        Rectangle {
                            anchors.fill: parent
                            radius: theme.smallRadius
                            color: listRow.selected ? theme.nodeSelected : rowMouse.containsMouse ? theme.hover : "transparent"
                            border.color: listRow.selected ? theme.accent : "transparent"
                            border.width: 1
                        }
                        Text {
                            x: 7
                            y: 5
                            width: 20
                            height: 22
                            text: root.kindGlyph(record)
                            color: root.kindColor(record)
                            font.bold: true
                            font.pixelSize: 14
                            horizontalAlignment: Text.AlignHCenter
                            verticalAlignment: Text.AlignVCenter
                        }
                        Text {
                            x: 33
                            y: 0
                            width: Math.max(50, listRow.width - (listRow.width >= 420 ? 225 : 42))
                            height: root.projectScope ? 19 : parent.height
                            text: String(record.name || itemId)
                            color: record.offline ? theme.muted : theme.text
                            elide: Text.ElideRight
                            verticalAlignment: Text.AlignVCenter
                            font.pixelSize: theme.fontSize
                        }
                        Text {
                            visible: root.projectScope
                            x: 33
                            y: 19
                            width: Math.max(50, listRow.width - (listRow.width >= 420 ? 225 : 42))
                            height: 13
                            text: root.catalog.path(record.parentId).map(function (bin) {
                                    return bin.name;
                                }).join(" / ")
                            color: theme.muted
                            font.pixelSize: theme.fontSize - 2
                            elide: Text.ElideRight
                        }
                        Text {
                            visible: listRow.width >= 420
                            x: parent.width - 180
                            y: 0
                            width: 94
                            height: parent.height
                            text: root.durationText(record) || "—"
                            color: theme.muted
                            elide: Text.ElideRight
                            verticalAlignment: Text.AlignVCenter
                            font.pixelSize: theme.fontSize - 1
                        }
                        Text {
                            visible: listRow.width >= 420
                            x: parent.width - 84
                            y: 0
                            width: 72
                            height: parent.height
                            text: String(record.kind || "—")
                            color: theme.muted
                            elide: Text.ElideRight
                            verticalAlignment: Text.AlignVCenter
                            font.pixelSize: theme.fontSize - 1
                        }
                        MouseArea {
                            id: rowMouse
                            anchors.fill: parent
                            objectName: "mediaInput_" + itemId
                            acceptedButtons: Qt.LeftButton | Qt.RightButton
                            hoverEnabled: true
                            preventStealing: true
                            drag.target: dragProxy
                            onPressed: function (mouse) {
                                root.forceActiveFocus();
                                var preserveSelection = root.isSelected(itemId) && !(mouse.modifiers & (Qt.ControlModifier | Qt.ShiftModifier));
                                if (!preserveSelection)
                                    root.selectOne(itemId, mouse.modifiers);
                                if (!root.isSelected(itemId))
                                    return;
                                var p = rowMouse.mapToItem(root.dragOverlay, mouse.x, mouse.y);
                                dragProxy.x = p.x;
                                dragProxy.y = p.y;
                                dragProxy.itemId = itemId;
                                dragProxy.itemIds = root.selectedIds.slice(0);
                                dragProxy.sourceId = record.sourceId ? String(record.sourceId) : "";
                                dragProxy.sourceIds = root.sourceIdsForItemIds(dragProxy.itemIds);
                            }
                            onPositionChanged: function (mouse) {
                                if (pressed) {
                                    var p = rowMouse.mapToItem(root.dragOverlay, mouse.x, mouse.y);
                                    dragProxy.x = p.x;
                                    dragProxy.y = p.y;
                                }
                            }
                            onReleased: function () {
                                if (drag.active)
                                    dragProxy.Drag.drop();
                            }
                            onClicked: function (mouse) {
                                if (mouse.button === Qt.RightButton) {
                                    itemMenu.recordId = itemId;
                                    itemMenu.x = mouse.x;
                                    itemMenu.y = mouse.y;
                                    itemMenu.open();
                                }
                            }
                            onDoubleClicked: root.openSelected()
                        }
                        DropArea {
                            visible: root.isBin(record)
                            anchors.fill: parent
                            z: 3
                            objectName: "mediaListBinDrop_" + itemId
                            keys: ["application/x-nemo-source", "application/x-nemo-source-id", "text/plain"]
                            onEntered: root.beginDropHover(itemId)
                            onExited: root.endDropHover(itemId)
                            onDropped: function (drop) {
                                root.handleDrop(itemId, drop);
                            }
                        }
                        Menu {
                            id: itemMenu
                            property string recordId: ""
                            objectName: "mediaItemMenu_" + itemId
                            MenuItem {
                                text: "Open in viewer"
                                enabled: !!root.itemById(itemMenu.recordId) && !root.isBin(root.itemById(itemMenu.recordId))
                                onTriggered: {
                                    root.selectedIds = [itemMenu.recordId];
                                    root.openSelected();
                                }
                            }
                            MenuItem {
                                text: "Insert at playhead"
                                enabled: root.sourceIdsForItemIds(root.selectedIds).length > 0
                                onTriggered: studio.mediaInsertRequested(root.panelGroup, root.sourceIdsForItemIds(root.selectedIds), "insert")
                            }
                            MenuItem {
                                text: "Overwrite at playhead"
                                enabled: root.sourceIdsForItemIds(root.selectedIds).length > 0
                                onTriggered: studio.mediaInsertRequested(root.panelGroup, root.sourceIdsForItemIds(root.selectedIds), "overwrite")
                            }
                            MenuItem {
                                text: "Metadata…"
                                enabled: !!root.itemById(itemMenu.recordId)
                                onTriggered: root.openMetadata(itemMenu.recordId)
                            }
                            MenuItem {
                                text: "Rename"
                                enabled: itemMenu.recordId !== "root"
                                onTriggered: root.startRename(itemMenu.recordId)
                            }
                            MenuItem {
                                text: "New bin from selection"
                                onTriggered: root.beginCreate(root.currentParentId, true)
                            }
                            MenuSeparator {
                            }
                            MenuItem {
                                text: "Copy"
                                onTriggered: root.copySelection(false)
                            }
                            MenuItem {
                                text: "Cut"
                                onTriggered: root.copySelection(true)
                            }
                            MenuItem {
                                text: "Delete"
                                onTriggered: root.requestDelete([itemMenu.recordId])
                            }
                            MenuSeparator {
                            }
                            MenuItem {
                                text: "Import media…"
                                enabled: false
                            }
                            MenuItem {
                                text: "Relink media…"
                                enabled: false
                            }
                            MenuItem {
                                text: "Create proxy…"
                                enabled: false
                            }
                        }
                        Item {
                            id: dragProxy
                            property string itemId: ""
                            property var itemIds: []
                            property string sourceId: ""
                            property var sourceIds: []
                            parent: root.dragOverlay
                            width: 2
                            height: 2
                            Drag.active: rowMouse.drag.active
                            Drag.source: listRow
                            Drag.keys: ["application/x-nemo-source", "application/x-nemo-source-id", "text/plain"]
                            Drag.supportedActions: Qt.CopyAction | Qt.MoveAction
                            Drag.proposedAction: Qt.CopyAction
                            Drag.mimeData: ({
                                    "itemId": itemId,
                                    "itemIds": itemIds,
                                    "sourceId": sourceId,
                                    "sourceIds": sourceIds,
                                    "application/x-nemo-source-id": sourceId
                                })
                        }
                    }
                    Text {
                        anchors.centerIn: parent
                        visible: listView.count === 0
                        text: "No media in " + root.currentName()
                        color: theme.muted
                        font.pixelSize: theme.fontSize
                    }
                }
                GridView {
                    id: gridView
                    z: 1
                    objectName: "mediaGridView"
                    visible: root.viewMode === "grid"
                    anchors.fill: parent
                    anchors.margins: 8
                    clip: true
                    cellWidth: 118
                    cellHeight: 82
                    model: root.visibleItems()
                    boundsBehavior: Flickable.StopAtBounds
                    delegate: Item {
                        id: gridCell
                        required property var modelData
                        property var record: modelData
                        property string itemId: String(record.id)
                        property string sourceId: record.sourceId ? String(record.sourceId) : ""
                        property string sourceGroup: root.panelGroup
                        property var itemIds: root.selectedIds
                        property var sourceIds: root.sourceIdsForItemIds(root.selectedIds)
                        property bool selected: root.isSelected(itemId)
                        width: gridView.cellWidth - 8
                        height: gridView.cellHeight - 8
                        objectName: "mediaItem_" + itemId
                        Rectangle {
                            anchors.fill: parent
                            radius: theme.smallRadius
                            color: gridCell.selected ? theme.nodeSelected : gridMouse.containsMouse ? theme.hover : theme.field
                            border.color: gridCell.selected ? theme.accent : theme.border
                            border.width: 1
                        }
                        Text {
                            anchors.horizontalCenter: parent.horizontalCenter
                            y: 12
                            text: root.kindGlyph(record)
                            color: root.kindColor(record)
                            font.bold: true
                            font.pixelSize: 24
                        }
                        Text {
                            anchors.left: parent.left
                            anchors.right: parent.right
                            anchors.leftMargin: 6
                            anchors.rightMargin: 6
                            y: 43
                            height: 17
                            text: String(record.name || itemId)
                            color: record.offline ? theme.muted : theme.text
                            elide: Text.ElideRight
                            horizontalAlignment: Text.AlignHCenter
                            font.pixelSize: theme.fontSize
                        }
                        Text {
                            anchors.left: parent.left
                            anchors.right: parent.right
                            y: 61
                            height: 13
                            text: (record.kind || "") + (root.durationText(record) ? " · " + root.durationText(record) : "")
                            color: theme.muted
                            elide: Text.ElideRight
                            horizontalAlignment: Text.AlignHCenter
                            font.pixelSize: theme.fontSize - 2
                        }
                        MouseArea {
                            id: gridMouse
                            anchors.fill: parent
                            objectName: "mediaGridInput_" + itemId
                            acceptedButtons: Qt.LeftButton | Qt.RightButton
                            hoverEnabled: true
                            preventStealing: true
                            drag.target: gridDragProxy
                            onPressed: function (mouse) {
                                root.forceActiveFocus();
                                var preserveSelection = root.isSelected(itemId) && !(mouse.modifiers & (Qt.ControlModifier | Qt.ShiftModifier));
                                if (!preserveSelection)
                                    root.selectOne(itemId, mouse.modifiers);
                                if (!root.isSelected(itemId))
                                    return;
                                var p = gridMouse.mapToItem(root.dragOverlay, mouse.x, mouse.y);
                                gridDragProxy.x = p.x;
                                gridDragProxy.y = p.y;
                                gridDragProxy.itemId = itemId;
                                gridDragProxy.itemIds = root.selectedIds.slice(0);
                                gridDragProxy.sourceId = record.sourceId ? String(record.sourceId) : "";
                                gridDragProxy.sourceIds = root.sourceIdsForItemIds(gridDragProxy.itemIds);
                            }
                            onPositionChanged: function (mouse) {
                                if (pressed) {
                                    var p = gridMouse.mapToItem(root.dragOverlay, mouse.x, mouse.y);
                                    gridDragProxy.x = p.x;
                                    gridDragProxy.y = p.y;
                                }
                            }
                            onReleased: if (drag.active)
                                gridDragProxy.Drag.drop()
                            onClicked: function (mouse) {
                                if (mouse.button === Qt.RightButton) {
                                    gridMenu.recordId = itemId;
                                    gridMenu.x = mouse.x;
                                    gridMenu.y = mouse.y;
                                    gridMenu.open();
                                }
                            }
                            onDoubleClicked: root.openSelected()
                        }
                        DropArea {
                            visible: root.isBin(record)
                            anchors.fill: parent
                            z: 3
                            objectName: "mediaGridBinDrop_" + itemId
                            keys: ["application/x-nemo-source", "application/x-nemo-source-id", "text/plain"]
                            onEntered: root.beginDropHover(itemId)
                            onExited: root.endDropHover(itemId)
                            onDropped: function (drop) {
                                root.handleDrop(itemId, drop);
                            }
                        }
                        Menu {
                            id: gridMenu
                            property string recordId: ""
                            objectName: "mediaGridMenu_" + itemId
                            MenuItem {
                                text: "Open in viewer"
                                enabled: !!root.itemById(gridMenu.recordId) && !root.isBin(root.itemById(gridMenu.recordId))
                                onTriggered: {
                                    root.selectedIds = [gridMenu.recordId];
                                    root.openSelected();
                                }
                            }
                            MenuItem {
                                text: "Insert at playhead"
                                enabled: root.sourceIdsForItemIds(root.selectedIds).length > 0
                                onTriggered: studio.mediaInsertRequested(root.panelGroup, root.sourceIdsForItemIds(root.selectedIds), "insert")
                            }
                            MenuItem {
                                text: "Overwrite at playhead"
                                enabled: root.sourceIdsForItemIds(root.selectedIds).length > 0
                                onTriggered: studio.mediaInsertRequested(root.panelGroup, root.sourceIdsForItemIds(root.selectedIds), "overwrite")
                            }
                            MenuItem {
                                text: "Metadata…"
                                enabled: !!root.itemById(gridMenu.recordId)
                                onTriggered: root.openMetadata(gridMenu.recordId)
                            }
                            MenuItem {
                                text: "Rename"
                                onTriggered: root.startRename(gridMenu.recordId)
                            }
                            MenuItem {
                                text: "Delete"
                                onTriggered: root.requestDelete([gridMenu.recordId])
                            }
                            MenuSeparator {
                            }
                            MenuItem {
                                text: "Import media…"
                                enabled: false
                            }
                            MenuItem {
                                text: "Relink media…"
                                enabled: false
                            }
                            MenuItem {
                                text: "Create proxy…"
                                enabled: false
                            }
                        }
                        Item {
                            id: gridDragProxy
                            property string itemId: ""
                            property var itemIds: []
                            property string sourceId: ""
                            property var sourceIds: []
                            parent: root.dragOverlay
                            width: 2
                            height: 2
                            Drag.active: gridMouse.drag.active
                            Drag.source: gridCell
                            Drag.keys: ["application/x-nemo-source", "application/x-nemo-source-id", "text/plain"]
                            Drag.supportedActions: Qt.CopyAction | Qt.MoveAction
                            Drag.proposedAction: Qt.CopyAction
                            Drag.mimeData: ({
                                    "itemId": itemId,
                                    "itemIds": itemIds,
                                    "sourceId": sourceId,
                                    "sourceIds": sourceIds,
                                    "application/x-nemo-source-id": sourceId
                                })
                        }
                    }
                    Text {
                        anchors.centerIn: parent
                        visible: gridView.count === 0
                        text: "No media in " + root.currentName()
                        color: theme.muted
                        font.pixelSize: theme.fontSize
                    }
                }
                DropArea {
                    anchors.fill: parent
                    z: 0
                    objectName: "mediaContentDropArea"
                    keys: ["application/x-nemo-source", "application/x-nemo-source-id", "text/plain"]
                    onEntered: root.beginDropHover(root.currentParentId)
                    onExited: root.endDropHover(root.currentParentId)
                    onDropped: function (drop) {
                        root.handleDrop(root.currentParentId, drop);
                    }
                }
            }
        }

        Label {
            id: statusLabel
            objectName: "mediaStatus"
            Layout.fillWidth: true
            visible: root.statusError && root.statusMessage.length > 0
            text: root.statusMessage
            color: theme.text
            elide: Text.ElideRight
            font.pixelSize: theme.fontSize - 1
        }
    }

    Menu {
        id: filterMenu
        objectName: "mediaFilterMenu"
        title: "Media filters"
        Menu {
            title: "Kind"
            MenuItem {
                text: "All"
                checkable: true
                checked: root.kindFilter === "all"
                onTriggered: {
                    root.leaveSmartBin();
                    root.kindFilter = "all";
                }
            }
            MenuItem {
                text: "Video"
                checkable: true
                checked: root.kindFilter === "video"
                onTriggered: {
                    root.leaveSmartBin();
                    root.kindFilter = "video";
                }
            }
            MenuItem {
                text: "Audio"
                checkable: true
                checked: root.kindFilter === "audio"
                onTriggered: {
                    root.leaveSmartBin();
                    root.kindFilter = "audio";
                }
            }
            MenuItem {
                text: "Still"
                checkable: true
                checked: root.kindFilter === "still"
                onTriggered: {
                    root.leaveSmartBin();
                    root.kindFilter = "still";
                }
            }
            MenuItem {
                text: "Bins"
                checkable: true
                checked: root.kindFilter === "bin"
                onTriggered: {
                    root.leaveSmartBin();
                    root.kindFilter = "bin";
                }
            }
        }
        MenuItem {
            text: "Unused only"
            checkable: true
            checked: root.unusedOnly
            onTriggered: {
                root.leaveSmartBin();
                root.unusedOnly = !root.unusedOnly;
            }
        }
        MenuItem {
            text: "Offline only"
            checkable: true
            checked: root.offlineOnly
            onTriggered: {
                root.leaveSmartBin();
                root.offlineOnly = !root.offlineOnly;
            }
        }
        MenuSeparator {
        }
        MenuItem {
            text: "Sort by name"
            checkable: true
            checked: root.sortField === "name"
            onTriggered: root.sortField = "name"
        }
        MenuItem {
            text: "Sort by type"
            checkable: true
            checked: root.sortField === "kind"
            onTriggered: root.sortField = "kind"
        }
        MenuItem {
            text: "Sort by duration"
            checkable: true
            checked: root.sortField === "duration"
            onTriggered: root.sortField = "duration"
        }
        MenuItem {
            text: "Reverse sort"
            checkable: true
            checked: root.sortDescending
            onTriggered: root.sortDescending = !root.sortDescending
        }
        MenuSeparator {
        }
        MenuItem {
            text: "Save current search as Smart Bin…"
            enabled: !root.currentSmartBinId
            onTriggered: root.beginSaveSmartBin()
        }
    }

    Menu {
        id: treeMenu
        property string recordId: "root"
        objectName: "mediaTreeMenu"
        MenuItem {
            text: "Open bin"
            onTriggered: root.openBin(treeMenu.recordId)
        }
        MenuItem {
            text: "New bin"
            onTriggered: root.beginCreate(treeMenu.recordId, false)
        }
        MenuItem {
            text: "New bin from selection"
            onTriggered: root.beginCreate(treeMenu.recordId, true)
        }
        MenuItem {
            text: "Rename"
            enabled: treeMenu.recordId !== "root"
            onTriggered: root.startRename(treeMenu.recordId)
        }
        MenuItem {
            text: "Delete"
            enabled: treeMenu.recordId !== "root"
            onTriggered: root.requestDelete([treeMenu.recordId])
        }
    }
    Dialog {
        id: renameDialog
        property string recordId: ""
        objectName: "mediaRenameDialog"
        title: "Rename item"
        modal: true
        width: 320
        standardButtons: Dialog.Ok | Dialog.Cancel
        contentItem: TextField {
            id: renameDialogField
            objectName: "mediaRenameField"
            implicitWidth: 280
            selectByMouse: true
            onAccepted: renameDialog.accept()
        }
        onAccepted: root.commitRename(recordId, renameDialogField.text)
    }

    Dialog {
        id: metadataDialog
        property string recordId: ""
        objectName: "mediaMetadataDialog"
        title: "Media metadata"
        modal: true
        width: 350
        standardButtons: Dialog.Ok | Dialog.Cancel
        contentItem: Column {
            spacing: 7
            width: 320
            Text {
                objectName: "mediaMetadataTitle"
                width: parent.width
                text: root.itemById(metadataDialog.recordId) ? String(root.itemById(metadataDialog.recordId).name || "") : ""
                color: theme.text
                font.bold: true
                elide: Text.ElideRight
            }
            TextField {
                id: metadataDialogField
                objectName: "mediaTagsField"
                width: parent.width
                placeholderText: "Tags, comma separated"
                selectByMouse: true
            }
            TextArea {
                id: metadataDescriptionField
                objectName: "mediaDescriptionField"
                width: parent.width
                height: 70
                placeholderText: "Description"
                wrapMode: TextEdit.Wrap
            }
            ComboBox {
                id: metadataLabelCombo
                objectName: "mediaLabelCombo"
                width: parent.width
                model: root.labelOptions
            }
            Row {
                spacing: 6
                Button {
                    text: "Import media…"
                    enabled: false
                    ToolTip.visible: hovered
                    ToolTip.text: "Import is unavailable in this prototype"
                }
                Button {
                    text: "Relink…"
                    enabled: false
                    ToolTip.visible: hovered
                    ToolTip.text: "Relink is unavailable in this prototype"
                }
                Button {
                    text: "Proxy…"
                    enabled: false
                    ToolTip.visible: hovered
                    ToolTip.text: "Proxy generation is unavailable in this prototype"
                }
            }
        }
        onAccepted: {
            root.applyMetadata(recordId, {
                    "tags": metadataDialogField.text.split(",").map(function (v) {
                            return v.trim();
                        }).filter(function (v) {
                            return v.length > 0;
                        }),
                    "description": metadataDescriptionField.text,
                    "color": metadataLabelCombo.currentText
                });
        }
    }

    Dialog {
        id: smartDialog
        property string mode: "save"
        property string smartId: ""
        property string name: ""
        property var query: ({})
        objectName: "mediaSmartBinDialog"
        title: mode === "rename" ? "Rename Smart Bin" : "Save Smart Bin"
        modal: true
        width: 320
        standardButtons: Dialog.Ok | Dialog.Cancel
        contentItem: TextField {
            id: smartNameField
            objectName: "mediaSmartBinNameField"
            implicitWidth: 280
            placeholderText: "Search name"
            selectByMouse: true
            onAccepted: smartDialog.accept()
        }
        onAccepted: root.finishSmartDialog()
    }

    Menu {
        id: smartMenu
        property string smartId: ""
        objectName: "mediaSmartBinMenu"
        MenuItem {
            text: "Open Smart Bin"
            onTriggered: root.openSmartBin(smartMenu.smartId)
        }
        MenuItem {
            text: "Rename search…"
            enabled: !!root.smartBinById(smartMenu.smartId) && !root.smartBinById(smartMenu.smartId).builtIn
            onTriggered: root.beginRenameSmartBin(smartMenu.smartId)
        }
        MenuItem {
            text: "Delete search"
            enabled: !!root.smartBinById(smartMenu.smartId) && !root.smartBinById(smartMenu.smartId).builtIn
            onTriggered: root.deleteSmartBin(smartMenu.smartId)
        }
    }

    Dialog {
        id: createBinDialog
        property string parentId: "root"
        property bool fromSelection: false
        objectName: "mediaCreateBinDialog"
        title: fromSelection ? "New bin from selection" : "New bin"
        modal: true
        standardButtons: Dialog.Ok | Dialog.Cancel
        contentItem: TextField {
            id: createBinField
            implicitWidth: 260
            placeholderText: "Bin name"
            selectByMouse: true
            onAccepted: createBinDialog.accept()
        }
        onAccepted: root.finishCreate()
    }

    Dialog {
        id: deleteDialog
        property var ids: []
        objectName: "mediaDeleteDialog"
        title: "Delete non-empty bin"
        modal: true
        width: 380
        standardButtons: Dialog.Cancel
        contentItem: Column {
            spacing: 8
            width: 350
            Text {
                width: parent.width
                wrapMode: Text.WordWrap
                text: "Deleting this bin can reparent its contents to the parent bin, or remove the contents too."
                color: theme.text
            }
            Row {
                spacing: 5
                Button {
                    objectName: "mediaDeleteKeepContents"
                    text: "Delete bin, keep contents"
                    onClicked: {
                        var idsToDelete = deleteDialog.ids;
                        deleteDialog.close();
                        if (root.applyCatalog({
                                "type": "remove",
                                "ids": idsToDelete,
                                "keepContents": true
                            }, "Deleted bin; kept contents"))
                            root.clearSelection();
                    }
                }
                Button {
                    objectName: "mediaDeleteContents"
                    text: "Delete contents"
                    onClicked: {
                        var idsToDelete = deleteDialog.ids;
                        deleteDialog.close();
                        if (root.applyCatalog({
                                "type": "remove",
                                "ids": idsToDelete,
                                "keepContents": false
                            }, "Deleted selection"))
                            root.clearSelection();
                    }
                }
            }
        }
    }

    Timer {
        id: statusTimer
        interval: 2800
        onTriggered: root.statusMessage = ""
    }
    Timer {
        id: hoverExpandTimer
        interval: 650
        onTriggered: {
            if (root.pendingHoverBinId && root.catalog && root.catalog.item(root.pendingHoverBinId)) {
                var nextExpanded = Object.assign({}, root.expandedBins);
                nextExpanded[root.pendingHoverBinId] = true;
                root.expandedBins = nextExpanded;
                root.pendingHoverBinId = "";
            }
        }
    }

    Connections {
        target: studio
        function onMediaInsertFinished(group, error) {
            if (group === root.panelGroup && error)
                root.setStatus(error, true);
        }
    }

    Connections {
        target: root.catalog
        ignoreUnknownSignals: true
        function onRevisionChanged() {
            root.catalogRevision = Number(root.catalog.revision || 0);
            root.selectedIds = root.normalizeIds(root.selectedIds);
            if (!root.itemById(root.currentParentId))
                root.currentParentId = "root";
        }
        function onErrorChanged() {
            if (root.catalog && root.catalog.error)
                root.setStatus(root.catalog.error, true);
        }
    }

    Keys.onPressed: function (event) {
        var key = event.key;
        var modifiers = event.modifiers;
        if ((modifiers & Qt.ControlModifier) && key === Qt.Key_A) {
            root.selectAll();
            event.accepted = true;
        } else if ((modifiers & Qt.ControlModifier) && key === Qt.Key_C) {
            root.copySelection(false);
            event.accepted = true;
        } else if ((modifiers & Qt.ControlModifier) && key === Qt.Key_X) {
            root.copySelection(true);
            event.accepted = true;
        } else if ((modifiers & Qt.ControlModifier) && key === Qt.Key_V) {
            root.pasteSelection();
            event.accepted = true;
        } else if ((modifiers & Qt.ControlModifier) && key === Qt.Key_Z && !(modifiers & Qt.ShiftModifier)) {
            if (root.catalog && root.catalog.undo)
                root.catalog.undo();
            event.accepted = true;
        } else if (((modifiers & Qt.ControlModifier) && key === Qt.Key_Z && (modifiers & Qt.ShiftModifier)) || ((modifiers & Qt.ShiftModifier) && key === Qt.Key_Z && !(modifiers & Qt.ControlModifier))) {
            if (root.catalog && root.catalog.redo)
                root.catalog.redo();
            event.accepted = true;
        } else if (key === Qt.Key_Delete) {
            root.deleteSelection();
            event.accepted = true;
        } else if (key === Qt.Key_F2 && root.selectedIds.length) {
            root.startRename(root.selectedIds[0]);
            event.accepted = true;
        } else if (key === Qt.Key_Escape) {
            root.clearSelection();
            event.accepted = true;
        }
    }

    Component.onCompleted: {
        if (root.catalog && root.catalog.item && !root.catalog.item("root"))
            root.setStatus("Media catalog is unavailable", true);
    }
}
