#!/usr/bin/env bash
set -euo pipefail
root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
# Reuse the pinned, header-only manifest dependency; never build the production app.
deps="${NEMO_PROTOTYPE_DEPS:-$root/../Nemo_Dev2/build/debug/vcpkg_installed/x64-linux}"
cmake -S "$root/apps/nemo-ui/prototype" -B "$root/build/viewer-prototype" -G Ninja -DCMAKE_PREFIX_PATH="$deps"
cmake --build "$root/build/viewer-prototype"
export QT_QPA_PLATFORM="${QT_QPA_PLATFORM:-wayland}"
export QT_QUICK_BACKEND="${QT_QUICK_BACKEND:-software}"
printf '%s\n' 'Viewer interaction prototype: simulated 24 fps transport, no media engine or saved workspace.'
exec "$root/build/viewer-prototype/nemo-viewer-prototype" "$@"
