import QtQuick

// Session-only, immutable-candidate timeline model.  The model owns all edit
// semantics; consumers submit operation objects and never mutate clip objects.
QtObject {
    id: root

    property int fps: 24
    property int startFrame: 1001
    property int inFrame: -1
    property int outFrame: -1
    property int revision: 0
    property string error: ""

    property var tracks: []
    property var clips: []
    property var sources: []

    property var _undo: []
    property var _redo: []
    property int _nextClipSeq: 1
    property int _nextTrackSeq: 1
    property int _nextLinkSeq: 1

    readonly property bool canUndo: _undo.length > 0
    readonly property bool canRedo: _redo.length > 0

    Component.onCompleted: _initialize()

    function _initialize() {
        sources = [{
                "id": "src-interview",
                "name": "Interview — Studio A",
                "kind": "video",
                "duration": 720,
                "color": "#6b86a8",
                "hasAudio": true
            }, {
                "id": "src-broll",
                "name": "B-Roll — City Walk",
                "kind": "video",
                "duration": 540,
                "color": "#759c7b",
                "hasAudio": true
            }, {
                "id": "src-screen",
                "name": "Screen Capture — Edit",
                "kind": "video",
                "duration": 900,
                "color": "#9a7eb5",
                "hasAudio": true
            }, {
                "id": "src-music",
                "name": "Music — Night Drive",
                "kind": "audio",
                "duration": 960,
                "color": "#b0845f",
                "hasAudio": false
            }, {
                "id": "src-room",
                "name": "Room Tone — Studio A",
                "kind": "audio",
                "duration": 1200,
                "color": "#657c83",
                "hasAudio": false
            }, {
                "id": "src-sfx",
                "name": "SFX — Camera Shutter",
                "kind": "audio",
                "duration": 240,
                "color": "#a66f75",
                "hasAudio": false
            }];
        tracks = [{
                "id": "track-v1",
                "name": "V1 · Picture",
                "kind": "video",
                "locked": false,
                "muted": false,
                "solo": false,
                "visible": true,
                "ripple": true,
                "targeted": true,
                "height": 44
            }, {
                "id": "track-v2",
                "name": "V2 · B-Roll",
                "kind": "video",
                "locked": false,
                "muted": false,
                "solo": false,
                "visible": true,
                "ripple": true,
                "targeted": false,
                "height": 44
            }, {
                "id": "track-v3",
                "name": "V3 · Graphics",
                "kind": "video",
                "locked": false,
                "muted": false,
                "solo": false,
                "visible": true,
                "ripple": true,
                "targeted": false,
                "height": 44
            }, {
                "id": "track-a1",
                "name": "A1 · Production",
                "kind": "audio",
                "locked": false,
                "muted": false,
                "solo": false,
                "visible": true,
                "ripple": true,
                "targeted": true,
                "height": 38
            }, {
                "id": "track-a2",
                "name": "A2 · Atmos",
                "kind": "audio",
                "locked": false,
                "muted": false,
                "solo": false,
                "visible": true,
                "ripple": true,
                "targeted": false,
                "height": 38
            }, {
                "id": "track-a3",
                "name": "A3 · Music & FX",
                "kind": "audio",
                "locked": false,
                "muted": false,
                "solo": false,
                "visible": true,
                "ripple": true,
                "targeted": false,
                "height": 38
            }];
        clips = [{
                "id": "clip-001",
                "trackId": "track-v1",
                "sourceId": "src-interview",
                "name": "Interview — opening",
                "start": 1001,
                "duration": 96,
                "sourceIn": 24,
                "sourceDuration": 720,
                "linkId": "link-001",
                "color": "#6b86a8"
            }, {
                "id": "clip-002",
                "trackId": "track-a1",
                "sourceId": "src-interview",
                "name": "Interview — opening",
                "start": 1001,
                "duration": 96,
                "sourceIn": 24,
                "sourceDuration": 720,
                "linkId": "link-001",
                "color": "#6b86a8"
            }, {
                "id": "clip-003",
                "trackId": "track-v1",
                "sourceId": "src-interview",
                "name": "Interview — pickup",
                "start": 1130,
                "duration": 72,
                "sourceIn": 180,
                "sourceDuration": 720,
                "linkId": "link-002",
                "color": "#6b86a8"
            }, {
                "id": "clip-004",
                "trackId": "track-a1",
                "sourceId": "src-interview",
                "name": "Interview — pickup",
                "start": 1130,
                "duration": 72,
                "sourceIn": 180,
                "sourceDuration": 720,
                "linkId": "link-002",
                "color": "#6b86a8"
            }, {
                "id": "clip-005",
                "trackId": "track-v2",
                "sourceId": "src-broll",
                "name": "B-Roll — street",
                "start": 1048,
                "duration": 80,
                "sourceIn": 60,
                "sourceDuration": 540,
                "linkId": "link-003",
                "color": "#759c7b"
            }, {
                "id": "clip-006",
                "trackId": "track-a2",
                "sourceId": "src-broll",
                "name": "B-Roll — street",
                "start": 1048,
                "duration": 80,
                "sourceIn": 60,
                "sourceDuration": 540,
                "linkId": "link-003",
                "color": "#759c7b"
            }, {
                "id": "clip-007",
                "trackId": "track-v3",
                "sourceId": "src-screen",
                "name": "Screen Capture — cutaway",
                "start": 1204,
                "duration": 90,
                "sourceIn": 40,
                "sourceDuration": 900,
                "linkId": "link-004",
                "color": "#9a7eb5"
            }, {
                "id": "clip-008",
                "trackId": "track-a3",
                "sourceId": "src-music",
                "name": "Night Drive — bed",
                "start": 1020,
                "duration": 140,
                "sourceIn": 12,
                "sourceDuration": 960,
                "linkId": "",
                "color": "#b0845f"
            }, {
                "id": "clip-009",
                "trackId": "track-a2",
                "sourceId": "src-room",
                "name": "Room Tone — bed",
                "start": 1160,
                "duration": 100,
                "sourceIn": 80,
                "sourceDuration": 1200,
                "linkId": "",
                "color": "#657c83"
            }, {
                "id": "clip-010",
                "trackId": "track-a3",
                "sourceId": "src-sfx",
                "name": "Camera Shutter",
                "start": 1220,
                "duration": 24,
                "sourceIn": 10,
                "sourceDuration": 240,
                "linkId": "",
                "color": "#a66f75"
            }];
        _nextClipSeq = 11;
        _nextTrackSeq = 1;
        _nextLinkSeq = 5;
        _undo = [];
        _redo = [];
        revision = 0;
        error = "";
    }

    function _cloneTrack(t) {
        return {
            "id": t.id,
            "name": t.name,
            "kind": t.kind,
            "locked": !!t.locked,
            "muted": !!t.muted,
            "solo": !!t.solo,
            "visible": !!t.visible,
            "ripple": t.ripple !== false,
            "targeted": !!t.targeted,
            "height": t.height
        };
    }

    function _cloneClip(c) {
        return {
            "id": c.id,
            "trackId": c.trackId,
            "sourceId": c.sourceId,
            "name": c.name,
            "start": c.start,
            "duration": c.duration,
            "sourceIn": c.sourceIn,
            "sourceDuration": c.sourceDuration,
            "linkId": c.linkId || "",
            "color": c.color
        };
    }

    function _cloneTracks(a) {
        var out = [];
        for (var i = 0; i < (a || []).length; ++i)
            out.push(_cloneTrack(a[i]));
        return out;
    }

    function _cloneClips(a) {
        var out = [];
        for (var i = 0; i < (a || []).length; ++i)
            out.push(_cloneClip(a[i]));
        return out;
    }

    function _snapshot() {
        return {
            "tracks": _cloneTracks(tracks),
            "clips": _cloneClips(clips),
            "inFrame": inFrame,
            "outFrame": outFrame,
            "nextClipSeq": _nextClipSeq,
            "nextTrackSeq": _nextTrackSeq,
            "nextLinkSeq": _nextLinkSeq
        };
    }

    function _restore(s) {
        tracks = _cloneTracks(s.tracks);
        clips = _cloneClips(s.clips);
        inFrame = s.inFrame;
        outFrame = s.outFrame;
        // Allocation counters are session-global high-water marks. Undoing
        // sequence content must never make a later edit reuse an old ID.
        _nextClipSeq = Math.max(_nextClipSeq, s.nextClipSeq);
        _nextTrackSeq = Math.max(_nextTrackSeq, s.nextTrackSeq);
        _nextLinkSeq = Math.max(_nextLinkSeq, s.nextLinkSeq);
        revision += 1;
        error = "";
    }

    function _source(id) {
        for (var i = 0; i < sources.length; ++i)
            if (sources[i].id === id)
                return sources[i];
        return null;
    }

    function _track(s, id) {
        for (var i = 0; i < s.tracks.length; ++i)
            if (s.tracks[i].id === id)
                return s.tracks[i];
        return null;
    }

    function _clip(s, id) {
        for (var i = 0; i < s.clips.length; ++i)
            if (s.clips[i].id === id)
                return s.clips[i];
        return null;
    }

    function _trackIndex(s, id) {
        for (var i = 0; i < s.tracks.length; ++i)
            if (s.tracks[i].id === id)
                return i;
        return -1;
    }

    function _sameState(a, b) {
        return JSON.stringify({
                "tracks": a.tracks,
                "clips": a.clips,
                "inFrame": a.inFrame,
                "outFrame": a.outFrame
            }) === JSON.stringify({
                "tracks": b.tracks,
                "clips": b.clips,
                "inFrame": b.inFrame,
                "outFrame": b.outFrame
            });
    }

    function _isInt(v) {
        return typeof v === "number" && isFinite(v) && Math.floor(v) === v;
    }

    function _fail(message) {
        return {
            "ok": false,
            "error": message || "Edit rejected"
        };
    }

    function _ok(s) {
        return {
            "ok": true,
            "state": s,
            "error": ""
        };
    }

    function _newClipId(s) {
        var id = "clip-" + s.nextClipSeq;
        s.nextClipSeq += 1;
        return id;
    }

    function _newTrackId(s) {
        var id = "track-new-" + s.nextTrackSeq;
        s.nextTrackSeq += 1;
        return id;
    }

    function _newLinkId(s) {
        var id = "link-new-" + s.nextLinkSeq;
        s.nextLinkSeq += 1;
        return id;
    }

    function _uniqueIds(ids) {
        var out = [];
        var seen = {};
        for (var i = 0; i < (ids || []).length; ++i) {
            var id = ids[i];
            if (typeof id !== "string" || !id.length || seen[id])
                continue;
            seen[id] = true;
            out.push(id);
        }
        return out;
    }

    function _expandLinked(s, ids, linked) {
        var out = _uniqueIds(ids);
        if (linked === false)
            return out;
        var changed = true;
        while (changed) {
            changed = false;
            for (var i = 0; i < s.clips.length; ++i) {
                var c = s.clips[i];
                if (!c.linkId)
                    continue;
                var included = false;
                for (var j = 0; j < out.length; ++j)
                    if (out[j] === c.id) {
                        included = true;
                        break;
                    }
                if (included)
                    continue;
                for (j = 0; j < out.length; ++j) {
                    var selected = _clip(s, out[j]);
                    if (selected && selected.linkId === c.linkId) {
                        out.push(c.id);
                        changed = true;
                        break;
                    }
                }
            }
        }
        return out;
    }

    function _groupIds(s, linkId) {
        var out = [];
        for (var i = 0; i < s.clips.length; ++i)
            if (linkId && s.clips[i].linkId === linkId)
                out.push(s.clips[i].id);
        return out;
    }

    function _idsSet(ids) {
        var out = {};
        for (var i = 0; i < ids.length; ++i)
            out[ids[i]] = true;
        return out;
    }

    function _kindTracks(s, kind) {
        var out = [];
        for (var i = 0; i < s.tracks.length; ++i)
            if (s.tracks[i].kind === kind)
                out.push(s.tracks[i]);
        return out;
    }

    function _compatibleTrack(s, clip, track) {
        var source = _source(clip.sourceId);
        if (!source || !track)
            return false;
        if (source.kind === "audio")
            return track.kind === "audio";
        if (source.kind === "video")
            return track.kind === "video" || (track.kind === "audio" && source.hasAudio);
        return false;
    }

    function _trackAtDelta(s, oldTrack, delta) {
        var list = _kindTracks(s, oldTrack.kind);
        var pos = -1;
        for (var i = 0; i < list.length; ++i)
            if (list[i].id === oldTrack.id) {
                pos = i;
                break;
            }
        var next = pos + delta;
        if (pos < 0 || next < 0 || next >= list.length)
            return null;
        return list[next];
    }

    function _ensureIds(s, ids) {
        if (!ids.length)
            return _fail("No clips selected");
        for (var i = 0; i < ids.length; ++i)
            if (!_clip(s, ids[i]))
                return _fail("Unknown clip " + ids[i]);
        return _ok(s);
    }

    function _ensureUnlocked(s, ids) {
        for (var i = 0; i < ids.length; ++i) {
            var c = _clip(s, ids[i]);
            var t = c ? _track(s, c.trackId) : null;
            if (t && t.locked)
                return _fail("Clip " + c.id + " is on locked track " + t.id);
        }
        return _ok(s);
    }

    function _sortState(s) {
        s.clips.sort(function (a, b) {
                var ta = _trackIndex(s, a.trackId);
                var tb = _trackIndex(s, b.trackId);
                if (ta !== tb)
                    return ta - tb;
                if (a.start !== b.start)
                    return a.start - b.start;
                return a.id < b.id ? -1 : (a.id > b.id ? 1 : 0);
            });
    }

    function _validateState(s) {
        var trackIds = {};
        for (var i = 0; i < s.tracks.length; ++i) {
            var t = s.tracks[i];
            if (!t || typeof t.id !== "string" || !t.id.length || trackIds[t.id])
                return _fail("Track IDs must be unique");
            trackIds[t.id] = true;
            if (t.kind !== "video" && t.kind !== "audio")
                return _fail("Track " + t.id + " has an invalid kind");
            if (!isFinite(t.height) || !_isInt(t.height) || t.height < 24)
                return _fail("Track " + t.id + " has an invalid height");
        }
        var clipIds = {};
        var byTrack = {};
        for (i = 0; i < s.clips.length; ++i) {
            var c = s.clips[i];
            if (!c || typeof c.id !== "string" || !c.id.length || clipIds[c.id])
                return _fail("Clip IDs must be unique");
            clipIds[c.id] = true;
            var track = _track(s, c.trackId);
            var source = _source(c.sourceId);
            if (!track)
                return _fail("Clip " + c.id + " references missing track " + c.trackId);
            if (!source)
                return _fail("Clip " + c.id + " references missing source " + c.sourceId);
            if (!_isInt(c.start) || c.start < root.startFrame)
                return _fail("Clip " + c.id + " has an invalid start");
            if (!_isInt(c.duration) || c.duration <= 0)
                return _fail("Clip " + c.id + " has an invalid duration");
            if (!_isInt(c.sourceIn) || c.sourceIn < 0)
                return _fail("Clip " + c.id + " has an invalid source offset");
            if (!_isInt(c.sourceDuration) || c.sourceDuration <= 0 || c.sourceDuration > source.duration)
                return _fail("Clip " + c.id + " has an invalid source duration");
            if (c.sourceIn + c.duration > c.sourceDuration)
                return _fail("Clip " + c.id + " runs past its source handle");
            if (!_compatibleTrack(s, c, track))
                return _fail("Clip " + c.id + " is incompatible with track " + track.id);
            if (!byTrack[c.trackId])
                byTrack[c.trackId] = [];
            byTrack[c.trackId].push(c);
        }
        for (var trackId in byTrack) {
            var list = byTrack[trackId];
            list.sort(function (a, b) {
                    return a.start - b.start;
                });
            for (i = 1; i < list.length; ++i)
                if (list[i - 1].start + list[i - 1].duration > list[i].start)
                    return _fail("Clips overlap on track " + trackId);
        }
        if (!(s.inFrame === -1 || (_isInt(s.inFrame) && s.inFrame >= root.startFrame)))
            return _fail("Invalid in mark");
        if (!(s.outFrame === -1 || (_isInt(s.outFrame) && s.outFrame >= root.startFrame)))
            return _fail("Invalid out mark");
        if (s.inFrame !== -1 && s.outFrame !== -1 && s.inFrame > s.outFrame)
            return _fail("In mark must not follow out mark");
        return _ok(s);
    }

    function _move(s, o) {
        var ids = _expandLinked(s, o.ids || [], o.linked);
        var good = _ensureIds(s, ids);
        if (!good.ok)
            return good;
        var delta = o.delta === undefined ? 0 : o.delta;
        var trackDelta = o.trackDelta === undefined ? 0 : o.trackDelta;
        if (!_isInt(delta) || !_isInt(trackDelta))
            return _fail("Move offsets must be integers");
        good = _ensureUnlocked(s, ids);
        if (!good.ok)
            return good;
        var set = _idsSet(ids);
        var targetTracks = {};
        for (var i = 0; i < ids.length; ++i) {
            var c = _clip(s, ids[i]);
            var oldTrack = _track(s, c.trackId);
            var target = _trackAtDelta(s, oldTrack, trackDelta);
            if (!target)
                return _fail("Move leaves available " + oldTrack.kind + " tracks");
            if (target.locked)
                return _fail("Move targets locked track " + target.id);
            if (!_compatibleTrack(s, c, target))
                return _fail("Clip " + c.id + " cannot move to " + target.id);
            targetTracks[c.id] = target.id;
        }
        for (i = 0; i < s.clips.length; ++i) {
            var moving = s.clips[i];
            if (!set[moving.id])
                continue;
            moving.start += delta;
            moving.trackId = targetTracks[moving.id];
        }
        _sortState(s);
        return _ok(s);
    }

    function _adjustTrim(c, edge, delta) {
        if (edge === "in") {
            c.start += delta;
            c.duration -= delta;
            c.sourceIn += delta;
        } else {
            c.duration += delta;
        }
    }

    function _rippleShifts(s, excluded, events) {
        var shifts = {};
        var excludedSet = _idsSet(excluded);
        for (var i = 0; i < s.clips.length; ++i) {
            var c = s.clips[i];
            if (excludedSet[c.id])
                continue;
            var t = _track(s, c.trackId);
            var shift = 0;
            for (var j = 0; j < events.length; ++j)
                if (c.start >= events[j].boundary)
                    shift += events[j].amount;
            if (!shift)
                continue;
            if (t.ripple === false)
                continue;
            if (t.locked)
                return _fail("Ripple crosses locked track " + t.id);
            shifts[c.id] = shift;
        }
        // A linked group may never be shifted on only one side.
        for (i = 0; i < s.clips.length; ++i) {
            c = s.clips[i];
            if (!c.linkId || excludedSet[c.id])
                continue;
            if (shifts[c.id] === undefined)
                continue;
            var group = _groupIds(s, c.linkId);
            var amount = shifts[c.id];
            for (j = 0; j < group.length; ++j) {
                if (excludedSet[group[j]])
                    continue;
                if (shifts[group[j]] === undefined)
                    shifts[group[j]] = 0;
                if (shifts[group[j]] !== amount)
                    return _fail("Ripple would split linked clip " + c.linkId);
            }
        }
        return {
            "ok": true,
            "shifts": shifts
        };
    }

    function _trim(s, o, ripple) {
        var ids = _expandLinked(s, [o.id], o.linked);
        var good = _ensureIds(s, ids);
        if (!good.ok)
            return good;
        var edge = o.edge;
        var delta = o.delta;
        if ((edge !== "in" && edge !== "out") || !_isInt(delta))
            return _fail("Trim requires an in/out edge and integer delta");
        good = _ensureUnlocked(s, ids);
        if (!good.ok)
            return good;
        var anchor = _clip(s, o.id);
        var events = [{
                "boundary": anchor.start + anchor.duration,
                "amount": edge === "in" ? -delta : delta
            }];
        for (var i = 0; i < ids.length; ++i) {
            var c = _clip(s, ids[i]);
            _adjustTrim(c, edge, delta);
            if (ripple && edge === "in")
                c.start -= delta;
        }
        if (ripple) {
            var shifts = _rippleShifts(s, ids, events);
            if (!shifts.ok)
                return shifts;
            for (i = 0; i < s.clips.length; ++i)
                if (shifts.shifts[s.clips[i].id])
                    s.clips[i].start += shifts.shifts[s.clips[i].id];
        }
        _sortState(s);
        return _ok(s);
    }

    function _neighbor(s, c, before, excluded) {
        var best = null;
        var end = c.start + c.duration;
        for (var i = 0; i < s.clips.length; ++i) {
            var other = s.clips[i];
            if (other.trackId !== c.trackId || (excluded && excluded[other.id]))
                continue;
            if (before) {
                if (other.start + other.duration === c.start && (!best || other.start > best.start))
                    best = other;
            } else if (other.start === end && (!best || other.start < best.start)) {
                best = other;
            }
        }
        return best;
    }

    function _applyGroupMods(s, mods) {
        for (var i = 0; i < s.clips.length; ++i) {
            var c = s.clips[i];
            var m = mods[c.id];
            if (!m)
                continue;
            c.start += m.move;
            c.duration += m.duration;
            c.sourceIn += m.sourceIn;
        }
    }

    function _addGroupMod(s, mods, id, move, duration, sourceIn, linked) {
        var ids = _expandLinked(s, [id], linked);
        for (var i = 0; i < ids.length; ++i)
            mods[ids[i]] = {
                "move": move,
                "duration": duration,
                "sourceIn": sourceIn
            };
    }

    function _roll(s, o) {
        var ids = _expandLinked(s, [o.id], o.linked);
        var good = _ensureIds(s, ids);
        if (!good.ok)
            return good;
        if ((o.edge !== "in" && o.edge !== "out") || !_isInt(o.delta))
            return _fail("Roll requires an in/out edge and integer delta");
        good = _ensureUnlocked(s, ids);
        if (!good.ok)
            return good;
        var selected = _idsSet(ids);
        var mods = {};
        for (var i = 0; i < ids.length; ++i) {
            var c = _clip(s, ids[i]);
            var adjacent = _neighbor(s, c, o.edge === "in", selected);
            if (!adjacent)
                return _fail("No adjacent clip to roll against " + c.id);
            var at = _track(s, adjacent.trackId);
            if (at.locked)
                return _fail("Roll touches locked track " + at.id);
            if (o.edge === "out") {
                _addGroupMod(s, mods, c.id, 0, o.delta, 0, o.linked);
                _addGroupMod(s, mods, adjacent.id, o.delta, -o.delta, o.delta, o.linked);
            } else {
                _addGroupMod(s, mods, adjacent.id, 0, o.delta, 0, o.linked);
                _addGroupMod(s, mods, c.id, o.delta, -o.delta, o.delta, o.linked);
            }
        }
        good = _ensureUnlocked(s, Object.keys(mods));
        if (!good.ok)
            return good;
        _applyGroupMods(s, mods);
        _sortState(s);
        return _ok(s);
    }

    function _slip(s, o) {
        var ids = _expandLinked(s, [o.id], o.linked);
        var good = _ensureIds(s, ids);
        if (!good.ok)
            return good;
        if (!_isInt(o.delta))
            return _fail("Slip offset must be an integer");
        good = _ensureUnlocked(s, ids);
        if (!good.ok)
            return good;
        for (var i = 0; i < ids.length; ++i)
            _clip(s, ids[i]).sourceIn += o.delta;
        return _ok(s);
    }

    function _slide(s, o) {
        var ids = _expandLinked(s, [o.id], o.linked);
        var good = _ensureIds(s, ids);
        if (!good.ok)
            return good;
        if (!_isInt(o.delta))
            return _fail("Slide offset must be an integer");
        good = _ensureUnlocked(s, ids);
        if (!good.ok)
            return good;
        var selected = _idsSet(ids);
        var mods = {};
        for (var i = 0; i < ids.length; ++i) {
            var c = _clip(s, ids[i]);
            var before = _neighbor(s, c, true, selected);
            var after = _neighbor(s, c, false, selected);
            if (!before || !after)
                return _fail("Slide requires clips on both sides of " + c.id);
            if (_track(s, before.trackId).locked || _track(s, after.trackId).locked)
                return _fail("Slide touches a locked track");
            _addGroupMod(s, mods, c.id, o.delta, 0, 0, o.linked);
            _addGroupMod(s, mods, before.id, 0, o.delta, 0, o.linked);
            _addGroupMod(s, mods, after.id, o.delta, -o.delta, o.delta, o.linked);
        }
        good = _ensureUnlocked(s, Object.keys(mods));
        if (!good.ok)
            return good;
        _applyGroupMods(s, mods);
        _sortState(s);
        return _ok(s);
    }

    function _cut(s, o) {
        var ids = _expandLinked(s, o.ids || [], o.linked);
        var good = _ensureIds(s, ids);
        if (!good.ok)
            return good;
        if (!_isInt(o.frame))
            return _fail("Cut frame must be an integer");
        good = _ensureUnlocked(s, ids);
        if (!good.ok)
            return good;
        var groups = {};
        for (var i = 0; i < ids.length; ++i) {
            var c = _clip(s, ids[i]);
            if (o.frame <= c.start || o.frame >= c.start + c.duration)
                return _fail("Cut frame is outside " + c.id);
            if (c.linkId)
                groups[c.linkId] = true;
        }
        var rightLinks = {};
        var additions = [];
        for (i = 0; i < ids.length; ++i) {
            c = _clip(s, ids[i]);
            var oldEnd = c.start + c.duration;
            var leftDuration = o.frame - c.start;
            var rightDuration = oldEnd - o.frame;
            c.duration = leftDuration;
            var right = _cloneClip(c);
            right.id = _newClipId(s);
            right.start = o.frame;
            right.duration = rightDuration;
            right.sourceIn = c.sourceIn + leftDuration;
            if (c.linkId) {
                if (!rightLinks[c.linkId])
                    rightLinks[c.linkId] = _newLinkId(s);
                right.linkId = rightLinks[c.linkId];
            }
            additions.push(right);
        }
        for (i = 0; i < additions.length; ++i)
            s.clips.push(additions[i]);
        _sortState(s);
        return _ok(s);
    }

    function _delete(s, o) {
        var ids = _expandLinked(s, o.ids || [], o.linked);
        var good = _ensureIds(s, ids);
        if (!good.ok)
            return good;
        good = _ensureUnlocked(s, ids);
        if (!good.ok)
            return good;
        var selected = _idsSet(ids);
        var intervals = ids.map(function (id) {
                var c = _clip(s, id);
                return {
                    "start": c.start,
                    "end": c.start + c.duration
                };
            }).sort(function (a, b) {
                return a.start - b.start;
            });
        var ranges = [];
        for (var i = 0; i < intervals.length; ++i) {
            var previous = ranges.length ? ranges[ranges.length - 1] : null;
            if (previous && intervals[i].start <= previous.end)
                previous.end = Math.max(previous.end, intervals[i].end);
            else
                ranges.push(intervals[i]);
        }
        s.clips = s.clips.filter(function (c) {
                return !selected[c.id];
            });
        if (o.ripple) {
            for (i = 0; i < s.clips.length; ++i) {
                var remaining = s.clips[i];
                if (_track(s, remaining.trackId).ripple === false)
                    continue;
                for (var j = 0; j < ranges.length; ++j)
                    if (remaining.start < ranges[j].end && remaining.start + remaining.duration > ranges[j].start)
                        return _fail("Ripple deletion intersects unselected clip " + remaining.id + " on track " + remaining.trackId);
            }
            var events = ranges.map(function (r) {
                    return {
                        "boundary": r.end,
                        "amount": r.start - r.end
                    };
                });
            var result = _rippleShifts(s, [], events);
            if (!result.ok)
                return result;
            for (i = 0; i < s.clips.length; ++i)
                s.clips[i].start += result.shifts[s.clips[i].id] || 0;
        }
        _sortState(s);
        return _ok(s);
    }

    function _gapPlans(s, frame, amount, targetTracks) {
        var plans = {};
        var targets = _idsSet(targetTracks);
        for (var i = 0; i < s.clips.length; ++i) {
            var c = s.clips[i];
            var t = _track(s, c.trackId);
            var action = "none";
            if (c.start < frame && frame < c.start + c.duration)
                action = "split";
            else if (c.start >= frame)
                action = "shift";
            if (action !== "none") {
                if (t.ripple === false && !targets[t.id])
                    action = "none";
                else if (t.locked)
                    return _fail("Insert crosses locked track " + t.id);
            }
            plans[c.id] = {
                "action": action,
                "shift": action === "none" ? 0 : amount
            };
        }
        for (i = 0; i < s.clips.length; ++i) {
            c = s.clips[i];
            if (!c.linkId || plans[c.id].action === "none")
                continue;
            var ids = _groupIds(s, c.linkId);
            for (var j = 0; j < ids.length; ++j) {
                var p = plans[ids[j]];
                if (!p || p.action !== plans[c.id].action || p.shift !== plans[c.id].shift)
                    return _fail("Insert would split linked clip " + c.linkId);
            }
        }
        return {
            "ok": true,
            "plans": plans
        };
    }

    function _insertGap(s, frame, amount, targetTracks) {
        if (!_isInt(frame) || !_isInt(amount) || amount <= 0)
            return _fail("Insert gap must be positive integer timing");
        var result = _gapPlans(s, frame, amount, targetTracks);
        if (!result.ok)
            return result;
        var additions = [];
        var rightLinks = {};
        for (var i = 0; i < s.clips.length; ++i) {
            var c = s.clips[i];
            var plan = result.plans[c.id];
            if (plan.action === "shift") {
                c.start += amount;
            } else if (plan.action === "split") {
                var oldEnd = c.start + c.duration;
                var leftDuration = frame - c.start;
                var rightDuration = oldEnd - frame;
                c.duration = leftDuration;
                var right = _cloneClip(c);
                right.id = _newClipId(s);
                right.start = frame + amount;
                right.duration = rightDuration;
                right.sourceIn = c.sourceIn + leftDuration;
                if (c.linkId) {
                    if (!rightLinks[c.linkId])
                        rightLinks[c.linkId] = _newLinkId(s);
                    right.linkId = rightLinks[c.linkId];
                }
                additions.push(right);
            }
        }
        for (i = 0; i < additions.length; ++i)
            s.clips.push(additions[i]);
        _sortState(s);
        return _ok(s);
    }

    function _validInsertClip(s, sourceId, trackId, sourceIn, duration) {
        var source = _source(sourceId);
        var track = _track(s, trackId);
        if (!source)
            return _fail("Unknown source " + sourceId);
        if (!track)
            return _fail("Unknown track " + trackId);
        if (!_isInt(sourceIn) || !_isInt(duration) || sourceIn < 0 || duration <= 0)
            return _fail("Insert timing must be positive integers");
        if (sourceIn + duration > source.duration)
            return _fail("Insert exceeds source duration");
        var probe = {
            "sourceId": sourceId
        };
        if (!_compatibleTrack(s, probe, track))
            return _fail("Source cannot be placed on track " + trackId);
        if (track.locked)
            return _fail("Track " + trackId + " is locked");
        return {
            "ok": true,
            "source": source,
            "track": track
        };
    }

    function _matchingAudioTrack(s) {
        var list = _kindTracks(s, "audio");
        for (var i = 0; i < list.length; ++i)
            if (list[i].targeted)
                return list[i].locked ? null : list[i];
        return null;
    }

    function _makeClip(s, source, trackId, frame, sourceIn, duration, linkId) {
        return {
            "id": _newClipId(s),
            "trackId": trackId,
            "sourceId": source.id,
            "name": source.name,
            "start": frame,
            "duration": duration,
            "sourceIn": sourceIn,
            "sourceDuration": source.duration,
            "linkId": linkId || "",
            "color": source.color
        };
    }

    function _overwriteRange(s, frame, duration, trackIds) {
        var end = frame + duration;
        var targetTracks = _idsSet(trackIds);
        var affected = [];
        var affectedSet = {};
        for (var i = 0; i < s.clips.length; ++i) {
            var c = s.clips[i];
            if (!targetTracks[c.trackId] || c.start >= end || c.start + c.duration <= frame)
                continue;
            if (c.linkId) {
                var group = _groupIds(s, c.linkId);
                for (var g = 0; g < group.length; ++g) {
                    var member = _clip(s, group[g]);
                    if (member && !targetTracks[member.trackId])
                        return _fail("Overwrite would affect linked clip " + member.id + " on untargeted track " + member.trackId);
                    if (!member || member.start >= end || member.start + member.duration <= frame)
                        return _fail("Overwrite range does not align with linked clip " + c.linkId);
                    if (!affectedSet[member.id]) {
                        affectedSet[member.id] = true;
                        affected.push(member.id);
                    }
                }
            } else if (!affectedSet[c.id]) {
                affectedSet[c.id] = true;
                affected.push(c.id);
            }
        }
        for (i = 0; i < affected.length; ++i) {
            c = _clip(s, affected[i]);
            var t = _track(s, c.trackId);
            if (t.locked)
                return _fail("Overwrite touches locked track " + t.id);
        }
        var remove = {};
        var additions = [];
        var rightLinks = {};
        for (i = 0; i < affected.length; ++i) {
            c = _clip(s, affected[i]);
            var oldStart = c.start;
            var oldEnd = c.start + c.duration;
            var left = Math.max(0, frame - oldStart);
            var right = Math.max(0, oldEnd - end);
            if (!left && !right) {
                remove[c.id] = true;
            } else if (left && right) {
                c.duration = left;
                var rightClip = _cloneClip(c);
                rightClip.id = _newClipId(s);
                rightClip.start = end;
                rightClip.duration = right;
                rightClip.sourceIn = c.sourceIn + (end - oldStart);
                if (c.linkId) {
                    if (!rightLinks[c.linkId])
                        rightLinks[c.linkId] = _newLinkId(s);
                    rightClip.linkId = rightLinks[c.linkId];
                }
                additions.push(rightClip);
            } else if (left) {
                c.duration = left;
            } else {
                c.start = end;
                c.sourceIn += end - oldStart;
                c.duration = right;
            }
        }
        var kept = [];
        for (i = 0; i < s.clips.length; ++i)
            if (!remove[s.clips[i].id])
                kept.push(s.clips[i]);
        for (i = 0; i < additions.length; ++i)
            kept.push(additions[i]);
        s.clips = kept;
        _sortState(s);
        return _ok(s);
    }

    function _insert(s, o) {
        var sourceIn = o.sourceIn === undefined ? 0 : o.sourceIn;
        var duration = o.duration;
        var frame = o.frame;
        if (!_isInt(frame))
            return _fail("Insert frame must be an integer");
        var valid = _validInsertClip(s, o.sourceId, o.trackId, sourceIn, duration);
        if (!valid.ok)
            return valid;
        var source = valid.source;
        var primary = valid.track;
        var targetTracks = [primary.id];
        var audioTrack = null;
        if (source.kind === "video" && source.hasAudio) {
            if (primary.kind !== "video")
                return _fail("Audio-bearing video must target a video track");
            audioTrack = _matchingAudioTrack(s);
            if (!audioTrack)
                return _fail("No unlocked targeted audio track for linked media");
            targetTracks.push(audioTrack.id);
        }
        if (o.type === "insert") {
            var gap = _insertGap(s, frame, duration, targetTracks);
            if (!gap.ok)
                return gap;
        } else if (o.type === "overwrite") {
            var erased = _overwriteRange(s, frame, duration, targetTracks);
            if (!erased.ok)
                return erased;
        } else {
            return _fail("Insert mode must be insert or overwrite");
        }
        var link = source.kind === "video" && source.hasAudio ? _newLinkId(s) : "";
        s.clips.push(_makeClip(s, source, primary.id, frame, sourceIn, duration, link));
        if (audioTrack)
            s.clips.push(_makeClip(s, source, audioTrack.id, frame, sourceIn, duration, link));
        _sortState(s);
        return _ok(s);
    }

    function _pasteTrack(s, sourceTrackId, delta) {
        var sourceTrack = _track(s, sourceTrackId);
        return sourceTrack ? _trackAtDelta(s, sourceTrack, delta) : null;
    }

    function _paste(s, o) {
        var input = o.clips || [];
        if (!input.length || !_isInt(o.frame))
            return _fail("Paste requires clips and an integer frame");
        var baseTrack = _track(s, o.trackId);
        if (!baseTrack)
            return _fail("Unknown paste track " + o.trackId);
        var destinationKindTracks = _kindTracks(s, baseTrack.kind);
        var originRank = -1;
        for (var rank = 0; rank < destinationKindTracks.length; ++rank) {
            for (var inputIndex = 0; inputIndex < input.length; ++inputIndex)
                if (input[inputIndex].trackId === destinationKindTracks[rank].id && (originRank < 0 || rank < originRank))
                    originRank = rank;
        }
        if (originRank < 0)
            return _fail("Clipboard has no " + baseTrack.kind + " clip for target " + baseTrack.id);
        var destinationRank = destinationKindTracks.indexOf(baseTrack);
        var trackDelta = destinationRank - originRank;
        var minStart = null;
        var maxEnd = null;
        var prepared = [];
        for (var i = 0; i < input.length; ++i) {
            var p = input[i];
            var source = _source(p.sourceId);
            if (!source || !_isInt(p.start) || !_isInt(p.duration) || p.duration <= 0 || !_isInt(p.sourceIn) || p.sourceIn < 0 || p.sourceIn + p.duration > source.duration)
                return _fail("Invalid pasted clip snapshot");
            var target = _pasteTrack(s, p.trackId, trackDelta);
            if (!target || target.locked || !_compatibleTrack(s, p, target))
                return _fail("Pasted clip cannot use target track");
            if (minStart === null || p.start < minStart)
                minStart = p.start;
            if (maxEnd === null || p.start + p.duration > maxEnd)
                maxEnd = p.start + p.duration;
            prepared.push({
                    "p": p,
                    "source": source,
                    "track": target
                });
        }
        var span = maxEnd - minStart;
        if (o.mode === "insert") {
            var gap = _insertGap(s, o.frame, span, prepared.map(function (entry) {
                        return entry.track.id;
                    }));
            if (!gap.ok)
                return gap;
        } else if (o.mode !== "overwrite") {
            return _fail("Paste mode must be insert or overwrite");
        }
        var linkMap = {};
        var desired = [];
        var erasedRanges = {};
        for (i = 0; i < prepared.length; ++i) {
            var item = prepared[i];
            var p = item.p;
            if (o.mode === "overwrite") {
                var rangeKey = p.start + ":" + p.duration;
                if (!erasedRanges[rangeKey]) {
                    var rangeTracks = prepared.filter(function (entry) {
                            return entry.p.start === p.start && entry.p.duration === p.duration;
                        }).map(function (entry) {
                            return entry.track.id;
                        });
                    var erased = _overwriteRange(s, o.frame + p.start - minStart, p.duration, rangeTracks);
                    if (!erased.ok)
                        return erased;
                    erasedRanges[rangeKey] = true;
                }
            }
            var link = "";
            if (p.linkId) {
                if (!linkMap[p.linkId])
                    linkMap[p.linkId] = _newLinkId(s);
                link = linkMap[p.linkId];
            }
            desired.push({
                    "id": _newClipId(s),
                    "trackId": item.track.id,
                    "sourceId": p.sourceId,
                    "name": p.name || item.source.name,
                    "start": o.frame + p.start - minStart,
                    "duration": p.duration,
                    "sourceIn": p.sourceIn,
                    "sourceDuration": p.sourceDuration || item.source.duration,
                    "linkId": link,
                    "color": p.color || item.source.color
                });
        }
        for (i = 0; i < desired.length; ++i)
            s.clips.push(desired[i]);
        _sortState(s);
        return _ok(s);
    }

    function _trackEdit(s, o) {
        var t = _track(s, o.id);
        if (!t)
            return _fail("Unknown track " + o.id);
        var changes = o.changes || {};
        var allowed = {
            "name": true,
            "locked": true,
            "muted": true,
            "solo": true,
            "visible": true,
            "ripple": true,
            "targeted": true,
            "height": true
        };
        for (var key in changes) {
            if (!allowed[key])
                return _fail("Track field cannot be changed: " + key);
            if (key === "name" && typeof changes[key] !== "string")
                return _fail("Track name must be text");
            if (key === "height" && (!_isInt(changes[key]) || changes[key] < 24))
                return _fail("Track height must be at least 24");
            if (key !== "name" && key !== "height" && typeof changes[key] !== "boolean")
                return _fail("Track flag must be boolean");
            t[key] = changes[key];
        }
        if (changes.targeted === true)
            for (var i = 0; i < s.tracks.length; ++i)
                if (s.tracks[i].kind === t.kind && s.tracks[i].id !== t.id)
                    s.tracks[i].targeted = false;
        return _ok(s);
    }

    function _addTrack(s, o) {
        if (o.kind !== "video" && o.kind !== "audio")
            return _fail("Track kind must be video or audio");
        var count = _kindTracks(s, o.kind).length + 1;
        s.tracks.push({
                "id": _newTrackId(s),
                "name": (o.kind === "video" ? "Video " : "Audio ") + count,
                "kind": o.kind,
                "locked": false,
                "muted": false,
                "solo": false,
                "visible": true,
                "ripple": true,
                "targeted": false,
                "height": o.kind === "video" ? 68 : 54
            });
        return _ok(s);
    }

    function _removeTrack(s, o) {
        var t = _track(s, o.id);
        if (!t)
            return _fail("Unknown track " + o.id);
        for (var i = 0; i < s.clips.length; ++i)
            if (s.clips[i].trackId === t.id)
                return _fail("Track " + t.id + " must be empty before removal");
        var kept = [];
        for (i = 0; i < s.tracks.length; ++i)
            if (s.tracks[i].id !== t.id)
                kept.push(s.tracks[i]);
        s.tracks = kept;
        return _ok(s);
    }

    function _reorderTrack(s, o) {
        if (!_isInt(o.index) || o.index < 0 || o.index >= s.tracks.length)
            return _fail("Track order index is out of range");
        var old = _trackIndex(s, o.id);
        if (old < 0)
            return _fail("Unknown track " + o.id);
        var t = s.tracks.splice(old, 1)[0];
        s.tracks.splice(o.index, 0, t);
        _sortState(s);
        return _ok(s);
    }

    function _marks(s, o) {
        var nextIn = o.inFrame === undefined ? s.inFrame : o.inFrame;
        var nextOut = o.outFrame === undefined ? s.outFrame : o.outFrame;
        if (!(nextIn === -1 || (_isInt(nextIn) && nextIn >= root.startFrame)))
            return _fail("Invalid in mark");
        if (!(nextOut === -1 || (_isInt(nextOut) && nextOut >= root.startFrame)))
            return _fail("Invalid out mark");
        if (nextIn !== -1 && nextOut !== -1 && nextIn > nextOut)
            return _fail("In mark must not follow out mark");
        s.inFrame = nextIn;
        s.outFrame = nextOut;
        return _ok(s);
    }

    function _candidate(operation) {
        if (!operation || typeof operation.type !== "string")
            return _fail("Operation type is required");
        var s = _snapshot();
        var result;
        switch (operation.type) {
        case "move":
            result = _move(s, operation);
            break;
        case "trim":
            result = _trim(s, operation, false);
            break;
        case "ripple":
            result = _trim(s, operation, true);
            break;
        case "roll":
            result = _roll(s, operation);
            break;
        case "slip":
            result = _slip(s, operation);
            break;
        case "slide":
            result = _slide(s, operation);
            break;
        case "cut":
            result = _cut(s, operation);
            break;
        case "delete":
            result = _delete(s, operation);
            break;
        case "insert":
        case "overwrite":
            result = _insert(s, operation);
            break;
        case "paste":
            result = _paste(s, operation);
            break;
        case "track":
            result = _trackEdit(s, operation);
            break;
        case "addTrack":
            result = _addTrack(s, operation);
            break;
        case "removeTrack":
            result = _removeTrack(s, operation);
            break;
        case "reorderTrack":
            result = _reorderTrack(s, operation);
            break;
        case "marks":
            result = _marks(s, operation);
            break;
        default:
            return _fail("Unknown operation " + operation.type);
        }
        if (!result.ok)
            return result;
        var valid = _validateState(s);
        if (!valid.ok)
            return valid;
        return _ok(s);
    }

    function preview(operation) {
        var result = _candidate(operation);
        if (!result.ok)
            return {
                "ok": false,
                "error": result.error,
                "clips": _cloneClips(clips),
                "tracks": _cloneTracks(tracks)
            };
        return {
            "ok": true,
            "error": "",
            "clips": _cloneClips(result.state.clips),
            "tracks": _cloneTracks(result.state.tracks)
        };
    }

    function apply(operation) {
        var result = _candidate(operation);
        if (!result.ok) {
            error = result.error;
            return false;
        }
        var before = _snapshot();
        if (_sameState(before, result.state)) {
            error = "";
            return true;
        }
        var undoNext = _undo.slice();
        undoNext.push(before);
        while (undoNext.length > 100)
            undoNext.shift();
        _undo = undoNext;
        _redo = [];
        _restore(result.state);
        return true;
    }

    function undo() {
        if (!_undo.length) {
            error = "Nothing to undo";
            return false;
        }
        var old = _undo[_undo.length - 1];
        var undoNext = _undo.slice(0, _undo.length - 1);
        var redoNext = _redo.slice();
        redoNext.push(_snapshot());
        while (redoNext.length > 100)
            redoNext.shift();
        _undo = undoNext;
        _redo = redoNext;
        _restore(old);
        return true;
    }

    function redo() {
        if (!_redo.length) {
            error = "Nothing to redo";
            return false;
        }
        var next = _redo[_redo.length - 1];
        var redoNext = _redo.slice(0, _redo.length - 1);
        var undoNext = _undo.slice();
        undoNext.push(_snapshot());
        while (undoNext.length > 100)
            undoNext.shift();
        _undo = undoNext;
        _redo = redoNext;
        _restore(next);
        return true;
    }

    function clip(id) {
        var c = _clip({
                "clips": clips
            }, id);
        return c ? _cloneClip(c) : null;
    }

    function linkedIds(ids) {
        return _expandLinked({
                "clips": clips
            }, ids || [], true);
    }

    function track(id) {
        var t = _track({
                "tracks": tracks
            }, id);
        return t ? _cloneTrack(t) : null;
    }

    function sequenceEnd() {
        var end = startFrame;
        for (var i = 0; i < clips.length; ++i)
            end = Math.max(end, clips[i].start + clips[i].duration);
        return end;
    }
}
