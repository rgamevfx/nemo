import QtQuick
import QtQuick.Controls

Button {
    id: root

    property string glyph: "play"
    property bool active: false
    property string tooltipText: ""
    onGlyphChanged: glyphCanvas.requestPaint()
    property var themeContext: typeof theme === "undefined" ? null : theme

    function themeColor(role, fallback) {
        return themeContext && themeContext[role] !== undefined ? themeContext[role] : fallback;
    }
    onEnabledChanged: glyphCanvas.requestPaint()

    implicitWidth: 29
    implicitHeight: 28
    padding: 0
    flat: true

    background: Rectangle {
        radius: root.themeContext ? root.themeContext.smallRadius : 4
        color: root.pressed
               ? root.themeColor("raised", "transparent")
               : root.hovered
                 ? root.themeColor("hover", "transparent")
                 : "transparent"
        border.width: root.activeFocus || root.active ? 1 : 0
        border.color: root.activeFocus
                      ? root.themeColor("accent", "transparent")
                      : root.themeColor("border", "transparent")
    }

    contentItem: Canvas {
        id: glyphCanvas
        anchors.fill: parent
        anchors.margins: 7
        antialiasing: true

        onPaint: {
            var ctx = getContext("2d");
            ctx.reset();
            ctx.strokeStyle = root.enabled
                               ? root.themeColor("text", "transparent")
                               : root.themeColor("disabled", "transparent");
            ctx.fillStyle = root.enabled
                             ? root.themeColor("text", "transparent")
                             : root.themeColor("disabled", "transparent");
            ctx.lineWidth = 1.5;
            ctx.lineCap = "round";
            ctx.lineJoin = "round";
            var w = width;
            var h = height;
            var mid = h / 2;

            function triangle(direction) {
                ctx.beginPath();
                if (direction > 0) {
                    ctx.moveTo(w * 0.34, h * 0.2);
                    ctx.lineTo(w * 0.76, mid);
                    ctx.lineTo(w * 0.34, h * 0.8);
                } else {
                    ctx.moveTo(w * 0.66, h * 0.2);
                    ctx.lineTo(w * 0.24, mid);
                    ctx.lineTo(w * 0.66, h * 0.8);
                }
                ctx.closePath();
                ctx.fill();
            }

            if (root.glyph === "play") {
                triangle(1);
            } else if (root.glyph === "pause") {
                ctx.fillRect(w * 0.26, h * 0.18, w * 0.18, h * 0.64);
                ctx.fillRect(w * 0.56, h * 0.18, w * 0.18, h * 0.64);
            } else if (root.glyph === "stop") {
                ctx.fillRect(w * 0.25, h * 0.24, w * 0.5, h * 0.52);
            } else if (root.glyph === "previous") {
                ctx.beginPath();
                ctx.moveTo(w * 0.72, h * 0.2);
                ctx.lineTo(w * 0.34, mid);
                ctx.lineTo(w * 0.72, h * 0.8);
                ctx.stroke();
                ctx.beginPath();
                ctx.moveTo(w * 0.2, h * 0.18);
                ctx.lineTo(w * 0.2, h * 0.82);
                ctx.stroke();
            } else if (root.glyph === "next") {
                ctx.beginPath();
                ctx.moveTo(w * 0.28, h * 0.2);
                ctx.lineTo(w * 0.66, mid);
                ctx.lineTo(w * 0.28, h * 0.8);
                ctx.stroke();
                ctx.beginPath();
                ctx.moveTo(w * 0.8, h * 0.18);
                ctx.lineTo(w * 0.8, h * 0.82);
                ctx.stroke();
            } else if (root.glyph === "start") {
                ctx.beginPath();
                ctx.moveTo(w * 0.72, h * 0.2);
                ctx.lineTo(w * 0.34, mid);
                ctx.lineTo(w * 0.72, h * 0.8);
                ctx.closePath();
                ctx.fill();
                ctx.beginPath();
                ctx.moveTo(w * 0.19, h * 0.17);
                ctx.lineTo(w * 0.19, h * 0.83);
                ctx.stroke();
            } else if (root.glyph === "end") {
                ctx.beginPath();
                ctx.moveTo(w * 0.28, h * 0.2);
                ctx.lineTo(w * 0.66, mid);
                ctx.lineTo(w * 0.28, h * 0.8);
                ctx.closePath();
                ctx.fill();
                ctx.beginPath();
                ctx.moveTo(w * 0.81, h * 0.17);
                ctx.lineTo(w * 0.81, h * 0.83);
                ctx.stroke();
            } else if (root.glyph === "markIn") {
                ctx.beginPath();
                ctx.moveTo(w * 0.3, h * 0.2);
                ctx.lineTo(w * 0.3, h * 0.8);
                ctx.lineTo(w * 0.7, h * 0.8);
                ctx.stroke();
                ctx.beginPath();
                ctx.moveTo(w * 0.44, h * 0.32);
                ctx.lineTo(w * 0.7, h * 0.32);
                ctx.stroke();
            } else if (root.glyph === "markOut") {
                ctx.beginPath();
                ctx.moveTo(w * 0.7, h * 0.2);
                ctx.lineTo(w * 0.7, h * 0.8);
                ctx.lineTo(w * 0.3, h * 0.8);
                ctx.stroke();
                ctx.beginPath();
                ctx.moveTo(w * 0.56, h * 0.32);
                ctx.lineTo(w * 0.3, h * 0.32);
                ctx.stroke();
            }
        }

        Component.onCompleted: requestPaint()
    }
    Connections {
        target: root.themeContext
        function onTextChanged() { glyphCanvas.requestPaint() }
        function onDisabledChanged() { glyphCanvas.requestPaint() }
        function onAccentChanged() { glyphCanvas.requestPaint() }
    }

    ToolTip.visible: hovered && tooltipText.length > 0
    ToolTip.text: tooltipText
    Accessible.name: tooltipText
}
