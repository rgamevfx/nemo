import QtQuick

FocusScope {
    id: frameRuler

    objectName: "frameRuler"
    implicitHeight: compact ? 36 : 54
    clip: true

    property int frame: 1001
    property int firstFrame: 1001
    property int lastFrame: 1240
    property int inFrame: 1001
    property int outFrame: 1240
    property var themeContext: typeof theme === "undefined" ? null : theme
    // Compact mode keeps the ruler in the viewer's single-row chrome.
    // The interaction geometry remains unchanged so existing hit targets and
    // seek/mark semantics work at either height.
    property bool compact: false
    readonly property bool showPlayheadFlag: !compact || interactionArea.containsMouse || dragging

    function themeColor(role, fallback) {
        return themeContext && themeContext[role] !== undefined ? themeContext[role] : fallback;
    }

    signal seek(int value)
    signal markIn(int value)
    signal markOut(int value)

    readonly property int safeFirstFrame: Math.min(firstFrame, lastFrame)
    readonly property int safeLastFrame: Math.max(firstFrame, lastFrame)
    readonly property int safeInFrame: Math.max(safeFirstFrame, Math.min(safeLastFrame, inFrame))
    readonly property int safeOutFrame: Math.max(safeFirstFrame, Math.min(safeLastFrame, outFrame))
    readonly property int displayInFrame: Math.min(safeInFrame, safeOutFrame)
    readonly property int displayOutFrame: Math.max(safeInFrame, safeOutFrame)
    readonly property int displayFrame: Math.max(safeFirstFrame, Math.min(safeLastFrame,
                                                                        dragging && dragMode === "seek" ? previewFrame : frame))
    readonly property int visualInFrame: dragging && dragMode === "in"
                                         ? Math.min(safeOutFrame, previewValue) : displayInFrame
    readonly property int visualOutFrame: dragging && dragMode === "out"
                                          ? Math.max(safeInFrame, previewValue) : displayOutFrame
    property bool dragging: false
    property string dragMode: ""
    property int previewFrame: 1001
    property int previewValue: 1001

    function plotLeft() {
        return width >= 32 ? 8 : 2;
    }

    function plotRight() {
        return width >= 32 ? Math.max(plotLeft(), width - 8) : Math.max(plotLeft(), width - 2);
    }

    function xForFrame(value) {
        var span = safeLastFrame - safeFirstFrame;
        if (span <= 0)
            return (plotLeft() + plotRight()) / 2;
        var bounded = Math.max(safeFirstFrame, Math.min(safeLastFrame, value));
        return plotLeft() + (bounded - safeFirstFrame) * (plotRight() - plotLeft()) / span;
    }

    function frameForX(value) {
        var left = plotLeft();
        var right = plotRight();
        var span = safeLastFrame - safeFirstFrame;
        if (span <= 0 || right <= left)
            return safeFirstFrame;
        var ratio = Math.max(0, Math.min(1, (value - left) / (right - left)));
        return Math.max(safeFirstFrame, Math.min(safeLastFrame,
                                                   Math.round(safeFirstFrame + ratio * span)));
    }

    function tickStep() {
        var span = Math.max(1, safeLastFrame - safeFirstFrame);
        var labelWidth = Math.max(compact ? 16 : 20,
                                  String(safeFirstFrame).length * (compact ? 6.2 : 7.2),
                                  String(safeLastFrame).length * (compact ? 6.2 : 7.2));
        var usable = Math.max(1, plotRight() - plotLeft());
        var targetSpacing = labelWidth + (compact ? 6 : 10);
        var raw = span / Math.max(1, Math.floor(usable / targetSpacing));
        var power = Math.pow(10, Math.floor(Math.log(raw) / Math.LN10));
        var multiples = [1, 2, 5, 10];
        for (var i = 0; i < multiples.length; ++i) {
            var candidate = multiples[i] * power;
            if (candidate * usable / span >= targetSpacing)
                return Math.max(1, candidate);
        }
        return Math.max(1, 10 * power);
    }

    Rectangle {
        anchors.fill: parent
        color: frameRuler.themeColor("panel", "transparent")
    }

    Canvas {
        id: rulerCanvas
        anchors.fill: parent
        antialiasing: true
        renderTarget: Canvas.FramebufferObject

        onPaint: {
            var ctx = getContext("2d");
            ctx.clearRect(0, 0, width, height);

            var left = frameRuler.plotLeft();
            var right = frameRuler.plotRight();
            var baseY = frameRuler.compact ? Math.min(22, Math.max(15, height - 11))
                                          : Math.min(37, Math.max(27, height - 17));
            var stripY = frameRuler.compact ? Math.max(6, baseY - 5) : Math.max(22, baseY - 7);
            var labelY = frameRuler.compact ? Math.min(height - 2, baseY + 10)
                                            : Math.min(height - 2, baseY + 15);
            var span = frameRuler.safeLastFrame - frameRuler.safeFirstFrame;
            var major = frameRuler.tickStep();
            var majorSpacing = span > 0 ? major * (right - left) / span : right - left;
            var minorDivisions = majorSpacing >= 30 ? 5 : majorSpacing >= 15 ? 2 : 0;

            ctx.strokeStyle = frameRuler.themeColor("border", "transparent");
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(left, baseY + 0.5);
            ctx.lineTo(right, baseY + 0.5);
            ctx.stroke();

            var inX = frameRuler.xForFrame(frameRuler.visualInFrame);
            var outX = frameRuler.xForFrame(frameRuler.visualOutFrame);
            ctx.fillStyle = frameRuler.themeColor("accent", "transparent");
            ctx.fillRect(inX, stripY, Math.max(2, outX - inX), 7);

            ctx.strokeStyle = frameRuler.themeColor("muted", "transparent");
            ctx.lineWidth = 1;
            var firstMajor = span > 0 ? Math.ceil(frameRuler.safeFirstFrame / major) * major
                                      : frameRuler.safeFirstFrame;
            if (span > 0 && minorDivisions > 0) {
                var minorStep = Math.max(1, Math.floor(major / minorDivisions));
                var minorSpacing = minorStep * (right - left) / span;
                if (minorSpacing >= 6) {
                    var firstMinor = Math.ceil(frameRuler.safeFirstFrame / minorStep) * minorStep;
                    for (var minorFrame = firstMinor; minorFrame <= frameRuler.safeLastFrame; minorFrame += minorStep) {
                        if (minorFrame % major === 0)
                            continue;
                        var minorX = frameRuler.xForFrame(minorFrame);
                        ctx.beginPath();
                        ctx.moveTo(minorX + 0.5, baseY - 3);
                        ctx.lineTo(minorX + 0.5, baseY + 0.5);
                        ctx.stroke();
                    }
                }
            }

            var labels = [];
            if (span <= 0) {
                labels.push(frameRuler.safeFirstFrame);
            } else {
                for (var majorFrame = firstMajor; majorFrame <= frameRuler.safeLastFrame; majorFrame += major)
                    labels.push(majorFrame);
                if (labels.length === 0 || labels[0] !== frameRuler.safeFirstFrame)
                    labels.unshift(frameRuler.safeFirstFrame);
                if (labels[labels.length - 1] !== frameRuler.safeLastFrame)
                    labels.push(frameRuler.safeLastFrame);
            }

            ctx.font = frameRuler.compact ? "9px sans-serif" : "10px sans-serif";
            ctx.textBaseline = "alphabetic";
            ctx.strokeStyle = frameRuler.themeColor("muted", "transparent");
            ctx.lineWidth = 1;
            for (var tickIndex = 0; tickIndex < labels.length; ++tickIndex) {
                var tickX = frameRuler.xForFrame(labels[tickIndex]);
                ctx.beginPath();
                ctx.moveTo(tickX + 0.5, baseY - 10);
                ctx.lineTo(tickX + 0.5, baseY + 0.5);
                ctx.stroke();
            }

            ctx.fillStyle = frameRuler.themeColor("text", "transparent");
            var previousLabelRight = -Infinity;
            for (var labelIndex = 0; labelIndex < labels.length; ++labelIndex) {
                var label = String(labels[labelIndex]);
                var labelWidth = ctx.measureText(label).width;
                var labelX = frameRuler.xForFrame(labels[labelIndex]);
                var labelLeft = Math.max(1, Math.min(width - labelWidth - 1, labelX - labelWidth / 2));
                if (width < labelWidth + 3 || labelLeft < previousLabelRight + (frameRuler.compact ? 3 : 5))
                    continue;
                ctx.fillText(label, labelLeft, labelY);
                previousLabelRight = labelLeft + labelWidth;
            }

            // Endpoints remain visible even when labels are suppressed by a narrow view.
            ctx.strokeStyle = frameRuler.themeColor("muted", "transparent");
            ctx.lineWidth = 1;
            var endpointXs = [inX, outX];
            for (var endpoint = 0; endpoint < endpointXs.length; ++endpoint) {
                var endpointX = endpointXs[endpoint];
                ctx.beginPath();
                ctx.moveTo(endpointX + 0.5, stripY - 2);
                ctx.lineTo(endpointX + 0.5, Math.min(height - 5, baseY + 9));
                ctx.stroke();
                ctx.fillStyle = frameRuler.themeColor("muted", "transparent");
                ctx.beginPath();
                if (endpoint === 0) {
                    ctx.moveTo(endpointX, Math.min(height - 4, baseY + 10));
                    ctx.lineTo(endpointX + 5, Math.min(height - 9, baseY + 5));
                    ctx.lineTo(endpointX, Math.min(height - 9, baseY + 5));
                } else {
                    ctx.moveTo(endpointX, Math.min(height - 4, baseY + 10));
                    ctx.lineTo(endpointX - 5, Math.min(height - 9, baseY + 5));
                    ctx.lineTo(endpointX, Math.min(height - 9, baseY + 5));
                }
                ctx.closePath();
                ctx.fill();
            }

            // The playhead remains visible in compact mode. Its numeric flag is
            // shown only while the ruler is hovered or being dragged, avoiding
            // a permanent label lane in the 36px row.
            var playheadX = frameRuler.xForFrame(frameRuler.displayFrame);
            ctx.strokeStyle = frameRuler.themeColor("accent", "transparent");
            ctx.lineWidth = 1.5;
            ctx.beginPath();
            ctx.moveTo(playheadX + 0.5, 0);
            ctx.lineTo(playheadX + 0.5, Math.min(height - 4, baseY + 10));
            ctx.stroke();

            if (frameRuler.showPlayheadFlag) {
                var flagText = String(frameRuler.displayFrame);
                ctx.font = "bold " + (frameRuler.compact ? "9px" : "10px") + " sans-serif";
                var flagWidth = Math.max(frameRuler.compact ? 23 : 27,
                                         ctx.measureText(flagText).width + (frameRuler.compact ? 7 : 10));
                flagWidth = Math.min(Math.max(2, width - 2), flagWidth);
                var flagX = Math.max(1, Math.min(width - flagWidth - 1, playheadX - flagWidth / 2));
                ctx.fillStyle = frameRuler.themeColor("accent", "transparent");
                ctx.fillRect(flagX, 1, flagWidth, 15);
                ctx.beginPath();
                ctx.moveTo(playheadX, 16);
                ctx.lineTo(playheadX - 4, 16);
                ctx.lineTo(playheadX, 20);
                ctx.lineTo(playheadX + 4, 16);
                ctx.closePath();
                ctx.fill();
                ctx.fillStyle = frameRuler.themeColor("panel", "transparent");
                ctx.textBaseline = "middle";
                ctx.fillText(flagText, Math.max(flagX + (frameRuler.compact ? 3 : 4),
                                                Math.min(flagX + flagWidth - ctx.measureText(flagText).width - 3,
                                                         playheadX - ctx.measureText(flagText).width / 2)), 8.5);
            }
        }

        onWidthChanged: requestPaint()
        onHeightChanged: requestPaint()
    }
    Connections {
        target: frameRuler.themeContext
        function onBackgroundChanged() { rulerCanvas.requestPaint() }
        function onPanelChanged() { rulerCanvas.requestPaint() }
        function onBorderChanged() { rulerCanvas.requestPaint() }
        function onMutedChanged() { rulerCanvas.requestPaint() }
        function onTextChanged() { rulerCanvas.requestPaint() }
        function onAccentChanged() { rulerCanvas.requestPaint() }
    }

    MouseArea {
        id: interactionArea
        anchors.fill: parent
        acceptedButtons: Qt.LeftButton
        preventStealing: true
        hoverEnabled: true
        onContainsMouseChanged: rulerCanvas.requestPaint()
        cursorShape: frameRuler.dragging && frameRuler.dragMode !== "seek"
                     ? Qt.SizeHorCursor : Qt.PointingHandCursor

        function handleRadius() {
            return Math.max(7, Math.min(11, frameRuler.width * 0.12));
        }

        onPressed: function(mouse) {
            frameRuler.forceActiveFocus();
            var inX = frameRuler.xForFrame(frameRuler.displayInFrame);
            var outX = frameRuler.xForFrame(frameRuler.displayOutFrame);
            var radius = handleRadius();
            var inHit = Math.abs(mouse.x - inX) <= radius;
            var outHit = Math.abs(mouse.x - outX) <= radius;
            if (inHit || outHit) {
                if (inHit && outHit)
                    frameRuler.dragMode = mouse.x <= (inX + outX) / 2 ? "in" : "out";
                else
                    frameRuler.dragMode = inHit ? "in" : "out";
                frameRuler.previewValue = frameRuler.dragMode === "in" ? frameRuler.safeInFrame
                                                                        : frameRuler.safeOutFrame;
            } else {
                frameRuler.dragMode = "seek";
                frameRuler.previewFrame = frameRuler.frameForX(mouse.x);
                frameRuler.seek(frameRuler.previewFrame);
            }
            frameRuler.dragging = true;
            rulerCanvas.requestPaint();
        }

        onPositionChanged: function(mouse) {
            if (!pressed || !frameRuler.dragging)
                return;
            var value = frameRuler.frameForX(mouse.x);
            if (frameRuler.dragMode === "seek") {
                if (value === frameRuler.previewFrame)
                    return;
                frameRuler.previewFrame = value;
                frameRuler.seek(value);
            } else if (frameRuler.dragMode === "in") {
                value = Math.min(value, frameRuler.safeOutFrame);
                if (value === frameRuler.previewValue)
                    return;
                frameRuler.previewValue = value;
                frameRuler.markIn(value);
            } else if (frameRuler.dragMode === "out") {
                value = Math.max(value, frameRuler.safeInFrame);
                if (value === frameRuler.previewValue)
                    return;
                frameRuler.previewValue = value;
                frameRuler.markOut(value);
            }
            rulerCanvas.requestPaint();
        }

        onReleased: {
            frameRuler.dragging = false;
            frameRuler.dragMode = "";
            rulerCanvas.requestPaint();
        }

        onCanceled: {
            frameRuler.dragging = false;
            frameRuler.dragMode = "";
            rulerCanvas.requestPaint();
        }
    }

    onFrameChanged: rulerCanvas.requestPaint()
    onFirstFrameChanged: rulerCanvas.requestPaint()
    onLastFrameChanged: rulerCanvas.requestPaint()
    onInFrameChanged: rulerCanvas.requestPaint()
    onOutFrameChanged: rulerCanvas.requestPaint()
    onDisplayInFrameChanged: rulerCanvas.requestPaint()
    onDisplayOutFrameChanged: rulerCanvas.requestPaint()
    onDisplayFrameChanged: rulerCanvas.requestPaint()
    onVisualInFrameChanged: rulerCanvas.requestPaint()
    onVisualOutFrameChanged: rulerCanvas.requestPaint()
    onPreviewFrameChanged: rulerCanvas.requestPaint()
    onCompactChanged: rulerCanvas.requestPaint()
    onDraggingChanged: rulerCanvas.requestPaint()
    onShowPlayheadFlagChanged: rulerCanvas.requestPaint()
    onPreviewValueChanged: rulerCanvas.requestPaint()
}
