import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

// Session-only editing surface. TimelineModel is the sole owner of sequence
// state; this item owns only view state, selection, gestures and clipboard.
Rectangle {
    id: timelinePanel
    objectName: "timelinePrototype"
    color: theme.background
    focus: true
    activeFocusOnTab: true

    property var model: studio.timeline
    property string panelGroup: "A"
    property string tool: "select"
    property bool snapping: true
    property bool linkedSelection: true
    property var selectedIds: []
    property real scrollY: 0
    property real labelWidth: 156
    property real pixelsPerFrame: 3.2
    property real viewStart: model.startFrame - 24
    readonly property int rulerHeight: 31
    readonly property int rowGap: 2
    readonly property int minTrackHeight: 32
    property Component headerTools: TimelineHeaderTools {
        editor: timelinePanel
    }

    readonly property var tracks: model.tracks
    readonly property var clips: model.clips
    readonly property var sources: model.sources
    readonly property int revision: model.revision
    property int contextRevision: 0
    function contextFrame() {
        var revision = contextRevision;
        if (typeof studio !== "undefined" && studio && studio.timelineContext) {
            var context = studio.timelineContext(panelGroup);
            if (context && context.frame !== undefined && isFinite(Number(context.frame)))
                return Math.round(Number(context.frame));
        }
        return model && Number(model.startFrame) >= 0 ? Number(model.startFrame) : 1001;
    }
    readonly property int currentFrame: contextFrame()
    property bool initialFitDone: false

    property string statusMessage: ""
    property bool statusIsError: false
    property bool transportPlaying: false
    property var clipboardClips: []
    property var previewClips: []
    property var previewTracks: []
    property bool previewActive: false
    property string previewError: ""
    property string hoverClipId: ""
    property int hoverTrackIndex: -1
    property string hoverTrackControl: ""
    property bool hoverInHeader: false
    property real snapGuideFrame: -1
    property bool incompatibleTrack: false

    // Gesture state is intentionally not mirrored into the model. A rejected
    // candidate remains a transient visual until release or Escape.
    property string gesture: ""
    property string gestureClipId: ""
    property var gestureIds: []
    property int gestureStartFrame: 0
    property int gestureStartTrackIndex: -1
    property int gestureStartX: 0
    property int gestureStartY: 0
    property int gestureLastViewportX: 0
    property int gestureLastViewportY: 0
    property int gestureDelta: 0
    property int gestureTrackDelta: 0
    property real resizeHeight: 0
    property real labelResizeStart: 0
    property var gestureSelectionBefore: []
    property bool gestureAltBypass: false
    property var activeOperation: null
    property var marqueeRect: null

    function arrayValue(value) {
        return value && value.length !== undefined ? value : [];
    }

    function contentHeight() {
        var total = rulerHeight;
        for (var i = 0; i < tracks.length; ++i)
            total += trackHeight(i) + rowGap;
        return total;
    }

    function maxScrollY() {
        return Math.max(0, contentHeight() - timelineViewport.height);
    }

    function clampScroll() {
        scrollY = Math.max(0, Math.min(maxScrollY(), scrollY));
    }

    function trackHeight(index) {
        var track = tracks[index];
        var h = track && Number(track.height) > 0 ? Number(track.height) : 58;
        if (gesture === "resize" && index === gestureStartTrackIndex && resizeHeight > 0)
            h = resizeHeight;
        return Math.max(minTrackHeight, h);
    }

    function trackY(index) {
        var y = rulerHeight;
        for (var i = 0; i < index && i < tracks.length; ++i)
            y += trackHeight(i) + rowGap;
        return y - scrollY;
    }

    function trackAtY(y) {
        for (var i = 0; i < tracks.length; ++i) {
            var top = trackY(i);
            if (y >= top && y < top + trackHeight(i))
                return i;
        }
        return -1;
    }

    function trackById(id) {
        for (var i = 0; i < tracks.length; ++i)
            if (tracks[i] && String(tracks[i].id) === String(id))
                return tracks[i];
        return null;
    }

    function trackIndex(id) {
        for (var i = 0; i < tracks.length; ++i)
            if (tracks[i] && String(tracks[i].id) === String(id))
                return i;
        return -1;
    }

    function clipById(id) {
        return model.clip(id);
    }

    function sequenceEnd() {
        return Number(model.sequenceEnd());
    }

    function frameToX(frame) {
        return labelWidth + (Number(frame) - Number(viewStart)) * pixelsPerFrame;
    }

    function xToFrame(x) {
        return Math.round(Number(viewStart) + (Number(x) - labelWidth) / Math.max(0.01, pixelsPerFrame));
    }

    function sourceById(id) {
        for (var i = 0; i < sources.length; ++i)
            if (sources[i] && String(sources[i].id) === String(id))
                return sources[i];
        return null;
    }

    function uniqueIds(ids) {
        var result = [];
        var seen = {};
        var values = arrayValue(ids);
        for (var i = 0; i < values.length; ++i) {
            var id = values[i];
            if (id === undefined || id === null || seen[id])
                continue;
            seen[id] = true;
            result.push(String(id));
        }
        return result;
    }

    function linkedIds(ids) {
        var result = uniqueIds(ids);
        if (!linkedSelection || !model || typeof model.linkedIds !== "function")
            return result;
        var linked = model.linkedIds(result);
        return uniqueIds(linked);
    }

    function selectIds(ids, additive, toggle) {
        var next = additive ? uniqueIds(selectedIds) : [];
        var incoming = linkedIds(ids);
        for (var i = 0; i < incoming.length; ++i) {
            var at = next.indexOf(incoming[i]);
            if (toggle && at >= 0)
                next.splice(at, 1);
            else if (at < 0)
                next.push(incoming[i]);
        }
        selectedIds = next;
        timelineSurface.requestPaint();
    }

    function clipAt(x, y) {
        if (x < labelWidth + 6 || y < rulerHeight)
            return null;
        var best = null;
        var nearestEdge = 6;
        for (var i = clips.length - 1; i >= 0; --i) {
            var clip = clips[i];
            if (!clip)
                continue;
            var ti = trackIndex(clip.trackId);
            if (ti < 0)
                continue;
            var left = frameToX(clip.start);
            var right = frameToX(Number(clip.start) + Number(clip.duration));
            var top = trackY(ti) + 3;
            var bottom = top + trackHeight(ti) - 6;
            if (x >= left && x < right && y >= top && y <= bottom) {
                best = clip;
                break;
            }
            var distance = Math.min(Math.abs(x - left), Math.abs(x - right));
            if (y >= top && y <= bottom && distance < nearestEdge) {
                best = clip;
                nearestEdge = distance;
            }
        }
        return best;
    }

    function edgeAt(clip, x) {
        if (!clip)
            return "";
        var left = frameToX(clip.start);
        var right = frameToX(Number(clip.start) + Number(clip.duration));
        var tolerance = Math.max(5, Math.min(10, pixelsPerFrame * 2.2));
        if (Math.abs(x - left) <= tolerance)
            return "in";
        if (Math.abs(x - right) <= tolerance)
            return "out";
        return "";
    }

    function trackKindRank(index, kind) {
        var rank = 0;
        for (var i = 0; i < index; ++i)
            if (tracks[i] && tracks[i].kind === kind)
                ++rank;
        return rank;
    }

    function trackDeltaFor(index) {
        if (gestureStartTrackIndex < 0 || index < 0)
            return 0;
        var origin = tracks[gestureStartTrackIndex];
        var target = tracks[index];
        if (!origin || !target || origin.kind !== target.kind)
            return 0;
        return trackKindRank(index, target.kind) - trackKindRank(gestureStartTrackIndex, origin.kind);
    }

    function snapFrame(frame, excludedIds) {
        if (!snapping || gestureAltBypass)
            return Math.round(frame);
        var candidates = [currentFrame];
        if (model && Number(model.inFrame) >= 0)
            candidates.push(Number(model.inFrame));
        if (model && Number(model.outFrame) >= 0)
            candidates.push(Number(model.outFrame));
        var excluded = {};
        var ids = arrayValue(excludedIds);
        for (var e = 0; e < ids.length; ++e)
            excluded[ids[e]] = true;
        for (var i = 0; i < clips.length; ++i) {
            var c = clips[i];
            if (!c || excluded[c.id])
                continue;
            candidates.push(Number(c.start));
            candidates.push(Number(c.start) + Number(c.duration));
        }
        var threshold = 7 / pixelsPerFrame;
        var nearest = Math.round(frame);
        var distance = threshold;
        for (var j = 0; j < candidates.length; ++j) {
            var d = Math.abs(candidates[j] - frame);
            if (d <= distance) {
                nearest = Math.round(candidates[j]);
                distance = d;
                snapGuideFrame = nearest;
            }
        }
        return nearest;
    }

    function snapMoveDelta(raw) {
        var best = raw;
        var distance = 7 / pixelsPerFrame + 1;
        var guide = -1;
        for (var i = 0; i < gestureIds.length; ++i) {
            var c = clipById(gestureIds[i]);
            var edges = [c.start, c.start + c.duration];
            for (var j = 0; j < edges.length; ++j) {
                snapGuideFrame = -1;
                var candidate = snapFrame(edges[j] + raw, gestureIds) - edges[j];
                if (snapGuideFrame >= 0 && Math.abs(candidate - raw) < distance) {
                    best = candidate;
                    distance = Math.abs(candidate - raw);
                    guide = snapGuideFrame;
                }
            }
        }
        snapGuideFrame = guide;
        return best;
    }

    function operationForGesture() {
        if (!gesture)
            return null;
        if (gesture === "move")
            return {
                "type": "move",
                "ids": gestureIds,
                "delta": gestureDelta,
                "trackDelta": gestureTrackDelta,
                "linked": linkedSelection
            };
        if (gesture === "trim" || gesture === "ripple" || gesture === "roll")
            return {
                "type": gesture,
                "id": gestureClipId,
                "edge": gestureEdge,
                "delta": gestureDelta,
                "linked": linkedSelection
            };
        if (gesture === "slip" || gesture === "slide")
            return {
                "type": gesture,
                "id": gestureClipId,
                "delta": gestureDelta,
                "linked": linkedSelection
            };
        return null;
    }

    property string gestureEdge: ""

    function updatePreview() {
        if (incompatibleTrack) {
            previewActive = false;
            previewError = "Move requires a compatible destination track";
            timelineSurface.requestPaint();
            return;
        }
        var operation = operationForGesture();
        if (!operation || !model || typeof model.preview !== "function")
            return;
        activeOperation = operation;
        var result = model.preview(operation);
        if (result && result.ok) {
            previewActive = true;
            previewError = "";
            previewClips = arrayValue(result.clips);
            previewTracks = arrayValue(result.tracks);
        } else {
            previewActive = false;
            previewError = result && result.error ? String(result.error) : "Edit is not valid";
            previewClips = [];
            previewTracks = [];
        }
        timelineSurface.requestPaint();
    }

    function operationChanged(operation) {
        if (!operation)
            return false;
        if (operation.type === "move")
            return Number(operation.delta) !== 0 || Number(operation.trackDelta) !== 0;
        if (operation.type === "trim" || operation.type === "ripple" || operation.type === "roll" || operation.type === "slip" || operation.type === "slide")
            return Number(operation.delta) !== 0;
        return true;
    }

    function commitOperation(operation) {
        if (!operation || !model || typeof model.apply !== "function")
            return false;
        var committed = model.apply(operation);
        if (committed) {
            statusMessage = "";
            statusIsError = false;
        } else {
            flashStatus(model.error ? String(model.error) : "Edit was rejected", true);
        }
        return committed;
    }

    function flashStatus(message, isError) {
        statusMessage = String(message || "");
        statusIsError = !!isError;
        statusTimer.restart();
    }

    function cancelGesture() {
        if (gesture === "labelResize")
            labelWidth = labelResizeStart;
        incompatibleTrack = false;
        snapGuideFrame = -1;
        gesture = "";
        gestureClipId = "";
        gestureIds = [];
        activeOperation = null;
        previewActive = false;
        previewError = "";
        marqueeRect = null;
        resizeHeight = 0;
        timelineSurface.requestPaint();
    }

    function finishGesture() {
        if (gesture === "marquee") {
            var r = marqueeRect;
            var next = gestureSelectionBefore.slice(0);
            if (r) {
                var left = Math.min(r.x1, r.x2);
                var right = Math.max(r.x1, r.x2);
                var top = Math.min(r.y1, r.y2);
                var bottom = Math.max(r.y1, r.y2);
                var hits = [];
                for (var i = 0; i < clips.length; ++i) {
                    var clip = clips[i];
                    var ti = clip ? trackIndex(clip.trackId) : -1;
                    if (!clip || ti < 0)
                        continue;
                    var cx1 = frameToX(clip.start);
                    var cx2 = frameToX(Number(clip.start) + Number(clip.duration));
                    var cy1 = trackY(ti) + 3;
                    var cy2 = cy1 + trackHeight(ti) - 6;
                    if (cx1 < right && cx2 > left && cy1 < bottom && cy2 > top)
                        hits.push(clip.id);
                }
                selectIds(hits, gestureSelectionBefore.length > 0, false);
            }
            cancelGesture();
            return;
        }
        if (gesture === "labelResize") {
            gesture = "";
            cancelGesture();
            return;
        }
        if (gesture === "resize") {
            var resizeTrack = tracks[gestureStartTrackIndex];
            if (resizeTrack)
                commitOperation({
                        "type": "track",
                        "id": resizeTrack.id,
                        "changes": {
                            "height": Math.round(resizeHeight)
                        }
                    });
            cancelGesture();
            return;
        }
        var operation = operationForGesture();
        if (operation && previewActive && operationChanged(operation))
            commitOperation(operation);
        else if (operation && previewError.length > 0)
            flashStatus(previewError, true);
        cancelGesture();
    }

    function setPlayhead(frame) {
        var value = Math.round(Number(frame));
        var lower = model && Number(model.startFrame) >= 0 ? Number(model.startFrame) : 1001;
        var upper = Math.max(lower, sequenceEnd() - 1);
        value = Math.max(lower, Math.min(upper, value));
        if (studio && studio.setTimelineContext)
            studio.setTimelineContext(panelGroup, {
                    "frame": value
                });
        timelineSurface.requestPaint();
    }

    function frameAll() {
        var start = model.startFrame;
        var end = Math.max(start + 48, sequenceEnd());
        var available = Math.max(40, timelineViewport.width - labelWidth - 40);
        pixelsPerFrame = Math.max(0.03, Math.min(24, available / (end - start)));
        viewStart = start - 16 / pixelsPerFrame;
        scrollY = 0;
        clampScroll();
        timelineSurface.requestPaint();
    }

    function frameSelected() {
        var start = Number.MAX_VALUE;
        var end = -Number.MAX_VALUE;
        var ids = selectedIds;
        for (var i = 0; i < ids.length; ++i) {
            var clip = clipById(ids[i]);
            if (clip) {
                start = Math.min(start, Number(clip.start));
                end = Math.max(end, Number(clip.start) + Number(clip.duration));
            }
        }
        if (start === Number.MAX_VALUE) {
            frameAll();
            return;
        }
        var available = Math.max(80, timelineViewport.width - labelWidth - 24);
        var span = Math.max(12, end - start);
        pixelsPerFrame = Math.max(0.03, Math.min(24, available / (span * 1.18)));
        viewStart = start - Math.max(2, Math.round(span * 0.09));
        scrollY = 0;
        clampScroll();
        timelineSurface.requestPaint();
    }

    function targetTrack(kind) {
        for (var i = 0; i < tracks.length; ++i) {
            var track = tracks[i];
            if (track && track.targeted && (!kind || track.kind === kind))
                return track.locked ? null : track;
        }
        return null;
    }

    function sourceRangeFor(source, group) {
        return source ? studio.mediaSourceRange(group || panelGroup, source.id) : null;
    }

    function insertSourcesAt(sourceIds, mode) {
        var first = sourceIds.length ? sourceById(sourceIds[0]) : null;
        var target = first ? targetTrack(first.kind) : null;
        var operation = dropOperationFor(sourceIds, target, currentFrame, panelGroup);
        if (!operation) {
            flashStatus("No compatible targeted track or source range", true);
            return false;
        }
        if (operation.type === "paste")
            operation.mode = mode;
        else
            operation.type = mode;
        return commitOperation(operation);
    }

    function copySelection() {
        var ids = uniqueIds(selectedIds);
        if (ids.length === 0)
            return;
        var start = Number.MAX_VALUE;
        for (var i = 0; i < ids.length; ++i) {
            var c = clipById(ids[i]);
            if (c)
                start = Math.min(start, Number(c.start));
        }
        var copied = [];
        for (var j = 0; j < ids.length; ++j) {
            var clip = clipById(ids[j]);
            if (!clip)
                continue;
            copied.push({
                    "id": clip.id,
                    "trackId": clip.trackId,
                    "sourceId": clip.sourceId,
                    "name": clip.name,
                    "start": Number(clip.start) - start,
                    "duration": Number(clip.duration),
                    "sourceIn": Number(clip.sourceIn),
                    "sourceDuration": Number(clip.sourceDuration),
                    "linkId": clip.linkId,
                    "color": clip.color
                });
        }
        clipboardClips = copied;
    }

    function pasteSelection(mode) {
        if (clipboardClips.length === 0 || !model || typeof model.apply !== "function")
            return false;
        var target = targetTrack();
        if (!target) {
            flashStatus("No explicitly targeted unlocked target track is available", true);
            return false;
        }
        var operation = {
            "type": "paste",
            "clips": clipboardClips,
            "frame": currentFrame,
            "trackId": target.id,
            "mode": mode === "overwrite" ? "overwrite" : "insert"
        };
        return commitOperation(operation);
    }

    function deleteSelection(ripple) {
        if (selectedIds.length === 0)
            return false;
        var committed = commitOperation({
                "type": "delete",
                "ids": linkedIds(selectedIds),
                "ripple": !!ripple,
                "linked": linkedSelection
            });
        if (committed)
            selectedIds = [];
        return committed;
    }

    function cutAtPlayhead() {
        var chosen = selectedIds.length ? linkedIds(selectedIds) : clips.filter(function (c) {
                return model.track(c.trackId).targeted;
            }).map(function (c) {
                return c.id;
            });
        var ids = chosen.filter(function (id) {
                var c = clipById(id);
                return c && c.start < currentFrame && currentFrame < c.start + c.duration;
            });
        if (ids.length === 0) {
            flashStatus("No clip at playhead", true);
            return false;
        }
        return commitOperation({
                "type": "cut",
                "ids": ids,
                "frame": currentFrame,
                "linked": linkedSelection
            });
    }

    function setTool(name) {
        var allowed = ["select", "ripple", "roll", "slip", "slide", "blade"];
        tool = allowed.indexOf(name) >= 0 ? name : "select";
        timelinePanel.forceActiveFocus();
        timelineSurface.requestPaint();
    }

    function openEditorMenu(anchor) {
        if (anchor) {
            var point = anchor.mapToItem(timelinePanel, 0, anchor.height);
            editorMenu.x = point.x;
            editorMenu.y = point.y;
        }
        editorMenu.open();
    }

    function requestMediaPanel() {
        if (studio && studio.requestMediaPanel)
            studio.requestMediaPanel(panelGroup);
    }

    // Kept as a compatibility entry point for existing timeline integrations;
    // media is now a dockable panel rather than a popup.
    function openMedia(anchor) {
        requestMediaPanel();
    }

    function applyTrackChanges(id, changes) {
        return commitOperation({
                "type": "track",
                "id": id,
                "changes": changes
            });
    }

    function beginGesture(kind, clip, mouse, edge) {
        gesture = kind;
        gestureClipId = clip ? String(clip.id) : "";
        gestureIds = clip ? linkedIds(selectedIds.indexOf(String(clip.id)) >= 0 ? selectedIds : [clip.id]) : [];
        gestureStartFrame = clip ? Number(clip.start) : xToFrame(mouse.x);
        gestureStartTrackIndex = clip ? trackIndex(clip.trackId) : trackAtY(mouse.y);
        gestureStartX = mouse.x;
        gestureStartY = mouse.y;
        gestureLastViewportX = mouse.x;
        gestureLastViewportY = mouse.y;
        gestureDelta = 0;
        gestureTrackDelta = 0;
        gestureEdge = edge || "";
        gestureAltBypass = (mouse.modifiers & Qt.AltModifier) !== 0;
        gestureSelectionBefore = selectedIds.slice(0);
        previewActive = false;
        previewError = "";
        resizeHeight = clip ? 0 : trackHeight(gestureStartTrackIndex);
        labelResizeStart = labelWidth;
        if (kind !== "marquee" && kind !== "resize" && kind !== "labelResize")
            updatePreview();
    }

    function updateGesture(mouse) {
        if (!gesture)
            return;
        gestureAltBypass = (mouse.modifiers & Qt.AltModifier) !== 0;
        snapGuideFrame = -1;
        if (gesture === "scrub") {
            setPlayhead(xToFrame(mouse.x));
            return;
        }
        gestureLastViewportX = mouse.x;
        gestureLastViewportY = mouse.y;
        if (gesture === "marquee") {
            marqueeRect = {
                "x1": gestureStartX,
                "y1": gestureStartY,
                "x2": mouse.x,
                "y2": mouse.y
            };
            timelineSurface.requestPaint();
            return;
        }
        if (gesture === "labelResize") {
            labelWidth = Math.max(128, Math.min(300, labelResizeStart + mouse.x - gestureStartX));
            timelineSurface.requestPaint();
            return;
        }
        if (gesture === "resize") {
            resizeHeight = Math.max(minTrackHeight, mouse.y - trackY(gestureStartTrackIndex));
            timelineSurface.requestPaint();
            return;
        }
        var raw = Math.round((mouse.x - gestureStartX) / Math.max(0.01, pixelsPerFrame));
        var clip = clipById(gestureClipId);
        var edgeFrame = clip ? (gestureEdge === "in" ? Number(clip.start) : Number(clip.start) + Number(clip.duration)) : 0;
        if (gesture === "move") {
            gestureDelta = snapMoveDelta(raw);
            gestureTrackDelta = trackDeltaFor(trackAtY(mouse.y));
            var destination = trackAtY(mouse.y);
            incompatibleTrack = destination < 0 || tracks[destination].kind !== tracks[gestureStartTrackIndex].kind;
        } else if (gesture === "trim" || gesture === "ripple" || gesture === "roll") {
            gestureDelta = snapFrame(edgeFrame + raw, gestureIds) - edgeFrame;
        } else {
            gestureDelta = raw;
        }
        updatePreview();
    }

    function autoScroll() {
        if (!gesture)
            return;
        var edge = 28;
        var vx = gestureLastViewportX;
        var vy = gestureLastViewportY;
        var oldViewStart = viewStart;
        if (vx < labelWidth + 8)
            viewStart -= (labelWidth + 8 - vx) * 0.3 / pixelsPerFrame;
        else if (vx > timelineViewport.width - edge)
            viewStart += (vx - timelineViewport.width + edge) * 1.8 / Math.max(0.01, pixelsPerFrame);
        // Keep the grabbed source frame under the pointer while the view pans.
        gestureStartX -= (viewStart - oldViewStart) * pixelsPerFrame;
        var oldScrollY = scrollY;
        if (vy < edge)
            scrollY = Math.max(0, scrollY - (edge - vy) * 1.8);
        else if (vy > timelineViewport.height - edge)
            scrollY = Math.min(maxScrollY(), scrollY + (vy - timelineViewport.height + edge) * 1.8);
        if (gesture === "marquee")
            gestureStartY -= scrollY - oldScrollY;
        if (gesture !== "resize" && gesture !== "labelResize") {
            var synthetic = {
                "x": gestureLastViewportX,
                "y": gestureLastViewportY,
                "modifiers": gestureAltBypass ? Qt.AltModifier : Qt.NoModifier
            };
            updateGesture(synthetic);
        }
    }

    function trackControlAt(x, y) {
        var index = trackAtY(y);
        if (index < 0 || x < labelWidth - 66 || x >= labelWidth || y < trackY(index) + trackHeight(index) - 24)
            return "";
        return ["locked", tracks[index].kind === "audio" ? "muted" : "visible", "targeted"][Math.floor((x - labelWidth + 66) / 22)];
    }

    function drawTrackControl(ctx, key, x, y, active) {
        ctx.save();
        ctx.translate(x, y);
        ctx.strokeStyle = active ? theme.accent : theme.muted;
        ctx.lineWidth = 1.2;
        ctx.beginPath();
        if (key === "locked") {
            ctx.rect(-4, -1, 8, 6);
            ctx.moveTo(-2.5, -1);
            ctx.lineTo(-2.5, -4);
            ctx.arc(0, -4, 2.5, Math.PI, Math.PI * 2);
            ctx.lineTo(2.5, -1);
        } else if (key === "visible") {
            ctx.moveTo(-6, 0);
            ctx.quadraticCurveTo(0, -7, 6, 0);
            ctx.quadraticCurveTo(0, 7, -6, 0);
            ctx.moveTo(2, 0);
            ctx.arc(0, 0, 2, 0, Math.PI * 2);
        } else if (key === "muted") {
            ctx.moveTo(-5, -2);
            ctx.lineTo(-2, -2);
            ctx.lineTo(1, -5);
            ctx.lineTo(1, 5);
            ctx.lineTo(-2, 2);
            ctx.lineTo(-5, 2);
            ctx.closePath();
            ctx.moveTo(4, -3);
            ctx.lineTo(7, 3);
            ctx.moveTo(7, -3);
            ctx.lineTo(4, 3);
        } else {
            ctx.rect(-4, -4, 8, 8);
            ctx.moveTo(-7, 0);
            ctx.lineTo(7, 0);
        }
        ctx.stroke();
        ctx.restore();
    }

    function clipColor(clip, kind) {
        if (clip && clip.color)
            return String(clip.color);
        var video = ["#3d6680", "#4f617d", "#466f68", "#715c7a", "#506f86"];
        var audio = ["#665b88", "#6c6650", "#566f6b", "#765b6f", "#596e83"];
        var palette = kind === "audio" ? audio : video;
        var hash = 0;
        var text = clip && clip.sourceId ? String(clip.sourceId) : String(clip && clip.id || "");
        for (var i = 0; i < text.length; ++i)
            hash = (hash * 31 + text.charCodeAt(i)) & 0x7fffffff;
        return palette[hash % palette.length];
    }

    function clipsForPaint() {
        return previewActive ? previewClips : clips;
    }

    function drawClip(ctx, clip, selected, hovered) {
        var ti = trackIndex(clip.trackId);
        if (ti < 0)
            return;
        var x = frameToX(Number(clip.start));
        var w = Math.max(2, Number(clip.duration) * pixelsPerFrame);
        var y = trackY(ti) + 4;
        var h = Math.max(14, trackHeight(ti) - 8);
        ctx.save();
        ctx.globalAlpha = tracks[ti].muted || tracks[ti].visible === false ? 0.45 : 1;
        var tint = clipColor(clip, tracks[ti].kind);
        ctx.fillStyle = theme.light ? Qt.lighter(tint, 1.5) : Qt.darker(tint, 1.65);
        ctx.fillRect(x, y, w, h);
        ctx.fillStyle = tint;
        ctx.fillRect(x, y, w, 2);
        ctx.strokeStyle = selected ? theme.text : hovered ? theme.muted : Qt.rgba(theme.text.r, theme.text.g, theme.text.b, 0.13);
        ctx.lineWidth = selected ? 2 : 1;
        ctx.strokeRect(x + 0.5, y + 0.5, Math.max(1, w - 1), Math.max(1, h - 1));
        if (selected) {
            ctx.fillStyle = theme.text;
            ctx.fillRect(x, y, 3, h);
            ctx.fillRect(x + Math.max(0, w - 3), y, 3, h);
        }
        if (w > 28 && clip.name) {
            ctx.beginPath();
            ctx.rect(x + 5, y + 3, Math.max(0, w - 10), Math.max(0, h - 6));
            ctx.clip();
            ctx.fillStyle = theme.text;
            ctx.font = "11px sans-serif";
            var label = gesture === "slip" && gestureIds.indexOf(clip.id) >= 0 ? "Source " + clip.sourceIn + "–" + (clip.sourceIn + clip.duration - 1) : String(clip.name);
            ctx.fillText(label, x + 7, y + 15);
        }
        ctx.restore();
    }

    Canvas {
        id: timelineSurface
        objectName: "timelineSurface"
        anchors.fill: timelineViewport
        onPaint: {
            var ctx = getContext("2d");
            ctx.reset();
            ctx.fillStyle = theme.background;
            ctx.fillRect(0, 0, width, height);
            ctx.fillStyle = theme.header;
            ctx.fillRect(0, 0, width, rulerHeight);
            var wanted = 64 / pixelsPerFrame;
            var power = Math.pow(10, Math.floor(Math.log(wanted) / Math.LN10));
            var fraction = wanted / power;
            var step = Math.max(1, (fraction <= 1 ? 1 : fraction <= 2 ? 2 : fraction <= 5 ? 5 : 10) * power);
            var first = Math.ceil(viewStart / step) * step;
            ctx.font = "10px sans-serif";
            ctx.fillStyle = theme.muted;
            for (var frame = first; frame <= viewStart + (width - labelWidth) / pixelsPerFrame; frame += step) {
                var tickX = frameToX(frame);
                if (tickX < labelWidth)
                    continue;
                ctx.strokeStyle = theme.muted;
                ctx.lineWidth = 1;
                ctx.beginPath();
                ctx.moveTo(tickX + 0.5, rulerHeight - 6);
                ctx.lineTo(tickX + 0.5, rulerHeight);
                ctx.stroke();
                var label = String(Math.round(frame));
                if (tickX + ctx.measureText(label).width + 5 < width)
                    ctx.fillText(label, tickX + 4, 13);
            }
            ctx.save();
            ctx.beginPath();
            ctx.rect(0, rulerHeight, width, Math.max(0, height - rulerHeight));
            ctx.clip();
            ctx.fillStyle = theme.panel;
            ctx.fillRect(0, rulerHeight, labelWidth, height - rulerHeight);
            for (var i = 0; i < tracks.length; ++i) {
                var track = tracks[i];
                if (!track)
                    continue;
                var y = trackY(i);
                var h = trackHeight(i);
                ctx.fillStyle = theme.background;
                ctx.fillRect(labelWidth, y, width - labelWidth, h);
                ctx.fillStyle = track.targeted ? theme.raised : theme.panel;
                ctx.fillRect(0, y, labelWidth, h);
                ctx.strokeStyle = theme.border;
                ctx.beginPath();
                ctx.moveTo(0, y + h + 0.5);
                ctx.lineTo(width, y + h + 0.5);
                ctx.stroke();
                ctx.fillStyle = theme.text;
                ctx.font = "11px sans-serif";
                ctx.fillText(String(track.name || track.id || "Track"), 10, y + 17);
                if (track.targeted) {
                    ctx.fillStyle = theme.accent;
                    ctx.fillRect(0, y + 3, 2, h - 6);
                }
                if (track.solo) {
                    ctx.fillStyle = theme.accent;
                    ctx.fillText("S", labelWidth - 15, y + 16);
                }
                var keys = ["locked", track.kind === "audio" ? "muted" : "visible", "targeted"];
                for (var ci = 0; ci < keys.length; ++ci) {
                    var key = keys[ci];
                    var exceptional = key === "locked" ? track.locked : key === "muted" ? track.muted : key === "visible" ? !track.visible : false;
                    if (!(hoverInHeader && hoverTrackIndex === i) && !exceptional)
                        continue;
                    drawTrackControl(ctx, key, labelWidth - 66 + ci * 22 + 11, y + h - 13, exceptional || (key === "targeted" && track.targeted));
                }
            }
            ctx.save();
            ctx.beginPath();
            ctx.rect(labelWidth, rulerHeight, Math.max(0, width - labelWidth), Math.max(0, height - rulerHeight));
            ctx.clip();
            var paintClips = clipsForPaint();
            for (var j = 0; j < paintClips.length; ++j) {
                var painted = paintClips[j];
                if (painted)
                    drawClip(ctx, painted, selectedIds.indexOf(String(painted.id)) >= 0, hoverClipId === String(painted.id));
            }
            ctx.restore();
            ctx.restore();
            ctx.strokeStyle = theme.border;
            ctx.beginPath();
            ctx.moveTo(labelWidth + 0.5, 0);
            ctx.lineTo(labelWidth + 0.5, height);
            ctx.stroke();
            ctx.save();
            ctx.beginPath();
            ctx.rect(labelWidth, 0, Math.max(0, width - labelWidth), height);
            ctx.clip();
            if (dropSourceId.length > 0 && dropTrackId.length > 0) {
                var dropTrackIndex = trackIndex(dropTrackId);
                var dropSource = sourceById(dropSourceId);
                if (dropTrackIndex >= 0 && dropSource) {
                    var dropWidth = Math.max(2, Math.round(Number(dropSource.duration) || 48) * pixelsPerFrame);
                    var dropX = frameToX(dropFrame);
                    var dropY = trackY(dropTrackIndex) + 4;
                    ctx.fillStyle = Qt.rgba(theme.accent.r, theme.accent.g, theme.accent.b, dropValid ? 0.24 : 0.10);
                    ctx.fillRect(dropX, dropY, dropWidth, Math.max(14, trackHeight(dropTrackIndex) - 8));
                    ctx.strokeStyle = dropValid ? theme.accent : theme.muted;
                    ctx.strokeRect(dropX + 0.5, dropY + 0.5, Math.max(1, dropWidth - 1), Math.max(1, trackHeight(dropTrackIndex) - 9));
                }
            }
            if (model && Number(model.inFrame) >= 0) {
                ctx.fillStyle = Qt.rgba(theme.accent.r, theme.accent.g, theme.accent.b, 0.11);
                ctx.fillRect(frameToX(model.inFrame), rulerHeight, frameToX(Number(model.outFrame) >= 0 ? model.outFrame : sequenceEnd()) - frameToX(model.inFrame), height - rulerHeight);
                ctx.strokeStyle = theme.accent;
                ctx.beginPath();
                ctx.moveTo(frameToX(model.inFrame) + 0.5, 0);
                ctx.lineTo(frameToX(model.inFrame) + 0.5, height);
                ctx.stroke();
            }
            if (model && Number(model.outFrame) >= 0) {
                ctx.strokeStyle = theme.accent;
                ctx.beginPath();
                ctx.moveTo(frameToX(model.outFrame) + 0.5, 0);
                ctx.lineTo(frameToX(model.outFrame) + 0.5, height);
                ctx.stroke();
            }
            if (gesture && snapGuideFrame >= 0) {
                ctx.strokeStyle = theme.muted;
                ctx.setLineDash([3, 3]);
                ctx.beginPath();
                ctx.moveTo(frameToX(snapGuideFrame), rulerHeight);
                ctx.lineTo(frameToX(snapGuideFrame), height);
                ctx.stroke();
                ctx.setLineDash([]);
            }
            var playX = frameToX(currentFrame);
            ctx.strokeStyle = theme.accent;
            ctx.lineWidth = 1.5;
            ctx.beginPath();
            ctx.moveTo(playX + 0.5, 0);
            ctx.lineTo(playX + 0.5, height);
            ctx.stroke();
            ctx.fillStyle = theme.accent;
            ctx.beginPath();
            ctx.moveTo(playX - 6, 0);
            ctx.lineTo(playX + 6, 0);
            ctx.lineTo(playX, 7);
            ctx.closePath();
            ctx.fill();
            if (marqueeRect) {
                var mx = Math.min(marqueeRect.x1, marqueeRect.x2);
                var my = Math.min(marqueeRect.y1, marqueeRect.y2);
                ctx.fillStyle = Qt.rgba(theme.accent.r, theme.accent.g, theme.accent.b, 0.16);
                ctx.fillRect(mx, my, Math.abs(marqueeRect.x2 - marqueeRect.x1), Math.abs(marqueeRect.y2 - marqueeRect.y1));
                ctx.strokeStyle = theme.accent;
                ctx.strokeRect(mx + 0.5, my + 0.5, Math.abs(marqueeRect.x2 - marqueeRect.x1), Math.abs(marqueeRect.y2 - marqueeRect.y1));
            }
            ctx.restore();
        }
    }

    Item {
        id: timelineViewport
        objectName: "timelineViewport"
        anchors.fill: parent
        clip: true
        z: 2

        ScrollBar {
            id: verticalScrollBar
            objectName: "timelineVerticalScroll"
            z: 10
            anchors.top: parent.top
            anchors.topMargin: rulerHeight
            anchors.right: parent.right
            anchors.bottom: parent.bottom
            orientation: Qt.Vertical
            policy: ScrollBar.AsNeeded
            size: Math.min(1, height / Math.max(1, contentHeight() - rulerHeight))
            position: scrollY / Math.max(1, contentHeight() - rulerHeight)
            onPositionChanged: {
                if (pressed)
                    scrollY = Math.max(0, Math.min(maxScrollY(), position * (contentHeight() - rulerHeight)));
            }
        }
    }

    property string dropSourceId: ""
    property var dropSourceIds: []
    property string dropTrackId: ""
    property int dropFrame: 0
    property bool dropValid: false
    property var dropOperation: null

    function dropSourceIdsFor(drag) {
        var values = [];
        if (drag && drag.source && drag.source.sourceIds)
            values = drag.source.sourceIds;
        if ((!values || values.length === 0) && drag && drag.mimeData && drag.mimeData.sourceIds)
            values = drag.mimeData.sourceIds;
        if (!values || values.length === 0) {
            var one = dropSourceIdFor(drag);
            if (one)
                values = [one];
        }
        var result = [];
        for (var i = 0; i < (values || []).length; ++i) {
            var id = String(values[i]);
            if (id)
                result.push(id);
        }
        return result;
    }

    function dropSourceIdFor(drag) {
        var sourceId = "";
        if (drag && drag.source && drag.source.sourceId !== undefined)
            sourceId = String(drag.source.sourceId);
        if (!sourceId && drag && drag.mimeData && drag.mimeData.sourceId !== undefined)
            sourceId = String(drag.mimeData.sourceId);
        if (!sourceId && drag && drag.mimeData && drag.mimeData["application/x-nemo-source-id"] !== undefined)
            sourceId = String(drag.mimeData["application/x-nemo-source-id"]);
        if (!sourceId && drag && drag.text)
            sourceId = String(drag.text);
        return sourceId;
    }

    function dropOperationFor(ids, target, frame, sourceGroup) {
        if (!ids.length || !target)
            return null;
        var first = sourceById(ids[0]);
        if (!first)
            return null;
        var primaryRange = sourceRangeFor(first, sourceGroup);
        if (!primaryRange)
            return null;
        if (ids.length === 1)
            return {
                "type": "insert",
                "sourceId": first.id,
                "trackId": target.id,
                "frame": Math.round(frame),
                "sourceIn": primaryRange.sourceIn,
                "sourceDuration": primaryRange.sourceDuration,
                "duration": primaryRange.duration
            };
        var audio = first.kind === "video" ? targetTrack("audio") : null;
        var input = [];
        var offset = 0;
        for (var i = 0; i < ids.length; ++i) {
            var source = sourceById(ids[i]);
            var range = sourceRangeFor(source, sourceGroup);
            if (!source || !range || source.kind !== first.kind || (source.kind === "video" && source.hasAudio && !audio))
                return null;
            var linkId = source.kind === "video" && source.hasAudio ? "drop-" + i : "";
            input.push({
                    "trackId": target.id,
                    "sourceId": source.id,
                    "name": source.name,
                    "start": offset,
                    "duration": range.duration,
                    "sourceIn": range.sourceIn,
                    "sourceDuration": range.sourceDuration,
                    "linkId": linkId,
                    "color": source.color
                });
            if (source.kind === "video" && source.hasAudio)
                input.push({
                        "trackId": audio.id,
                        "sourceId": source.id,
                        "name": source.name,
                        "start": offset,
                        "duration": range.duration,
                        "sourceIn": range.sourceIn,
                        "sourceDuration": range.sourceDuration,
                        "linkId": linkId,
                        "color": source.color
                    });
            offset += range.duration;
        }
        return {
            "type": "paste",
            "clips": input,
            "trackId": target.id,
            "frame": Math.round(frame),
            "mode": "insert"
        };
    }

    function inspectDrop(drag) {
        dropSourceIds = dropSourceIdsFor(drag);
        dropSourceId = dropSourceIds.length > 0 ? String(dropSourceIds[0]) : "";
        dropFrame = xToFrame(drag ? drag.x : 0);
        var index = trackAtY(drag ? drag.y : 0);
        var target = index >= 0 ? tracks[index] : null;
        var source = sourceById(dropSourceId);
        dropTrackId = target ? String(target.id) : "";
        previewActive = false;
        previewError = "";
        dropOperation = null;
        dropValid = !!(source && target && drag && drag.x > labelWidth && drag.y >= rulerHeight && !target.locked && source.kind === target.kind);
        for (var sourceIndex = 1; dropValid && sourceIndex < dropSourceIds.length; ++sourceIndex) {
            var nextSource = sourceById(dropSourceIds[sourceIndex]);
            dropValid = !!(nextSource && nextSource.kind === source.kind);
        }
        if (dropValid)
            dropOperation = dropOperationFor(dropSourceIds, target, dropFrame, drag && drag.source ? drag.source.sourceGroup : panelGroup);
        dropValid = dropValid && !!dropOperation;
        if (dropValid && model && typeof model.preview === "function") {
            var candidate = model.preview(dropOperation);
            dropValid = !!(candidate && candidate.ok);
            previewError = candidate && !candidate.ok && candidate.error ? String(candidate.error) : "";
            previewActive = dropValid;
            previewClips = dropValid ? candidate.clips : [];
        }
        if (drag)
            drag.accepted = !!source;
        timelineSurface.requestPaint();
    }

    DropArea {
        id: sourceDrop
        objectName: "timelineDropArea"
        anchors.fill: timelineViewport
        keys: ["application/x-nemo-source", "application/x-nemo-source-id", "text/plain"]
        onEntered: function (drag) {
            inspectDrop(drag);
        }
        onPositionChanged: function (drag) {
            inspectDrop(drag);
        }
        onExited: {
            dropValid = false;
            dropSourceId = "";
            dropSourceIds = [];
            dropOperation = null;
            previewActive = false;
            previewError = "";
            timelineSurface.requestPaint();
        }
        onDropped: function (drop) {
            inspectDrop(drop);
            if (dropValid && dropOperation) {
                drop.acceptProposedAction();
                commitOperation(dropOperation);
            } else {
                drop.accepted = false;
            }
            dropValid = false;
            dropSourceId = "";
            dropSourceIds = [];
            dropOperation = null;
            previewActive = false;
            previewError = "";
            timelineSurface.requestPaint();
        }
    }

    MouseArea {
        id: timelineInput
        objectName: "timelineInput"
        anchors.fill: timelineViewport
        hoverEnabled: true
        acceptedButtons: Qt.LeftButton | Qt.RightButton | Qt.MiddleButton
        cursorShape: gesture === "resize" ? Qt.SizeVerCursor : Math.abs(mouseX - labelWidth) < 5 || gesture === "labelResize" ? Qt.SizeHorCursor : tool === "blade" ? Qt.CrossCursor : tool !== "select" || (hoverClipId && edgeAt(clipById(hoverClipId), mouseX)) ? Qt.SizeHorCursor : Qt.ArrowCursor
        ToolTip.visible: containsMouse && hoverInHeader && hoverTrackControl !== ""
        ToolTip.delay: 450
        ToolTip.text: ({
                "locked": "Lock track",
                "muted": "Mute audio",
                "visible": "Show video",
                "targeted": "Target track for insertion"
            })[hoverTrackControl] || ""
        onExited: {
            hoverClipId = "";
            hoverInHeader = false;
            hoverTrackControl = "";
            timelineSurface.requestPaint();
        }
        onPressed: function (mouse) {
            timelinePanel.forceActiveFocus();
            var cx = mouse.x;
            var cy = mouse.y;
            var trackIndexAt = trackAtY(cy);
            var track = trackIndexAt >= 0 ? tracks[trackIndexAt] : null;
            if (mouse.button === Qt.RightButton) {
                var rightClip = clipAt(cx, cy);
                if (rightClip) {
                    if (selectedIds.indexOf(String(rightClip.id)) < 0)
                        selectIds([rightClip.id], false, false);
                    var clipPoint = timelineInput.mapToItem(timelinePanel, mouse.x, mouse.y);
                    clipMenu.x = clipPoint.x;
                    clipMenu.y = clipPoint.y;
                    clipMenu.open();
                } else if (track) {
                    trackContextId = String(track.id);
                    var trackPoint = timelineInput.mapToItem(timelinePanel, mouse.x, mouse.y);
                    trackMenu.x = trackPoint.x;
                    trackMenu.y = trackPoint.y;
                    trackMenu.open();
                } else {
                    openEditorMenu(timelineInput);
                }
                mouse.accepted = true;
                return;
            }
            if (mouse.button === Qt.MiddleButton) {
                beginGesture("pan", null, {
                        "x": cx,
                        "y": cy,
                        "modifiers": mouse.modifiers
                    }, "");
                gestureLastViewportX = mouse.x;
                gestureLastViewportY = mouse.y;
                mouse.accepted = true;
                return;
            }
            if (cy < rulerHeight) {
                beginGesture("scrub", null, {
                        "x": cx,
                        "y": cy,
                        "modifiers": mouse.modifiers
                    }, "");
                setPlayhead(xToFrame(cx));
                mouse.accepted = true;
                return;
            }
            if (Math.abs(cx - labelWidth) <= 5) {
                beginGesture("labelResize", null, {
                        "x": cx,
                        "y": cy,
                        "modifiers": mouse.modifiers
                    }, "");
                mouse.accepted = true;
                return;
            }
            if (track && cx < labelWidth) {
                var control = trackControlAt(cx, cy);
                if (control) {
                    var changes = {};
                    if (control === "visible")
                        changes.visible = track.visible === false;
                    else if (control === "targeted") {
                        changes.targeted = !track.targeted;
                    } else
                        changes[control] = !track[control];
                    applyTrackChanges(track.id, changes);
                    mouse.accepted = true;
                    return;
                }
                if (cy < trackY(trackIndexAt) + trackHeight(trackIndexAt) - 5) {
                    applyTrackChanges(track.id, {
                            "targeted": true
                        });
                    return;
                }
            }
            if (track && cy >= trackY(trackIndexAt) + trackHeight(trackIndexAt) - 5) {
                beginGesture("resize", null, {
                        "x": cx,
                        "y": cy,
                        "modifiers": mouse.modifiers
                    }, "");
                gestureStartTrackIndex = trackIndexAt;
                resizeHeight = trackHeight(trackIndexAt);
                mouse.accepted = true;
                return;
            }
            var hit = clipAt(cx, cy);
            if (tool === "blade") {
                if (hit) {
                    selectIds([hit.id], (mouse.modifiers & Qt.ShiftModifier) !== 0, false);
                    var bladeFrame = snapFrame(xToFrame(cx), [hit.id]);
                    if (bladeFrame > Number(hit.start) && bladeFrame < Number(hit.start) + Number(hit.duration))
                        commitOperation({
                                "type": "cut",
                                "ids": linkedIds([hit.id]),
                                "frame": bladeFrame,
                                "linked": linkedSelection
                            });
                } else {
                    cutAtPlayhead();
                }
                mouse.accepted = true;
                return;
            }
            if (hit) {
                var additive = (mouse.modifiers & Qt.ShiftModifier) !== 0;
                var toggle = (mouse.modifiers & Qt.ControlModifier) !== 0;
                if (toggle)
                    selectIds([hit.id], true, true);
                else if (selectedIds.indexOf(String(hit.id)) < 0)
                    selectIds([hit.id], additive, false);
                var hitEdge = edgeAt(hit, cx);
                if (!hitEdge && (tool === "ripple" || tool === "roll")) {
                    var hitMiddle = frameToX(Number(hit.start) + Number(hit.duration) / 2);
                    hitEdge = cx < hitMiddle ? "in" : "out";
                }
                var gestureTool = tool === "ripple" || tool === "roll" ? tool : tool === "slip" || tool === "slide" ? tool : hitEdge ? "trim" : "move";
                beginGesture(gestureTool, hit, {
                        "x": cx,
                        "y": cy,
                        "modifiers": mouse.modifiers
                    }, hitEdge);
            } else {
                if ((mouse.modifiers & Qt.ShiftModifier) === 0 && (mouse.modifiers & Qt.ControlModifier) === 0)
                    selectedIds = [];
                beginGesture("marquee", null, {
                        "x": cx,
                        "y": cy,
                        "modifiers": mouse.modifiers
                    }, "");
            }
            mouse.accepted = true;
        }
        onPositionChanged: function (mouse) {
            var cx = mouse.x;
            var cy = mouse.y;
            var hit = clipAt(cx, cy);
            hoverClipId = hit ? String(hit.id) : "";
            hoverTrackIndex = trackAtY(cy);
            hoverInHeader = cx < labelWidth;
            hoverTrackControl = trackControlAt(cx, cy);
            if (pressed && gesture) {
                var event = {
                    "x": cx,
                    "y": cy,
                    "modifiers": mouse.modifiers
                };
                if (gesture === "pan") {
                    var dx = mouse.x - gestureLastViewportX;
                    var dy = mouse.y - gestureLastViewportY;
                    viewStart -= dx / Math.max(0.01, pixelsPerFrame);
                    scrollY = Math.max(0, Math.min(maxScrollY(), scrollY - dy));
                    gestureLastViewportX = mouse.x;
                    gestureLastViewportY = mouse.y;
                } else {
                    updateGesture(event);
                }
            }
            timelineSurface.requestPaint();
        }
        onReleased: function (mouse) {
            if (gesture === "pan") {
                cancelGesture();
                return;
            }
            if (gesture)
                finishGesture();
        }
        onCanceled: cancelGesture()
        onWheel: function (wheel) {
            wheel.accepted = true;
            var amount = wheel.pixelDelta.y !== 0 ? wheel.pixelDelta.y : wheel.angleDelta.y;
            if ((wheel.modifiers & Qt.ControlModifier) !== 0 || (wheel.modifiers & Qt.MetaModifier) !== 0) {
                var frameAtCursor = viewStart + (wheel.x - labelWidth) / pixelsPerFrame;
                pixelsPerFrame = Math.max(0.03, Math.min(24, pixelsPerFrame * Math.pow(1.16, amount / 120)));
                viewStart = frameAtCursor - (wheel.x - labelWidth) / Math.max(0.01, pixelsPerFrame);
            } else if ((wheel.modifiers & Qt.ShiftModifier) !== 0) {
                viewStart += amount / Math.max(0.01, pixelsPerFrame);
            } else {
                scrollY = Math.max(0, Math.min(maxScrollY(), scrollY - amount));
            }
            timelineSurface.requestPaint();
        }
    }

    Timer {
        id: initialFitTimer
        interval: 16
        repeat: false
        onTriggered: {
            if (initialFitDone)
                return;
            if (timelineViewport.width > labelWidth + 40 && timelineViewport.height > rulerHeight + 20) {
                frameAll();
                initialFitDone = true;
            } else {
                restart();
            }
        }
    }
    Timer {
        id: autoScrollTimer
        interval: 30
        repeat: true
        running: ["move", "trim", "ripple", "roll", "slip", "slide", "marquee"].indexOf(gesture) >= 0
        onTriggered: autoScroll()
    }

    Timer {
        id: statusTimer
        interval: 2200
        onTriggered: statusMessage = ""
    }

    Timer {
        id: transportTimer
        interval: Math.max(1, Math.round(1000 / Math.max(1, Number(model.fps) || 24)))
        repeat: true
        running: transportPlaying
        onTriggered: {
            var first = model && Number(model.inFrame) >= 0 ? Number(model.inFrame) : model && Number(model.startFrame) >= 0 ? Number(model.startFrame) : 1001;
            var last = model && Number(model.outFrame) >= 0 ? Number(model.outFrame) - 1 : sequenceEnd() - 1;
            if (last < first)
                last = first;
            var next = currentFrame + 1;
            if (next > last)
                next = first;
            setPlayhead(next);
        }
    }

    Label {
        id: transientStatus
        objectName: "timelineTransientStatus"
        visible: statusMessage.length > 0 || (gesture && previewError.length > 0) || (dropSourceId.length > 0 && previewError.length > 0)
        anchors.top: timelineViewport.top
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.topMargin: 9
        z: 5
        padding: 6
        color: theme.text
        text: statusMessage.length > 0 ? statusMessage : previewError
        font.pixelSize: 11
        elide: Text.ElideRight
        background: Rectangle {
            color: statusIsError || previewError.length > 0 ? theme.raised : theme.field
            radius: theme.smallRadius
        }
    }

    Menu {
        id: editorMenu
        objectName: "timelineEditorMenu"
        MenuItem {
            text: "Select  V"
            checkable: true
            checked: tool === "select"
            onTriggered: setTool("select")
        }
        MenuItem {
            text: "Blade  B"
            checkable: true
            checked: tool === "blade"
            onTriggered: setTool("blade")
        }
        MenuItem {
            text: "Ripple  R"
            checkable: true
            checked: tool === "ripple"
            onTriggered: setTool("ripple")
        }
        MenuItem {
            text: "Roll  T"
            checkable: true
            checked: tool === "roll"
            onTriggered: setTool("roll")
        }
        MenuItem {
            text: "Slip  Y"
            checkable: true
            checked: tool === "slip"
            onTriggered: setTool("slip")
        }
        MenuItem {
            text: "Slide  U"
            checkable: true
            checked: tool === "slide"
            onTriggered: setTool("slide")
        }
        MenuSeparator {
        }
        MenuItem {
            text: "Snapping"
            checkable: true
            checked: snapping
            onTriggered: snapping = !snapping
        }
        MenuItem {
            text: "Linked selection"
            checkable: true
            checked: linkedSelection
            onTriggered: linkedSelection = !linkedSelection
        }
        MenuSeparator {
        }
        MenuItem {
            text: "Frame selected  F"
            onTriggered: frameSelected()
        }
        MenuItem {
            text: "Frame all  Home"
            onTriggered: frameAll()
        }
        MenuItem {
            text: "Undo  Ctrl+Z"
            enabled: model && model.canUndo
            onTriggered: model.undo()
        }
        MenuItem {
            text: "Redo  Ctrl+Shift+Z"
            enabled: model && model.canRedo
            onTriggered: model.redo()
        }
        MenuItem {
            text: "Paste insert  Ctrl+V"
            enabled: clipboardClips.length > 0
            onTriggered: pasteSelection("insert")
        }
        MenuItem {
            text: "Paste overwrite"
            enabled: clipboardClips.length > 0
            onTriggered: pasteSelection("overwrite")
        }
        MenuItem {
            text: "Cut at playhead  Ctrl+K"
            onTriggered: cutAtPlayhead()
        }
        MenuItem {
            text: "Clear marks"
            onTriggered: model && model.apply({
                    "type": "marks",
                    "inFrame": -1,
                    "outFrame": -1
                })
        }
        MenuSeparator {
        }
        MenuItem {
            text: "Add video track"
            onTriggered: model && model.apply({
                    "type": "addTrack",
                    "kind": "video"
                })
        }
        MenuItem {
            text: "Add audio track"
            onTriggered: model && model.apply({
                    "type": "addTrack",
                    "kind": "audio"
                })
        }
    }
    property string trackContextId: ""

    Menu {
        id: trackMenu
        objectName: "timelineTrackMenu"
        MenuItem {
            text: "Lock track"
            checkable: true
            checked: trackById(trackContextId) ? !!trackById(trackContextId).locked : false
            onTriggered: applyTrackChanges(trackContextId, {
                    "locked": checked
                })
        }
        MenuItem {
            text: "Mute track"
            checkable: true
            checked: trackById(trackContextId) ? !!trackById(trackContextId).muted : false
            onTriggered: applyTrackChanges(trackContextId, {
                    "muted": checked
                })
        }
        MenuItem {
            text: "Solo track"
            checkable: true
            checked: trackById(trackContextId) ? !!trackById(trackContextId).solo : false
            onTriggered: applyTrackChanges(trackContextId, {
                    "solo": checked
                })
        }
        MenuItem {
            text: "Show track"
            checkable: true
            checked: trackById(trackContextId) ? trackById(trackContextId).visible !== false : true
            onTriggered: applyTrackChanges(trackContextId, {
                    "visible": checked
                })
        }
        MenuItem {
            text: "Target track"
            checkable: true
            checked: trackById(trackContextId) ? !!trackById(trackContextId).targeted : false
            onTriggered: applyTrackChanges(trackContextId, {
                    "targeted": checked
                })
        }
        MenuItem {
            text: "Ripple track"
            checkable: true
            checked: trackById(trackContextId) ? trackById(trackContextId).ripple !== false : true
            onTriggered: applyTrackChanges(trackContextId, {
                    "ripple": checked
                })
        }
        MenuSeparator {
        }
        MenuItem {
            text: "Rename…"
            onTriggered: renameTrackDialog.openFor(trackContextId)
        }
        MenuItem {
            text: "Move track up"
            enabled: trackIndex(trackContextId) > 0
            onTriggered: model && model.apply({
                    "type": "reorderTrack",
                    "id": trackContextId,
                    "index": trackIndex(trackContextId) - 1
                })
        }
        MenuItem {
            text: "Move track down"
            enabled: trackIndex(trackContextId) >= 0 && trackIndex(trackContextId) < tracks.length - 1
            onTriggered: model && model.apply({
                    "type": "reorderTrack",
                    "id": trackContextId,
                    "index": trackIndex(trackContextId) + 1
                })
        }
        MenuSeparator {
        }
        MenuItem {
            text: "Add video track"
            onTriggered: model && model.apply({
                    "type": "addTrack",
                    "kind": "video"
                })
        }
        MenuItem {
            text: "Add audio track"
            onTriggered: model && model.apply({
                    "type": "addTrack",
                    "kind": "audio"
                })
        }
        MenuItem {
            text: "Remove track"
            enabled: tracks.length > 1
            onTriggered: model && model.apply({
                    "type": "removeTrack",
                    "id": trackContextId
                })
        }
    }

    Menu {
        id: clipMenu
        objectName: "timelineClipMenu"
        MenuItem {
            text: "Copy"
            onTriggered: copySelection()
        }
        MenuItem {
            text: "Delete"
            onTriggered: deleteSelection(false)
        }
        MenuItem {
            text: "Ripple delete"
            onTriggered: deleteSelection(true)
        }
        MenuSeparator {
        }
        MenuItem {
            text: "Trim tool"
            onTriggered: setTool("select")
        }
        MenuItem {
            text: "Slip tool"
            onTriggered: setTool("slip")
        }
    }

    Dialog {
        id: renameTrackDialog
        property string trackId: ""
        title: "Rename track"
        modal: true
        standardButtons: Dialog.Ok | Dialog.Cancel
        function openFor(id) {
            trackId = id;
            renameField.text = trackById(id) ? String(trackById(id).name || "") : "";
            open();
            renameField.forceActiveFocus();
            renameField.selectAll();
        }
        onAccepted: {
            var value = renameField.text.trim();
            if (value.length > 0)
                applyTrackChanges(trackId, {
                        "name": value
                    });
        }
        contentItem: TextField {
            id: renameField
            implicitWidth: 260
            selectByMouse: true
            placeholderText: "Track name"
        }
    }

    Connections {
        target: timelinePanel.model
        ignoreUnknownSignals: true
        function onRevisionChanged() {
            selectedIds = selectedIds.filter(function (id) {
                    return model.clip(id) !== null;
                });
            clampScroll();
            timelineSurface.requestPaint();
        }
        function onErrorChanged() {
            if (model && model.error && String(model.error).length > 0)
                flashStatus(model.error, true);
        }
    }
    Connections {
        target: studio
        ignoreUnknownSignals: true
        function onTimelineContextChanged(group) {
            if (String(group) === panelGroup) {
                contextRevision += 1;
                timelineSurface.requestPaint();
            }
        }
    }
    Connections {
        target: theme
        ignoreUnknownSignals: true
        function onBackgroundChanged() {
            timelineSurface.requestPaint();
        }
        function onPanelChanged() {
            timelineSurface.requestPaint();
        }
        function onHeaderChanged() {
            timelineSurface.requestPaint();
        }
        function onFieldChanged() {
            timelineSurface.requestPaint();
        }
        function onRaisedChanged() {
            timelineSurface.requestPaint();
        }
        function onBorderChanged() {
            timelineSurface.requestPaint();
        }
        function onTextChanged() {
            timelineSurface.requestPaint();
        }
        function onMutedChanged() {
            timelineSurface.requestPaint();
        }
        function onAccentChanged() {
            timelineSurface.requestPaint();
        }
    }

    Keys.onPressed: function (event) {
        var key = event.key;
        var modifiers = event.modifiers;
        if (gesture && key !== Qt.Key_Escape && (modifiers & Qt.ControlModifier))
            cancelGesture();
        if (key === Qt.Key_Escape) {
            if (gesture)
                cancelGesture();
            else {
                editorMenu.close();
                trackMenu.close();
                clipMenu.close();
            }
            event.accepted = true;
        } else if ((modifiers & Qt.ControlModifier) !== 0 && key === Qt.Key_Z && (modifiers & Qt.ShiftModifier) === 0) {
            if (model && typeof model.undo === "function")
                model.undo();
            event.accepted = true;
        } else if (((modifiers & Qt.ControlModifier) !== 0 && key === Qt.Key_Z && (modifiers & Qt.ShiftModifier) !== 0) || ((modifiers & Qt.ShiftModifier) !== 0 && key === Qt.Key_Z && (modifiers & Qt.ControlModifier) === 0)) {
            if (model && typeof model.redo === "function")
                model.redo();
            event.accepted = true;
        } else if ((modifiers & Qt.ControlModifier) !== 0 && key === Qt.Key_C) {
            copySelection();
            event.accepted = true;
        } else if ((modifiers & Qt.ControlModifier) !== 0 && key === Qt.Key_V) {
            pasteSelection("insert");
            event.accepted = true;
        } else if ((modifiers & Qt.ControlModifier) !== 0 && key === Qt.Key_K) {
            cutAtPlayhead();
            event.accepted = true;
        } else if (key === Qt.Key_Delete) {
            deleteSelection((modifiers & Qt.ShiftModifier) !== 0);
            event.accepted = true;
        } else if (key === Qt.Key_Space) {
            transportPlaying = !transportPlaying;
            event.accepted = true;
        } else if (key === Qt.Key_I) {
            commitOperation({
                    "type": "marks",
                    "inFrame": currentFrame,
                    "outFrame": model.outFrame
                });
            event.accepted = true;
        } else if (key === Qt.Key_O) {
            commitOperation({
                    "type": "marks",
                    "inFrame": model.inFrame,
                    "outFrame": currentFrame
                });
            event.accepted = true;
        } else if (key === Qt.Key_F) {
            frameSelected();
            event.accepted = true;
        } else if (key === Qt.Key_Home) {
            frameAll();
            event.accepted = true;
        } else if (key === Qt.Key_Left) {
            setPlayhead(currentFrame - 1);
            event.accepted = true;
        } else if (key === Qt.Key_Right) {
            setPlayhead(currentFrame + 1);
            event.accepted = true;
        } else if (!(modifiers & (Qt.ControlModifier | Qt.AltModifier | Qt.MetaModifier))) {
            if (key === Qt.Key_V)
                setTool("select");
            else if (key === Qt.Key_B)
                setTool("blade");
            else if (key === Qt.Key_R)
                setTool("ripple");
            else if (key === Qt.Key_T)
                setTool("roll");
            else if (key === Qt.Key_Y)
                setTool("slip");
            else if (key === Qt.Key_U)
                setTool("slide");
            else
                return;
            event.accepted = true;
        }
    }

    onScrollYChanged: timelineSurface.requestPaint()
    onViewStartChanged: timelineSurface.requestPaint()
    onWidthChanged: {
        timelineSurface.requestPaint();
        if (!initialFitDone)
            initialFitTimer.restart();
    }
    onHeightChanged: {
        clampScroll();
        timelineSurface.requestPaint();
        if (!initialFitDone)
            initialFitTimer.restart();
    }
    Component.onCompleted: initialFitTimer.restart()
}
