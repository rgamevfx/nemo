import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

ApplicationWindow {
    id: window
    width: 1568
    height: 926
    minimumWidth: Math.max(960, rootNode.minimumPaneWidth + 16)
    minimumHeight: Math.max(640, rootNode.minimumPaneHeight + 56)
    visible: true
    title: "Nemo — Workspace prototype"
    color: theme.background
    font.family: "Inter"
    font.pixelSize: theme.fontSize
    palette.window: theme.panel
    palette.windowText: theme.text
    palette.base: theme.field
    palette.text: theme.text
    palette.button: theme.raised
    palette.buttonText: theme.text
    palette.highlight: theme.accent
    palette.highlightedText: "#ffffff"
    palette.mid: theme.border
    palette.dark: theme.border
    palette.light: theme.raised
    readonly property var controller: workspace


    Component.onCompleted: workspace.restoreSnapshot(studio.workspaces[studio.activeWorkspace].layout)
    onActiveChanged: if (!active)
        dockDrag.cancelDrag()

    function showMediaPanel(group) {
        var leaves = [];
        function collect(node) {
            if (node.kind === "tabs")
                leaves.push(node);
            else
                (node.children || []).forEach(collect);
        }
        collect(workspace.root);
        var target = null;
        for (var i = 0; i < leaves.length; ++i) {
            for (var j = 0; j < leaves[i].panels.length; ++j) {
                var panel = leaves[i].panels[j];
                if (panel.type === "mediabin" && panel.group === group)
                    target = {
                        "leaf": leaves[i].id,
                        "panel": panel.id
                    };
            }
        }
        if (!target && leaves.length) {
            var leafId = leaves[0].id;
            workspace.addTab(leafId, "mediabin");
            leaves = [];
            collect(workspace.root);
            for (var k = 0; k < leaves.length; ++k) {
                if (leaves[k].id === leafId) {
                    target = {
                        "leaf": leafId,
                        "panel": leaves[k].active
                    };
                    workspace.setGroup(target.panel, group);
                    break;
                }
            }
        }
        if (!target)
            return;
        workspace.activate(target.leaf, target.panel);
        var panelId = target.panel;
        Qt.callLater(function () {
                function focusMedia(item) {
                    if (item.panelId === panelId && item.objectName === "mediaBinPrototype") {
                        item.forceActiveFocus();
                        return true;
                    }
                    for (var n = 0; n < item.children.length; ++n)
                        if (focusMedia(item.children[n]))
                            return true;
                    return false;
                }
                focusMedia(rootNode);
            });
    }

    Connections {
        target: studio
        function onMediaPanelRequested(group) {
            window.showMediaPanel(group);
        }
        function onMediaInsertRequested(group, sourceIds, mode) {
            function findTimeline(item) {
                if (item.visible && item.objectName === "timelinePrototype" && item.panelGroup === group)
                    return item;
                for (var i = 0; i < item.children.length; ++i) {
                    var found = findTimeline(item.children[i]);
                    if (found)
                        return found;
                }
                return null;
            }
            var timeline = findTimeline(rootNode);
            if (!timeline) {
                studio.mediaInsertFinished(group, "Open a Timeline panel in group " + group + " to insert media");
                return;
            }
            var ok = timeline.insertSourcesAt(sourceIds, mode);
            studio.mediaInsertFinished(group, ok ? "" : timeline.statusMessage);
        }
    }

    component ChromeButton: Button {
        implicitHeight: 28
        padding: 8
        font.pixelSize: 11
        background: Rectangle {
            radius: 5
            color: parent.down ? theme.raised : parent.hovered ? theme.hover : "transparent"
        }
    }

    Rectangle {
        id: topBar
        height: 42
        anchors.top: parent.top
        anchors.left: parent.left
        anchors.right: parent.right
        color: theme.background
        Row {
            anchors.left: parent.left
            anchors.leftMargin: 16
            anchors.verticalCenter: parent.verticalCenter
            spacing: 12
            Text {
                text: "Nemo"
                color: theme.text
                font.pixelSize: 16
                font.weight: Font.DemiBold
                height: 28
                verticalAlignment: Text.AlignVCenter
            }
            ChromeButton {
                objectName: "themeSettingsButton"
                width: 30
                Accessible.name: "Appearance settings"
                onClicked: appearance.open()
                contentItem: Canvas {
                    id: settingsGlyph
                    onPaint: {
                        var ctx = getContext("2d");
                        ctx.reset();
                        ctx.strokeStyle = theme.muted;
                        ctx.lineWidth = 1.2;
                        var cx = width / 2, cy = height / 2;
                        ctx.beginPath();
                        ctx.arc(cx, cy, 4, 0, Math.PI * 2);
                        ctx.stroke();
                        for (var i = 0; i < 8; i++) {
                            var a = i * Math.PI / 4;
                            ctx.beginPath();
                            ctx.moveTo(cx + 5 * Math.cos(a), cy + 5 * Math.sin(a));
                            ctx.lineTo(cx + 7 * Math.cos(a), cy + 7 * Math.sin(a));
                            ctx.stroke();
                        }
                    }
                    Connections {
                        target: theme
                        function onPresetChanged() {
                            settingsGlyph.requestPaint();
                        }
                    }
                }
            }
        }
        Row {
            id: tabsRow
            anchors.centerIn: parent
            height: parent.height
            spacing: 3
            Flickable {
                width: Math.min(workspaceTabs.width, Math.max(280, window.width - 420))
                height: parent.height
                contentWidth: workspaceTabs.width
                contentHeight: height
                clip: true
                flickableDirection: Flickable.HorizontalFlick
                Row {
                    id: workspaceTabs
                    height: parent.height
                    spacing: 3
                    Repeater {
                        model: studio.workspaces
                        delegate: Button {
                            id: workspaceTab
                            required property var modelData
                            required property int index
                            objectName: "workspaceTab_" + modelData.name
                            width: Math.max(64, label.implicitWidth + 30)
                            height: 36
                            y: 6
                            padding: 0
                            onClicked: {
                                dockDrag.cancelDrag();
                                studio.switchWorkspace(index);
                            }
                            contentItem: Text {
                                id: label
                                text: workspaceTab.modelData.name
                                color: studio.activeWorkspace === workspaceTab.index ? theme.text : theme.muted
                                font.pixelSize: 12
                                font.weight: studio.activeWorkspace === workspaceTab.index ? Font.Medium : Font.Normal
                                horizontalAlignment: Text.AlignHCenter
                                verticalAlignment: Text.AlignVCenter
                            }
                            background: Rectangle {
                                radius: 6
                                color: studio.activeWorkspace === workspaceTab.index ? theme.header : workspaceTab.hovered ? theme.panel : "transparent"
                                Rectangle {
                                    anchors.bottom: parent.bottom
                                    anchors.horizontalCenter: parent.horizontalCenter
                                    width: parent.width - 18
                                    height: 2
                                    radius: 1
                                    color: theme.accent
                                    visible: studio.activeWorkspace === workspaceTab.index
                                }
                            }
                            MouseArea {
                                anchors.fill: parent
                                acceptedButtons: Qt.RightButton
                                onClicked: {
                                    workspaceMenu.targetIndex = workspaceTab.index;
                                    workspaceMenu.popup();
                                }
                            }
                        }
                    }
                }
            }
            ChromeButton {
                objectName: "addWorkspaceButton"
                anchors.verticalCenter: parent.verticalCenter
                width: 28
                text: "+"
                font.pixelSize: 17
                Accessible.name: "Create workspace from current layout"
                onClicked: {
                    nameDialog.renaming = false;
                    workspaceName.text = "Workspace " + (studio.workspaces.length + 1);
                    nameDialog.open();
                }
            }
        }
        ChromeButton {
            anchors.right: parent.right
            anchors.rightMargin: 12
            anchors.verticalCenter: parent.verticalCenter
            text: "…"
            font.pixelSize: 17
            Accessible.name: "Workspace options"
            onClicked: {
                workspaceMenu.targetIndex = studio.activeWorkspace;
                workspaceMenu.popup();
            }
        }
    }

    Menu {
        id: workspaceMenu
        property int targetIndex: 0
        MenuItem {
            text: "Rename workspace"
            onTriggered: {
                nameDialog.renaming = true;
                nameDialog.targetIndex = workspaceMenu.targetIndex;
                workspaceName.text = studio.workspaces[workspaceMenu.targetIndex].name;
                nameDialog.open();
            }
        }
        MenuItem {
            text: "Duplicate workspace"
            onTriggered: {
                studio.switchWorkspace(workspaceMenu.targetIndex);
                nameDialog.renaming = false;
                workspaceName.text = studio.workspaces[workspaceMenu.targetIndex].name + " copy";
                nameDialog.open();
            }
        }
        MenuSeparator {
        }
        MenuItem {
            text: "Move left"
            enabled: workspaceMenu.targetIndex > 0
            onTriggered: studio.moveWorkspace(workspaceMenu.targetIndex, -1)
        }
        MenuItem {
            text: "Move right"
            enabled: workspaceMenu.targetIndex < studio.workspaces.length - 1
            onTriggered: studio.moveWorkspace(workspaceMenu.targetIndex, 1)
        }
        MenuSeparator {
        }
        MenuItem {
            text: "Close workspace"
            enabled: studio.workspaces.length > 1
            onTriggered: studio.closeWorkspace(workspaceMenu.targetIndex)
        }
    }
    Dialog {
        id: nameDialog
        property bool renaming: false
        property int targetIndex: 0
        anchors.centerIn: parent
        width: 310
        title: renaming ? "Rename workspace" : "New workspace"
        modal: true
        standardButtons: Dialog.Ok | Dialog.Cancel
        onOpened: {
            workspaceName.forceActiveFocus();
            workspaceName.selectAll();
        }
        onAccepted: {
            if (renaming)
                studio.renameWorkspace(targetIndex, workspaceName.text);
            else
                studio.duplicateWorkspace(workspaceName.text);
        }
        TextField {
            id: workspaceName
            objectName: "workspaceNameField"
            width: parent.width
            selectByMouse: true
            onAccepted: nameDialog.accept()
        }
    }
    Popup {
        id: appearance
        objectName: "appearancePopup"
        x: 80
        y: 40
        width: 344
        padding: 16
        background: Rectangle {
            color: theme.header
            radius: theme.radius
            border.color: theme.border
        }
        contentItem: ColumnLayout {
            spacing: 12
            Text {
                text: "Appearance"
                color: theme.text
                font.pixelSize: 12
                font.weight: Font.Medium
            }
            RowLayout {
                Text {
                    text: "Theme"
                    color: theme.muted
                    font.pixelSize: theme.fontSize
                    Layout.fillWidth: true
                }
                StudioComboBox {
                    objectName: "themePresetMenu"
                    model: ["Graphite", "Slate", "Paper"]
                    currentIndex: model.indexOf(theme.preset)
                    implicitWidth: 142
                    implicitHeight: 28
                    onActivated: theme.preset = currentText
                }
            }
            RowLayout {
                Text {
                    text: "Accent"
                    color: theme.muted
                    font.pixelSize: theme.fontSize
                    Layout.fillWidth: true
                }
                Rectangle {
                    width: 18
                    height: 18
                    radius: 9
                    color: theme.accent
                }
                TextField {
                    id: accentField
                    objectName: "accentColorField"
                    text: theme.accent.toString()
                    implicitWidth: 112
                    implicitHeight: 28
                    selectByMouse: true
                    validator: RegularExpressionValidator {
                        regularExpression: /#[0-9a-fA-F]{6}/
                    }
                    onEditingFinished: if (acceptableInput)
                        theme.accentOverride = text
                }
            }
            ChromeButton {
                text: "Reset accent"
                onClicked: {
                    theme.accentOverride = "";
                    accentField.text = theme.accent.toString();
                }
            }
            Text {
                text: "Node category colors"
                color: theme.muted
                font.pixelSize: theme.fontSize
            }
            ScrollView {
                id: categoryScroll
                Layout.fillWidth: true
                Layout.preferredHeight: Math.min(300, categoryColumn.implicitHeight)
                clip: true
                ColumnLayout {
                    id: categoryColumn
                    width: categoryScroll.availableWidth
                    spacing: 6
                    Repeater {
                        model: studio.nodeCategories
                        delegate: RowLayout {
                            id: categoryRow
                            required property var modelData
                            property string categoryId: String(modelData.id)
                            Layout.fillWidth: true
                            spacing: 7
                            Text {
                                text: categoryRow.modelData.label
                                color: theme.text
                                font.pixelSize: theme.fontSize
                                Layout.fillWidth: true
                                elide: Text.ElideRight
                            }
                            Rectangle {
                                width: 18
                                height: 18
                                radius: 4
                                color: theme.nodeCategoryColor(categoryRow.categoryId)
                                border.color: theme.border
                            }
                            TextField {
                                id: categoryField
                                objectName: "categoryColorField_" + categoryRow.categoryId
                                text: theme.nodeCategoryColor(categoryRow.categoryId)
                                implicitWidth: 112
                                implicitHeight: 28
                                selectByMouse: true
                                Accessible.name: categoryRow.modelData.label + " node category color"
                                validator: RegularExpressionValidator {
                                    regularExpression: /#[0-9a-fA-F]{6}/
                                }
                                onEditingFinished: {
                                    if (acceptableInput)
                                        theme.setNodeCategoryColor(categoryRow.categoryId, text);
                                    text = theme.nodeCategoryColor(categoryRow.categoryId);
                                }
                                Connections {
                                    target: theme
                                    function onNodeCategoryColorsChanged() {
                                        categoryField.text = theme.nodeCategoryColor(categoryRow.categoryId);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            ChromeButton {
                objectName: "resetNodeCategoryColorsButton"
                text: "Reset node category colors"
                Layout.fillWidth: true
                onClicked: theme.resetNodeCategoryColors()
            }
        }
    }

    DockDrag {
        id: dockDrag
        objectName: "dockDrag"
        anchors.fill: parent
        z: 10
        workspace: window.controller
    }
    WorkspaceNode {
        id: rootNode
        anchors {
            top: topBar.bottom
            left: parent.left
            right: parent.right
            bottom: parent.bottom
            margins: 8
            topMargin: 2
        }
        node: workspace.root
        workspace: window.controller
        drag: dockDrag
    }
    Rectangle {
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.bottom: parent.bottom
        height: workspace.error.length ? 24 : 0
        visible: height > 0
        color: "#613331"
        Text {
            anchors.centerIn: parent
            text: workspace.error
            color: "#ffffff"
            font.pixelSize: 11
        }
    }
    Shortcut {
        sequence: "Ctrl+Shift+R"
        onActivated: workspace.restoreSnapshot(studio.layout(studio.workspaces[studio.activeWorkspace].name))
    }
    Shortcut {
        sequence: "Esc"
        context: Qt.ApplicationShortcut
        enabled: dockDrag.active
        onActivated: dockDrag.cancelDrag()
    }
}
