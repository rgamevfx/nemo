import QtQuick

// Session-only fixture model. No Document, renderer, or persistent project is involved.
QtObject {
    id: studioModel

    // `nodes` and `edges` are the active graph arrays. `graphs` owns every graph so
    // inspectors and parameter panels can continue resolving nodes while navigating.
    property var nodes: []
    property var edges: []
    property var graphs: ({})
    property string activeGraphId: "root"
    property var breadcrumbs: []
    property var selectedNodeIds: []
    property string selectedNodeId: ""
    property string viewerNodeId: "merge1"
    property string graphError: ""
    property int revision: 0
    property int frame: 1001
    readonly property TimelineModel timeline: TimelineModel {
    }
    readonly property MediaCatalog media: MediaCatalog {
        timeline: studioModel.timeline
    }
    // Viewing state is keyed by the compact A-E panel-link group. A group
    // never reads another group's source, graph target, or playhead.
    property var _mediaContexts: ({})
    property var _mediaSourceContexts: ({})
    property var _timelineContexts: ({})
    property var _graphTimeContexts: ({})
    property var _graphContexts: ({})
    property var _viewerRoles: ({})
    property bool _syncingCompatibilityFrame: false
    property int mediaRevision: 0
    readonly property var groupKeys: ["A", "B", "C", "D", "E"]
    // Animation is session-only state keyed by stable graph node and parameter IDs.
    property var animationChannels: []
    property int animationRevision: 0
    property string animationError: ""
    property var selectedAnimationKeyIds: []
    property var selectedAnimationChannelIds: []
    property int _animationKeySerial: 1
    // Animation undo is session-only and intentionally independent from graph history.
    property var _animationUndoStack: []
    property var _animationRedoStack: []
    property int _animationEditDepth: 0
    property var _animationEditBefore: null
    property var _animationHistorySnapshot: []
    readonly property bool canUndoAnimation: _animationEditDepth === 0 && (_animationUndoStack || []).length > 0
    readonly property bool canRedoAnimation: _animationEditDepth === 0 && (_animationRedoStack || []).length > 0
    property var panelStates: ({})
    property var workspaces: []
    property int activeWorkspace: 1
    property int serial: 10
    property var nodeCategories: [({
                "id": "Color",
                "label": "Color",
                "types": ["ColorCorrect", "Grade"]
            }), ({
                "id": "Distort",
                "label": "Distort",
                "types": ["Transform"]
            }), ({
                "id": "Filter",
                "label": "Filter",
                "types": ["Blur"]
            }), ({
                "id": "Utility",
                "label": "Utility",
                "types": ["Dot"]
            }), ({
                "id": "Merge",
                "label": "Merge",
                "types": ["Merge"]
            }), ({
                "id": "IO",
                "label": "I/O",
                "types": ["Read", "Viewer"]
            })]
    readonly property real graphNodeHeight: 28
    readonly property real graphNodeWidth: 112

    signal inspectorRequested(string nodeId)
    signal nodesMoved
    signal activeGraphChanged
    signal mediaContextChanged(string group)
    signal timelineContextChanged(string group)
    signal graphTimeContextChanged(string group)
    signal graphContextChanged(string group)
    signal viewerRoleChanged(string panelId)
    signal mediaPanelRequested(string group)
    signal mediaInsertRequested(string group, var sourceIds, string mode)
    signal mediaInsertFinished(string group, string error)
    readonly property Connections catalogChanges: Connections {
        target: studioModel.media
        function onRevisionChanged() {
            studioModel.mediaRevision++;
        }
    }

    function nodeTypes() {
        var result = [];
        for (var i = 0; i < nodeCategories.length; ++i)
            result = result.concat(nodeCategories[i].types);
        return result;
    }
    function nodeCategory(type) {
        var value = String(type || "");
        if (value === "Input" || value === "Output")
            return "IO";
        if (value === "Subnet")
            return "Utility";
        for (var i = 0; i < nodeCategories.length; ++i)
            if (nodeCategories[i].types.indexOf(value) >= 0)
                return String(nodeCategories[i].id);
        return "Utility";
    }

    function _validGroup(group) {
        return groupKeys.indexOf(String(group)) >= 0;
    }

    function _source(sourceId) {
        var sources = timeline && timeline.sources ? timeline.sources : [];
        for (var i = 0; i < sources.length; ++i)
            if (String(sources[i].id) === String(sourceId))
                return sources[i];
        return null;
    }

    function _sourceBounds(sourceId) {
        var source = _source(sourceId), start = timeline ? Number(timeline.startFrame) : 1001;
        if (!source)
            return {
                "first": start,
                "last": Math.max(start, timeline ? Number(timeline.sequenceEnd()) - 1 : start)
            };
        return {
            "first": start,
            "last": start + Math.max(1, Number(source.duration) || 1) - 1
        };
    }

    function _sequenceTimeContext() {
        var first = timeline ? Number(timeline.startFrame) : 1001;
        var last = Math.max(first, timeline ? Number(timeline.sequenceEnd()) - 1 : first);
        return {
            "frame": first,
            "inFrame": first,
            "outFrame": last
        };
    }

    function _timeContext(source, fallback) {
        var value = source || fallback || _sequenceTimeContext();
        return {
            "frame": Number(value.frame),
            "inFrame": Number(value.inFrame),
            "outFrame": Number(value.outFrame)
        };
    }

    function mediaContext(group) {
        var key = String(group), context = _mediaContexts[key];
        if (!_validGroup(key) || !context)
            return {
                "sourceId": "",
                "frame": 1001,
                "inFrame": 1001,
                "outFrame": 1001
            };
        return {
            "sourceId": String(context.sourceId || ""),
            "frame": Number(context.frame),
            "inFrame": Number(context.inFrame),
            "outFrame": Number(context.outFrame)
        };
    }

    function mediaSourceRange(group, sourceId) {
        var source = _source(sourceId);
        if (!_validGroup(group) || !source)
            return null;
        var state = (_mediaSourceContexts[group] || {})[sourceId];
        var bounds = _sourceBounds(sourceId);
        var first = state ? state.inFrame : bounds.first;
        var last = state ? state.outFrame : bounds.last;
        return {
            "sourceIn": first - bounds.first,
            "sourceDuration": source.duration,
            "duration": last - first + 1
        };
    }

    function _saveMediaSource(group, context) {
        var key = String(group), sourceId = String(context.sourceId || "");
        if (!sourceId)
            return;
        var groups = {};
        for (var groupKey in _mediaSourceContexts)
            groups[groupKey] = _mediaSourceContexts[groupKey];
        var states = {};
        for (var stateKey in (groups[key] || {}))
            states[stateKey] = groups[key][stateKey];
        states[sourceId] = {
            "frame": Number(context.frame),
            "inFrame": Number(context.inFrame),
            "outFrame": Number(context.outFrame)
        };
        groups[key] = states;
        _mediaSourceContexts = groups;
    }

    function setMediaContext(group, changes) {
        var key = String(group);
        if (!_validGroup(key) || !changes)
            return false;
        var current = mediaContext(key), next = {
            "sourceId": current.sourceId,
            "frame": current.frame,
            "inFrame": current.inFrame,
            "outFrame": current.outFrame
        };
        if (changes.sourceId !== undefined) {
            var sourceId = String(changes.sourceId || "");
            if (sourceId && !_source(sourceId))
                return false;
            _saveMediaSource(key, current);
            next.sourceId = sourceId;
            var remembered = (_mediaSourceContexts[key] || {})[sourceId];
            if (sourceId && changes.frame === undefined && changes.inFrame === undefined && changes.outFrame === undefined) {
                var sourceBounds = _sourceBounds(sourceId);
                next.frame = remembered ? Number(remembered.frame) : sourceBounds.first;
                next.inFrame = remembered ? Number(remembered.inFrame) : sourceBounds.first;
                next.outFrame = remembered ? Number(remembered.outFrame) : sourceBounds.last;
            }
        }
        var bounds = _sourceBounds(next.sourceId), first = bounds.first, last = bounds.last;
        if (changes.inFrame !== undefined)
            next.inFrame = Math.max(first, Math.min(last, Math.round(Number(changes.inFrame))));
        if (changes.outFrame !== undefined)
            next.outFrame = Math.max(next.inFrame, Math.min(last, Math.round(Number(changes.outFrame))));
        if (changes.frame !== undefined)
            next.frame = Math.round(Number(changes.frame));
        next.inFrame = Math.max(first, Math.min(last, next.inFrame));
        next.outFrame = Math.max(next.inFrame, Math.min(last, next.outFrame));
        next.frame = Math.max(first, Math.min(last, next.frame));
        if (JSON.stringify(current) === JSON.stringify(next))
            return true;
        var contexts = {};
        for (var contextKey in _mediaContexts)
            contexts[contextKey] = _mediaContexts[contextKey];
        contexts[key] = next;
        _mediaContexts = contexts;
        _saveMediaSource(key, next);
        mediaRevision++;
        mediaContextChanged(key);
        return true;
    }

    function timelineContext(group) {
        var key = String(group);
        return _validGroup(key) ? _timeContext(_timelineContexts[key]) : _sequenceTimeContext();
    }

    function graphTimeContext(group) {
        var key = String(group);
        return _validGroup(key) ? _timeContext(_graphTimeContexts[key]) : _sequenceTimeContext();
    }

    function _setTimeContext(storeName, signalName, group, changes) {
        var key = String(group);
        if (!_validGroup(key) || !changes)
            return false;
        var store = storeName === "timeline" ? _timelineContexts : _graphTimeContexts;
        var current = _timeContext(store[key]);
        var next = {
            "frame": current.frame,
            "inFrame": current.inFrame,
            "outFrame": current.outFrame
        };
        var bounds = _sequenceTimeContext(), first = bounds.inFrame, last = bounds.outFrame;
        if (changes.inFrame !== undefined)
            next.inFrame = Math.max(first, Math.min(last, Math.round(Number(changes.inFrame))));
        if (changes.outFrame !== undefined)
            next.outFrame = Math.max(next.inFrame, Math.min(last, Math.round(Number(changes.outFrame))));
        if (changes.frame !== undefined)
            next.frame = Math.round(Number(changes.frame));
        next.inFrame = Math.max(first, Math.min(last, next.inFrame));
        next.outFrame = Math.max(next.inFrame, Math.min(last, next.outFrame));
        next.frame = Math.max(first, Math.min(last, next.frame));
        if (JSON.stringify(current) === JSON.stringify(next))
            return true;
        var copy = {};
        for (var contextKey in store)
            copy[contextKey] = store[contextKey];
        copy[key] = next;
        if (storeName === "timeline")
            _timelineContexts = copy;
        else
            _graphTimeContexts = copy;
        if (key === "A" && !_syncingCompatibilityFrame) {
            _syncingCompatibilityFrame = true;
            frame = next.frame;
            _syncingCompatibilityFrame = false;
        }
        if (signalName === "timeline")
            timelineContextChanged(key);
        else
            graphTimeContextChanged(key);
        return true;
    }

    function setTimelineContext(group, changes) {
        return _setTimeContext("timeline", "timeline", group, changes);
    }

    function setGraphTimeContext(group, changes) {
        return _setTimeContext("graph", "graph", group, changes);
    }

    function availableMediaTargets(group) {
        if (!_validGroup(group) || !media || !media.items)
            return [];
        var result = [], seen = {}, items = media.items;
        for (var i = 0; i < items.length; ++i) {
            var item = items[i], sourceId = item && item.sourceId ? String(item.sourceId) : "";
            if (!item || item.kind === "bin" || !sourceId || seen[sourceId])
                continue;
            seen[sourceId] = true;
            result.push({
                    "id": sourceId,
                    "name": String(item.name || sourceId),
                    "kind": String(item.kind),
                    "duration": Number(item.duration) || 0,
                    "color": item.color || ""
                });
        }
        return result;
    }

    function graphContext(group) {
        var key = String(group), context = _graphContexts[key];
        if (!_validGroup(key) || !context)
            return {
                "graphId": "",
                "nodeId": ""
            };
        return {
            "graphId": String(context.graphId || ""),
            "nodeId": String(context.nodeId || "")
        };
    }

    function availableGraphTargets(group) {
        var context = graphContext(group), graph = context.graphId ? _graph(context.graphId) : null;
        if (!graph)
            return [];
        return graph.nodes.map(function (node) {
                return {
                    "id": String(node.id),
                    "name": String(node.name || node.id),
                    "type": String(node.type || "")
                };
            });
    }

    function graphTargetName(group) {
        var context = graphContext(group), graph = context.graphId ? _graph(context.graphId) : null;
        if (!context.nodeId || !graph)
            return "";
        var target = _nodeIn(graph.nodes, context.nodeId);
        return target && target.name ? String(target.name) : "";
    }

    function setGraphContext(group, changes) {
        var key = String(group);
        if (!_validGroup(key) || !changes)
            return false;
        var current = graphContext(key), next = {
            "graphId": current.graphId,
            "nodeId": current.nodeId
        };
        if (changes.graphId !== undefined) {
            var graphId = String(changes.graphId || "");
            if (!_graph(graphId))
                return false;
            next.graphId = graphId;
        }
        if (changes.nodeId !== undefined) {
            var graph = _graph(next.graphId), nodeId = String(changes.nodeId || "");
            if (nodeId && (!graph || !_nodeIn(graph.nodes, nodeId)))
                return false;
            next.nodeId = nodeId;
        }
        if (JSON.stringify(current) === JSON.stringify(next))
            return true;
        var contexts = {};
        for (var contextKey in _graphContexts)
            contexts[contextKey] = _graphContexts[contextKey];
        contexts[key] = next;
        _graphContexts = contexts;
        graphContextChanged(key);
        return true;
    }

    function viewerRole(panelId) {
        var id = String(panelId || ""), role = _viewerRoles[id];
        if (!role && panelStates[id])
            role = panelStates[id].viewerRole;
        return role === "timeline" || role === "media" || role === "graph" ? role : "graph";
    }

    function setViewerRole(panelId, role) {
        var id = String(panelId || ""), nextRole = String(role || "");
        if (!id || ["graph", "timeline", "media"].indexOf(nextRole) < 0)
            return false;
        var roles = {};
        for (var roleId in _viewerRoles)
            roles[roleId] = _viewerRoles[roleId];
        roles[id] = nextRole;
        _viewerRoles = roles;
        var state = panelStates[id] || {};
        state.viewerRole = nextRole;
        panelStates[id] = state;
        viewerRoleChanged(id);
        return true;
    }

    function openMedia(group, sourceId) {
        return setMediaContext(group, {
                "sourceId": String(sourceId || "")
            });
    }

    function requestMediaPanel(group) {
        var key = String(group);
        if (!_validGroup(key))
            return false;
        mediaPanelRequested(key);
        return true;
    }

    function number(key, label, value, min, max, step, section) {
        return {
            "key": key,
            "label": label,
            "kind": "number",
            "value": value,
            "min": min,
            "max": max,
            "step": step,
            "section": section
        };
    }

    function choice(key, label, value, options, section) {
        return {
            "key": key,
            "label": label,
            "kind": "choice",
            "value": value,
            "options": options,
            "section": section
        };
    }
    function toggle(key, label, value, section) {
        return {
            "key": key,
            "label": label,
            "kind": "toggle",
            "value": value,
            "section": section
        };
    }
    function parameters(type) {
        if (type === "Merge")
            return [choice("operation", "Operation", "Over", ["Over", "Plus", "Multiply", "Screen"], "Composite"), number("mix", "Mix", 1, 0, 1, 0.01, "Composite"), choice("channels", "Channels", "RGBA", ["RGBA", "RGB", "Alpha"], "Composite"), toggle("clamp", "Clamp output", false, "Composite"), toggle("mask", "Enable mask", false, "Mask"), toggle("invert", "Invert", false, "Mask"), number("feather", "Feather", 0, 0, 100, 0.1, "Mask")];
        if (type === "ColorCorrect" || type === "Grade")
            return [number("exposure", "Exposure", -0.18, -3, 3, 0.01, "Primary"), number("contrast", "Contrast", 1, 0, 2, 0.01, "Primary"), number("saturation", "Saturation", 0.82, 0, 2, 0.01, "Primary"), number("pivot", "Pivot", 0.18, 0, 1, 0.01, "Primary"), choice("channels", "Channels", "RGB", ["RGB", "RGBA", "R", "G", "B"], "Range"), toggle("clampBlack", "Clamp black", false, "Range"), toggle("clampWhite", "Clamp white", false, "Range")];
        if (type === "Transform")
            return [number("translateX", "Translate X", -6, -200, 200, 1, "Transform"), number("translateY", "Translate Y", 0, -200, 200, 1, "Transform"), number("scale", "Scale", 1.042, 0.1, 3, 0.001, "Transform"), number("rotate", "Rotate", 0, -180, 180, 0.1, "Transform"), choice("filter", "Filter", "Cubic", ["Cubic", "Linear", "Nearest"], "Sampling")];
        if (type === "Blur")
            return [number("size", "Size", 12, 0, 100, 0.1, "Blur"), choice("channels", "Channels", "RGBA", ["RGBA", "RGB", "Alpha"], "Blur")];
        if (type === "Dot" || type === "Input" || type === "Output" || type === "Subnet")
            return [];
        if (type === "Read")
            return [choice("colorspace", "Color space", "Rec.709", ["Rec.709", "Linear", "sRGB"], "Source"), number("first", "First frame", 1001, 1, 2000, 1, "Timing"), number("last", "Last frame", 1240, 1, 2000, 1, "Timing")];
        return [choice("channels", "Channels", "RGBA", ["RGBA", "RGB", "Alpha"], "Display")];
    }

    function makeNode(id, name, type, x, y) {
        return {
            "id": id,
            "name": name,
            "type": type,
            "x": x,
            "y": y,
            "params": parameters(type)
        };
    }
    function makeRouter(id, name, type, x, y, port) {
        var n = makeNode(id, name, type, x, y);
        n.interfacePort = port;
        return n;
    }
    function _graph(id) {
        return graphs[id] || null;
    }
    function _activeGraph() {
        return _graph(activeGraphId);
    }
    function _nodeIn(list, id) {
        for (var i = 0; i < list.length; ++i)
            if (String(list[i].id) === String(id))
                return list[i];
        return null;
    }
    // Rebuilt on topology publication, never on pointer motion or parameter edits.
    readonly property var nodeIndex: {
        var result = {};
        for (var graphId in graphs) {
            var graphNodes = graphs[graphId].nodes;
            for (var i = 0; i < graphNodes.length; ++i)
                result[graphNodes[i].id] = {
                    "node": graphNodes[i],
                    "graphId": graphId
                };
        }
        return result;
    }
    function node(id) {
        var entry = nodeIndex[id];
        return entry ? entry.node : null;
    }
    function _edgeInput(edge) {
        return edge && edge.input !== undefined ? edge.input : 0;
    }
    function _edgeOutput(edge) {
        return edge && edge.output !== undefined ? edge.output : 0;
    }
    function _samePort(a, b) {
        return String(a) === String(b);
    }
    function _sameEdge(a, b) {
        return !!a && !!b && String(a.from) === String(b.from) && String(a.to) === String(b.to) && _samePort(_edgeInput(a), _edgeInput(b)) && _samePort(_edgeOutput(a), _edgeOutput(b));
    }
    function _edgeRoute(edge) {
        var source = edge && edge.routePoints ? edge.routePoints : [];
        var result = [];
        for (var i = 0; i < source.length; ++i) {
            var point = source[i];
            if (point && isFinite(Number(point.x)) && isFinite(Number(point.y)))
                result.push({
                        "x": Number(point.x),
                        "y": Number(point.y)
                    });
        }
        return result;
    }
    function edgeRoute(edge) {
        return _edgeRoute(edge);
    }
    function setEdgeRoute(edge, points) {
        var graph = _activeGraph(), index = -1;
        if (graph)
            for (var i = 0; i < graph.edges.length; ++i)
                if (_sameEdge(graph.edges[i], edge)) {
                    index = i;
                    break;
                }
        if (index < 0) {
            graphError = "Edge does not exist.";
            return false;
        }
        var nextPoints = _edgeRoute({
                "routePoints": points || []
            }), current = _edgeRoute(graph.edges[index]);
        if (JSON.stringify(current) === JSON.stringify(nextPoints)) {
            graphError = "";
            return true;
        }
        var replacement = {};
        for (var propertyName in graph.edges[index])
            replacement[propertyName] = graph.edges[index][propertyName];
        replacement.routePoints = nextPoints;
        var next = graph.edges.slice();
        next[index] = replacement;
        _replaceGraph(graph, graph.nodes, next);
        revision++;
        graphError = "";
        return true;
    }
    function removeEdgeRoutePoint(edge, index) {
        var points = _edgeRoute(edge), pointIndex = Number(index);
        if (!isFinite(pointIndex) || pointIndex < 0 || pointIndex >= points.length)
            return false;
        points.splice(Math.floor(pointIndex), 1);
        return setEdgeRoute(edge, points);
    }

    function _port(id, label, type, side) {
        return {
            "id": id,
            "label": label,
            "type": type,
            "side": side
        };
    }
    function _inputPortsForNode(n) {
        if (!n)
            return [];
        if (n.type === "Read" || n.type === "Input")
            return [];
        if (n.type === "Output") {
            var outputPort = n.interfacePort || {
                "id": "output",
                "label": "Output",
                "type": "image",
                "side": "bottom"
            };
            return [_port(outputPort.id, outputPort.label || "Output", outputPort.type || "image", "top")];
        }
        if (n.type === "Subnet" && n.interfaceInputs)
            return n.interfaceInputs.slice();
        var result = [];
        if (n.type === "Merge") {
            result.push(_port(0, "A", "image", "top"));
            result.push(_port(1, "B", "image", "top"));
        } else {
            result.push(_port(0, "Input", "image", "top"));
        }
        // A mask is a real typed port, not a second generic processing input.
        result.push(_port("mask", "Mask", "mask", "right"));
        return result;
    }
    function _outputPortsForNode(n) {
        if (!n || n.type === "Viewer" || n.type === "Output")
            return [];
        if (n.type === "Input") {
            var inputPort = n.interfacePort || {
                "id": 0,
                "label": "Output",
                "type": "image"
            };
            return [_port(0, inputPort.label || "Output", inputPort.type || "image", "bottom")];
        }
        if (n.type === "Subnet" && n.interfaceOutputs)
            return n.interfaceOutputs.slice();
        return [_port(0, "Output", "image", "bottom")];
    }
    function inputPorts(id) {
        return _inputPortsForNode(node(id));
    }
    function outputPorts(id) {
        return _outputPortsForNode(node(id));
    }
    function _portFor(ports, id) {
        for (var i = 0; i < ports.length; ++i)
            if (_samePort(ports[i].id, id))
                return ports[i];
        return null;
    }
    function _primaryPort(ports) {
        var list = ports || [];
        for (var i = 0; i < list.length; ++i)
            if (_samePort(list[i].id, 0))
                return list[i];
        for (var j = 0; j < list.length; ++j)
            if (list[j].type !== "mask")
                return list[j];
        return list.length > 0 ? list[0] : null;
    }
    function _primaryInputPort(n) {
        return _primaryPort(_inputPortsForNode(n));
    }
    function _primaryOutputPort(n) {
        return _primaryPort(_outputPortsForNode(n));
    }
    function _nodeTypeIsKnown(type) {
        var value = String(type || ""), available = nodeTypes();
        return available.indexOf(value) >= 0;
    }
    function _nodeExistsInGraphs(id) {
        var key = String(id), allGraphs = graphs || {};
        for (var graphId in allGraphs)
            if (_nodeIn((allGraphs[graphId] || {}).nodes || [], key))
                return true;
        return false;
    }
    function _nextNodeIdentity() {
        var next = Math.max(1, Number(serial) || 1), id = "";
        do {
            id = "added" + next;
            next++;
        } while (_nodeExistsInGraphs(id))
        return {
            "id": id,
            "nextSerial": next
        };
    }
    function _copyNode(node) {
        var result = {};
        for (var propertyName in node)
            result[propertyName] = node[propertyName];
        return result;
    }
    function _copyNodeWithPosition(node, x, y) {
        var result = _copyNode(node);
        result.x = x;
        result.y = y;
        return result;
    }
    function _copyEdgeWithEndpoints(edge, from, to, input, output) {
        var result = {};
        for (var propertyName in edge)
            result[propertyName] = edge[propertyName];
        result.from = from;
        result.to = to;
        result.input = input;
        result.output = output;
        return result;
    }

    function _edgeIsRemoved(edge, ignoredEdge, destination, input) {
        if (_sameEdge(edge, ignoredEdge))
            return true;
        return String(edge.to) === String(destination) && _samePort(_edgeInput(edge), input);
    }
    function _reachable(edgeList, start, goal) {
        var pending = [start], visited = [];
        while (pending.length > 0) {
            var current = pending.pop();
            if (String(current) === String(goal))
                return true;
            var seen = false;
            for (var v = 0; v < visited.length; ++v)
                if (String(visited[v]) === String(current)) {
                    seen = true;
                    break;
                }
            if (seen)
                continue;
            visited.push(current);
            for (var i = 0; i < edgeList.length; ++i)
                if (String(edgeList[i].from) === String(current))
                    pending.push(edgeList[i].to);
        }
        return false;
    }
    function _compatiblePorts(sourcePort, destinationPort) {
        // Image data can be sampled as a mask; a mask cannot be promoted to image.
        return sourcePort.type === destinationPort.type || (sourcePort.type === "image" && destinationPort.type === "mask");
    }
    function _edgeError(from, to, input, ignoredEdge, nodeList, edgeList, output) {
        var resolvedInput = input === undefined ? 0 : input;
        var resolvedOutput = output === undefined ? 0 : output;
        var source = _nodeIn(nodeList, from), destination = _nodeIn(nodeList, to);
        if (!source)
            return "Source node does not exist.";
        if (!destination)
            return "Destination node does not exist.";
        var sourcePort = _portFor(_outputPortsForNode(source), resolvedOutput);
        if (!sourcePort)
            return "Source output does not exist.";
        var destinationPort = _portFor(_inputPortsForNode(destination), resolvedInput);
        if (!destinationPort)
            return "Destination input does not exist.";
        if (!_compatiblePorts(sourcePort, destinationPort))
            return "Incompatible " + sourcePort.type + " and " + destinationPort.type + " ports.";
        if (String(from) === String(to))
            return "A node cannot connect to itself.";
        var remaining = [];
        for (var i = 0; i < edgeList.length; ++i) {
            var edge = edgeList[i];
            if (_edgeIsRemoved(edge, ignoredEdge, to, resolvedInput))
                continue;
            var edgeSource = _nodeIn(nodeList, edge.from), edgeDestination = _nodeIn(nodeList, edge.to);
            if (!edgeSource || !edgeDestination)
                return "Graph contains an invalid edge endpoint.";
            var edgeOutput = _portFor(_outputPortsForNode(edgeSource), _edgeOutput(edge));
            var edgeInput = _portFor(_inputPortsForNode(edgeDestination), _edgeInput(edge));
            if (!edgeOutput || !edgeInput)
                return "Graph contains an invalid edge port.";
            if (!_compatiblePorts(edgeOutput, edgeInput))
                return "Graph contains incompatible edge ports.";
            remaining.push(edge);
        }
        if (_reachable(remaining, to, from))
            return "Connection would create a cycle.";
        return "";
    }
    function connectionError(from, to, input, ignoredEdge, output) {
        var resolvedInput = input === undefined ? 0 : input;
        var resolvedOutput = output === undefined ? 0 : output;
        var graph = _activeGraph();
        var error = graph ? _edgeError(from, to, resolvedInput, ignoredEdge, graph.nodes, graph.edges, resolvedOutput) : "No active graph.";
        graphError = error ? from + " → " + to + " [output " + resolvedOutput + ", input " + resolvedInput + "]: " + error : "";
        return graphError;
    }
    function _validateEdgeList(edgeList, nodeList) {
        for (var i = 0; i < edgeList.length; ++i) {
            var edge = edgeList[i];
            var error = _edgeError(edge.from, edge.to, _edgeInput(edge), edge, nodeList, edgeList, _edgeOutput(edge));
            if (error)
                return error;
        }
        return "";
    }
    function _connected(id, edgeList) {
        for (var i = 0; i < edgeList.length; ++i)
            if (String(edgeList[i].from) === String(id) || String(edgeList[i].to) === String(id))
                return true;
        return false;
    }
    function _edgesWithout(edgeToRemove, edgeList) {
        var result = [];
        for (var i = 0; i < edgeList.length; ++i)
            if (!_sameEdge(edgeList[i], edgeToRemove))
                result.push(edgeList[i]);
        return result;
    }
    function _insertionError(id, edge) {
        var graph = _activeGraph(), insertionNode = node(id);
        if (!graph || !insertionNode)
            return "Inserted node does not exist.";
        if (_connected(id, graph.edges))
            return "Inserted node must be disconnected.";
        if (!edge)
            return "Edge does not exist.";
        var original = null;
        for (var i = 0; i < graph.edges.length; ++i)
            if (_sameEdge(graph.edges[i], edge)) {
                original = graph.edges[i];
                break;
            }
        if (!original)
            return "Edge does not exist.";
        var originalInput = _edgeInput(original), remaining = _edgesWithout(original, graph.edges);
        var prospectiveEdges = remaining.concat([{
                    "from": original.from,
                    "to": id,
                    "input": 0,
                    "output": _edgeOutput(original)
                }, {
                    "from": id,
                    "to": original.to,
                    "input": originalInput,
                    "output": 0
                }]);
        return _validateEdgeList(prospectiveEdges, graph.nodes);
    }
    function _insertionEdges(edge, id) {
        var graph = _activeGraph(), original = null;
        if (!graph)
            return null;
        for (var i = 0; i < graph.edges.length; ++i)
            if (_sameEdge(graph.edges[i], edge)) {
                original = graph.edges[i];
                break;
            }
        if (!original)
            return null;
        var originalInput = _edgeInput(original), result = [], inserted = false;
        for (var j = 0; j < graph.edges.length; ++j) {
            if (_sameEdge(graph.edges[j], original)) {
                if (!inserted) {
                    result.push({
                            "from": original.from,
                            "to": id,
                            "input": 0,
                            "output": _edgeOutput(original)
                        });
                    result.push({
                            "from": id,
                            "to": original.to,
                            "input": originalInput,
                            "output": 0
                        });
                    inserted = true;
                }
            } else
                result.push(graph.edges[j]);
        }
        return result;
    }
    function _publishGraphs() {
        var copy = {};
        for (var id in graphs)
            copy[id] = graphs[id];
        graphs = copy;
    }
    function _publishActive(graph) {
        if (!graph || graph.id !== activeGraphId)
            return;
        nodes = graph.nodes;
        edges = graph.edges;
    }
    function _replaceGraph(graph, nextNodes, nextEdges) {
        graph.nodes = nextNodes;
        graph.edges = nextEdges;
        _publishGraphs();
        _publishActive(graph);
    }

    function connectNodes(from, to, input, oldEdge, output) {
        var resolvedInput = input === undefined ? 0 : input, resolvedOutput = output === undefined ? 0 : output;
        var graph = _activeGraph();
        var error = connectionError(from, to, resolvedInput, oldEdge, resolvedOutput);
        if (error || !graph)
            return false;
        var replacement = {
            "from": from,
            "to": to,
            "input": resolvedInput,
            "output": resolvedOutput
        }, next = [], inserted = false;
        for (var i = 0; i < graph.edges.length; ++i) {
            var edge = graph.edges[i];
            if (_sameEdge(edge, oldEdge) || (String(edge.to) === String(to) && _samePort(_edgeInput(edge), resolvedInput))) {
                if (!inserted) {
                    next.push(replacement);
                    inserted = true;
                }
            } else
                next.push(edge);
        }
        if (!inserted)
            next.push(replacement);
        var changed = next.length !== graph.edges.length;
        if (!changed) {
            for (var j = 0; j < next.length; ++j)
                if (!_sameEdge(next[j], graph.edges[j])) {
                    changed = true;
                    break;
                }
        }
        if (changed) {
            _replaceGraph(graph, graph.nodes, next);
            revision++;
        }
        graphError = "";
        return true;
    }
    function disconnectEdge(edge) {
        var graph = _activeGraph(), index = -1;
        if (graph)
            for (var i = 0; i < graph.edges.length; ++i)
                if (_sameEdge(graph.edges[i], edge)) {
                    index = i;
                    break;
                }
        if (index < 0) {
            graphError = "Edge does not exist.";
            return false;
        }
        var next = graph.edges.slice();
        next.splice(index, 1);
        _replaceGraph(graph, graph.nodes, next);
        revision++;
        graphError = "";
        return true;
    }
    function insertNodeIntoEdge(id, edge) {
        var error = _insertionError(id, edge);
        if (error) {
            graphError = "Insert " + id + ": " + error;
            return false;
        }
        var next = _insertionEdges(edge, id);
        if (!next) {
            graphError = "Edge does not exist.";
            return false;
        }
        var graph = _activeGraph();
        _replaceGraph(graph, graph.nodes, next);
        revision++;
        graphError = "";
        return true;
    }
    function _nodeName(type) {
        var graph = _activeGraph(), base = String(type || ""), count = 1, candidate = "";
        if (!graph)
            return base + count;
        do {
            candidate = base + count++;
            var occupied = false;
            for (var i = 0; i < graph.nodes.length; ++i) {
                if (String(graph.nodes[i].name || "") === candidate) {
                    occupied = true;
                    break;
                }
            }
        } while (occupied)
        return candidate;
    }
    function _commitNodeCreation(candidate, nextNodes, nextEdges, nextSerial, operation) {
        var graph = _activeGraph(), prefix = operation || "Create";
        if (!graph) {
            graphError = prefix + " " + candidate.type + ": no active graph.";
            return "";
        }
        if (!candidate || !candidate.id || !candidate.type || !isFinite(Number(candidate.x)) || !isFinite(Number(candidate.y))) {
            graphError = prefix + ": invalid node.";
            return "";
        }
        if (_nodeExistsInGraphs(candidate.id)) {
            graphError = prefix + " " + candidate.type + ": node ID already exists.";
            return "";
        }
        var error = _validateEdgeList(nextEdges || [], nextNodes || []);
        if (error) {
            graphError = prefix + " " + candidate.type + ": " + error;
            return "";
        }
        _replaceGraph(graph, nextNodes, nextEdges);
        serial = nextSerial;
        revision++;
        graphError = "";
        selectNode(candidate.id);
        return String(candidate.id);
    }
    function _creationDownstream(graph, sourceId, outputId) {
        var result = {}, pending = [];
        for (var i = 0; i < graph.edges.length; ++i) {
            var first = graph.edges[i];
            if (String(first.from) === String(sourceId) && _samePort(_edgeOutput(first), outputId))
                pending.push(String(first.to));
        }
        while (pending.length > 0) {
            var id = pending.pop();
            if (result[id])
                continue;
            result[id] = true;
            for (var j = 0; j < graph.edges.length; ++j)
                if (String(graph.edges[j].from) === id)
                    pending.push(String(graph.edges[j].to));
        }
        return result;
    }
    function _creationLayoutShift(graph, anchor, outputId, candidate) {
        var downstream = _creationDownstream(graph, anchor.id, outputId), delta = 0;
        var candidateX = Number(candidate.x), candidateY = Number(candidate.y), candidateBottom = candidateY + graphNodeHeight + 12;
        for (var i = 0; i < graph.nodes.length; ++i) {
            var node = graph.nodes[i];
            if (!downstream[String(node.id)])
                continue;
            var nodeX = Number(node.x) || 0, nodeY = Number(node.y) || 0;
            var horizontalOverlap = nodeX < candidateX + graphNodeWidth && nodeX + graphNodeWidth > candidateX;
            if (horizontalOverlap && nodeY < candidateBottom)
                delta = Math.max(delta, candidateBottom - nodeY);
        }
        return {
            "ids": downstream,
            "delta": delta
        };
    }
    function createNode(type, x, y, afterId) {
        var resolvedType = String(type || ""), graph = _activeGraph();
        if (!resolvedType) {
            graphError = "Create: node type is required.";
            return "";
        }
        if (!_nodeTypeIsKnown(resolvedType)) {
            graphError = "Create " + resolvedType + ": unknown node type.";
            return "";
        }
        if (!graph) {
            graphError = "Create " + resolvedType + ": no active graph.";
            return "";
        }
        var sceneX = Number(x), sceneY = Number(y);
        if (!isFinite(sceneX) || !isFinite(sceneY)) {
            graphError = "Create " + resolvedType + ": invalid position.";
            return "";
        }
        var identity = _nextNodeIdentity(), candidate = makeNode(identity.id, _nodeName(resolvedType), resolvedType, sceneX, sceneY);
        var anchor = _nodeIn(graph.nodes, String(afterId || "")), anchorOutput = anchor ? _primaryOutputPort(anchor) : null;
        var candidateInput = _primaryInputPort(candidate), candidateOutput = _primaryOutputPort(candidate);
        var connected = !!anchorOutput && !!candidateInput && _compatiblePorts(anchorOutput, candidateInput);
        var nextEdges = graph.edges.slice(), layout = null;
        if (connected) {
            candidate.x = Number(anchor.x) || 0;
            candidate.y = (Number(anchor.y) || 0) + 95;
            layout = _creationLayoutShift(graph, anchor, anchorOutput.id, candidate);
            if (candidateOutput) {
                var redirected = false, redirectedEdges = [];
                for (var edgeIndex = 0; edgeIndex < graph.edges.length; ++edgeIndex) {
                    var edge = graph.edges[edgeIndex];
                    if (String(edge.from) === String(anchor.id) && _samePort(_edgeOutput(edge), anchorOutput.id)) {
                        if (!redirected) {
                            redirectedEdges.push({
                                    "from": anchor.id,
                                    "to": candidate.id,
                                    "input": candidateInput.id,
                                    "output": anchorOutput.id
                                });
                            redirected = true;
                        }
                        redirectedEdges.push(_copyEdgeWithEndpoints(edge, candidate.id, edge.to, _edgeInput(edge), candidateOutput.id));
                    } else {
                        redirectedEdges.push(edge);
                    }
                }
                if (!redirected)
                    redirectedEdges.push({
                            "from": anchor.id,
                            "to": candidate.id,
                            "input": candidateInput.id,
                            "output": anchorOutput.id
                        });
                nextEdges = redirectedEdges;
            } else {
                nextEdges.push({
                        "from": anchor.id,
                        "to": candidate.id,
                        "input": candidateInput.id,
                        "output": anchorOutput.id
                    });
            }
        }
        var nextNodes = [];
        for (var nodeIndex = 0; nodeIndex < graph.nodes.length; ++nodeIndex) {
            var sourceNode = graph.nodes[nodeIndex], shift = connected && layout && layout.ids[String(sourceNode.id)] && layout.delta > 0;
            nextNodes.push(shift ? _copyNodeWithPosition(sourceNode, Number(sourceNode.x) || 0, (Number(sourceNode.y) || 0) + layout.delta) : sourceNode);
        }
        nextNodes.push(candidate);
        return _commitNodeCreation(candidate, nextNodes, nextEdges, identity.nextSerial, "Create");
    }

    function setSelection(ids) {
        var graph = _activeGraph(), next = [], source = ids || [];
        for (var i = 0; i < source.length; ++i) {
            var id = String(source[i]), exists = graph && _nodeIn(graph.nodes, id);
            var duplicate = false;
            for (var j = 0; j < next.length; ++j)
                if (next[j] === id)
                    duplicate = true;
            if (exists && !duplicate)
                next.push(id);
        }
        selectedNodeIds = next;
        selectedNodeId = next.length ? next[next.length - 1] : "";
        var selections = _selectionByGraph || {};
        selections[activeGraphId] = next.slice();
        _selectionByGraph = selections;
    }
    property var _selectionByGraph: ({})
    function selectNode(id, toggle) {
        var graph = _activeGraph();
        if (!graph || !_nodeIn(graph.nodes, id))
            return;
        var current = selectedNodeIds.slice(), key = String(id), index = current.indexOf(key);
        if (toggle) {
            if (index >= 0)
                current.splice(index, 1);
            else
                current.push(key);
            setSelection(current);
        } else
            setSelection([key]);
    }
    function openNodeParameters(id) {
        if (!node(id))
            return;
        selectNode(id);
        inspectorRequested(String(id));
    }
    function parameter(nodeId, key) {
        var n = node(nodeId);
        if (!n || !n.params)
            return null;
        for (var i = 0; i < n.params.length; ++i)
            if (String(n.params[i].key) === String(key))
                return n.params[i];
        return null;
    }

    function _animationChannelId(nodeId, key) {
        return String(nodeId) + "::" + String(key);
    }
    function _isAnimationNumber(value) {
        return typeof value === "number" && isFinite(value);
    }
    function _animationChannel(channelId) {
        var id = String(channelId), channels = animationChannels || [];
        for (var i = 0; i < channels.length; ++i)
            if (String(channels[i].id) === id)
                return channels[i];
        return null;
    }
    function _animationKeyLocation(keyId) {
        var id = String(keyId), channels = animationChannels || [];
        for (var i = 0; i < channels.length; ++i) {
            var keys = channels[i].keys || [];
            for (var j = 0; j < keys.length; ++j)
                if (String(keys[j].id) === id)
                    return {
                        "channelIndex": i,
                        "keyIndex": j
                    };
        }
        return null;
    }
    function _animationIds(ids) {
        if (ids === undefined || ids === null)
            return [];
        var source = Array.isArray(ids) ? ids : [ids], result = [];
        for (var i = 0; i < source.length; ++i) {
            var id = String(source[i]), duplicate = false;
            for (var j = 0; j < result.length; ++j)
                if (result[j] === id) {
                    duplicate = true;
                    break;
                }
            if (!duplicate)
                result.push(id);
        }
        return result;
    }
    function _animationKeyClone(key) {
        var result = {};
        for (var propertyName in key)
            result[propertyName] = key[propertyName];
        result.id = String(key.id);
        result.time = Number(key.time);
        result.value = key.value;
        result.interpolation = key.interpolation;
        result.inSlope = _isAnimationNumber(key.inSlope) ? Number(key.inSlope) : 0;
        result.outSlope = _isAnimationNumber(key.outSlope) ? Number(key.outSlope) : 0;
        result.tangentMode = key.tangentMode === "smooth" ? "smooth" : "broken";
        return result;
    }
    function _animationChannelClone(channel) {
        var result = {};
        for (var propertyName in channel)
            if (propertyName !== "keys")
                result[propertyName] = channel[propertyName];
        result.id = String(channel.id);
        result.nodeId = String(channel.nodeId);
        result.parameterKey = String(channel.parameterKey);
        result.keys = [];
        var source = channel.keys || [];
        for (var i = 0; i < source.length; ++i)
            result.keys.push(_animationKeyClone(source[i]));
        return result;
    }
    function _animationSnapshot() {
        var result = [], channels = animationChannels || [];
        for (var i = 0; i < channels.length; ++i)
            result.push(_animationChannelClone(channels[i]));
        return result;
    }
    function _animationSnapshotWithoutNodes(snapshot, removed) {
        var result = [], source = snapshot || [];
        for (var i = 0; i < source.length; ++i)
            if (!removed[String(source[i].nodeId)])
                result.push(_animationChannelClone(source[i]));
        return result;
    }
    function _animationHistoryWithoutNodes(history, removed) {
        var result = [], source = history || [];
        for (var i = 0; i < source.length; ++i) {
            var entry = source[i] || {};
            result.push({
                    "before": _animationSnapshotWithoutNodes(entry.before, removed),
                    "after": _animationSnapshotWithoutNodes(entry.after, removed)
                });
        }
        return result;
    }
    function _pruneAnimationNodes(removed) {
        var before = JSON.stringify(animationChannels || []), current = _animationSnapshotWithoutNodes(animationChannels || [], removed);
        animationChannels = current;
        _animationUndoStack = _animationHistoryWithoutNodes(_animationUndoStack || [], removed);
        _animationRedoStack = _animationHistoryWithoutNodes(_animationRedoStack || [], removed);
        _animationEditBefore = _animationEditBefore ? _animationSnapshotWithoutNodes(_animationEditBefore, removed) : null;
        _animationHistorySnapshot = _animationSnapshotWithoutNodes(_animationHistorySnapshot || [], removed);
        _animationPruneSelection();
        var changed = before !== JSON.stringify(current);
        if (changed) {
            _evaluateAnimationFrame(frame);
            animationRevision++;
        }
        return changed;
    }
    function _animationSnapshotsEqual(a, b) {
        return JSON.stringify(a || []) === JSON.stringify(b || []);
    }
    function _animationPushHistory(before, after) {
        if (_animationSnapshotsEqual(before, after))
            return;
        var undo = (_animationUndoStack || []).slice();
        undo.push({
                "before": before,
                "after": after
            });
        while (undo.length > 100)
            undo.shift();
        _animationUndoStack = undo;
        _animationRedoStack = [];
    }
    function _animationPruneSelection() {
        var nextKeys = [], selectedKeys = selectedAnimationKeyIds || [];
        for (var i = 0; i < selectedKeys.length; ++i)
            if (_animationKeyLocation(selectedKeys[i]))
                nextKeys.push(String(selectedKeys[i]));
        selectedAnimationKeyIds = nextKeys;
        var nextChannels = [], selectedChannels = selectedAnimationChannelIds || [];
        for (var j = 0; j < selectedChannels.length; ++j)
            if (_animationChannel(selectedChannels[j]))
                nextChannels.push(String(selectedChannels[j]));
        selectedAnimationChannelIds = nextChannels;
    }
    function _animationRestore(snapshot) {
        var restored = [], source = snapshot || [];
        for (var i = 0; i < source.length; ++i)
            restored.push(_animationChannelClone(source[i]));
        animationChannels = restored;
        _animationPruneSelection();
        _animationHistorySnapshot = _animationSnapshot();
        _evaluateAnimationFrame(frame);
        animationRevision++;
        revision++;
    }
    function undoAnimation() {
        if (_animationEditDepth > 0)
            return false;
        var undo = (_animationUndoStack || []).slice();
        if (undo.length === 0)
            return false;
        var entry = undo.pop(), redo = (_animationRedoStack || []).slice();
        redo.push({
                "before": entry.before,
                "after": entry.after
            });
        _animationUndoStack = undo;
        _animationRedoStack = redo;
        _animationRestore(entry.before);
        return true;
    }
    function redoAnimation() {
        if (_animationEditDepth > 0)
            return false;
        var redo = (_animationRedoStack || []).slice();
        if (redo.length === 0)
            return false;
        var entry = redo.pop(), undo = (_animationUndoStack || []).slice();
        undo.push({
                "before": entry.before,
                "after": entry.after
            });
        while (undo.length > 100)
            undo.shift();
        _animationUndoStack = undo;
        _animationRedoStack = redo;
        _animationRestore(entry.after);
        return true;
    }
    function beginAnimationEdit() {
        if (_animationEditDepth === 0)
            _animationEditBefore = _animationSnapshot();
        _animationEditDepth++;
    }
    function endAnimationEdit() {
        if (_animationEditDepth <= 0)
            return;
        _animationEditDepth--;
        if (_animationEditDepth === 0) {
            var before = _animationEditBefore, after = _animationSnapshot();
            _animationEditBefore = null;
            _animationPushHistory(before, after);
            _animationHistorySnapshot = after;
        }
    }
    function _animationSortKeys(keys) {
        keys.sort(function (a, b) {
                return Number(a.time) - Number(b.time);
            });
    }
    function _animationFindTime(keys, time) {
        for (var i = 0; i < keys.length; ++i)
            if (Math.abs(Number(keys[i].time) - time) <= 1e-6)
                return i;
        return -1;
    }
    function _animationSecant(a, b) {
        if (!a || !b || !_isAnimationNumber(a.value) || !_isAnimationNumber(b.value))
            return 0;
        var dt = Number(b.time) - Number(a.time);
        return Math.abs(dt) <= 1e-12 ? 0 : (Number(b.value) - Number(a.value)) / dt;
    }
    function _animationDefaultTangents(keys, index) {
        var key = keys[index], before = index > 0 ? keys[index - 1] : null, after = index + 1 < keys.length ? keys[index + 1] : null;
        key.inSlope = before ? _animationSecant(before, key) : (after ? _animationSecant(key, after) : 0);
        key.outSlope = after ? _animationSecant(key, after) : (before ? _animationSecant(before, key) : 0);
    }
    function _animationTouch() {
        _evaluateAnimationFrame(frame);
        if (_animationEditDepth === 0) {
            var after = _animationSnapshot();
            _animationPushHistory(_animationHistorySnapshot || [], after);
            _animationHistorySnapshot = after;
        }
        animationRevision++;
        revision++;
    }
    function _evaluateAnimationFrame(time) {
        var channels = animationChannels || [];
        for (var i = 0; i < channels.length; ++i) {
            var channel = channels[i], n = node(channel.nodeId);
            if (!n || !n.params || !channel.keys || channel.keys.length === 0)
                continue;
            var value = animationValue(channel.id, time);
            for (var j = 0; j < n.params.length; ++j)
                if (String(n.params[j].key) === String(channel.parameterKey)) {
                    n.params[j].value = value;
                    break;
                }
        }
    }
    function animationValue(channelId, time) {
        var channel = _animationChannel(channelId), keys = channel ? (channel.keys || []) : [];
        if (!channel || keys.length === 0)
            return null;
        var t = Number(time);
        if (!isFinite(t))
            t = Number(keys[0].time);
        if (t <= Number(keys[0].time))
            return keys[0].value;
        var last = keys.length - 1;
        if (t >= Number(keys[last].time))
            return keys[last].value;
        var rightIndex = 1;
        while (rightIndex < keys.length && Number(keys[rightIndex].time) < t)
            rightIndex++;
        var left = keys[rightIndex - 1], right = keys[rightIndex];
        if (Math.abs(t - Number(left.time)) <= 1e-6)
            return left.value;
        if (Math.abs(t - Number(right.time)) <= 1e-6)
            return right.value;
        if (channel.kind !== "number" || !_isAnimationNumber(left.value) || !_isAnimationNumber(right.value) || left.interpolation === "hold")
            return left.value;
        var dt = Number(right.time) - Number(left.time), u = (t - Number(left.time)) / dt;
        if (left.interpolation !== "bezier") {
            return Number(left.value) + (Number(right.value) - Number(left.value)) * u;
        }
        var m0 = _isAnimationNumber(left.outSlope) ? Number(left.outSlope) : _animationSecant(left, right);
        var m1 = _isAnimationNumber(right.inSlope) ? Number(right.inSlope) : _animationSecant(left, right);
        var u2 = u * u, u3 = u2 * u;
        var h00 = 2 * u3 - 3 * u2 + 1, h10 = u3 - 2 * u2 + u;
        var h01 = -2 * u3 + 3 * u2, h11 = u3 - u2;
        return h00 * Number(left.value) + h10 * dt * m0 + h01 * Number(right.value) + h11 * dt * m1;
    }
    function _animationBezierDerivative(left, right, u) {
        if (!left || !right || !_isAnimationNumber(left.value) || !_isAnimationNumber(right.value))
            return 0;
        var dt = Number(right.time) - Number(left.time);
        if (Math.abs(dt) <= 1e-12)
            return 0;
        var m0 = _isAnimationNumber(left.outSlope) ? Number(left.outSlope) : _animationSecant(left, right);
        var m1 = _isAnimationNumber(right.inSlope) ? Number(right.inSlope) : _animationSecant(left, right);
        var u2 = u * u;
        var dh00 = 6 * u2 - 6 * u;
        var dh10 = 3 * u2 - 4 * u + 1;
        var dh01 = -6 * u2 + 6 * u;
        var dh11 = 3 * u2 - 2 * u;
        return (dh00 * Number(left.value) + dh10 * dt * m0 + dh01 * Number(right.value) + dh11 * dt * m1) / dt;
    }
    function insertAnimationKey(channelId, time) {
        var channel = _animationChannel(channelId);
        if (!channel) {
            animationError = "Animation channel does not exist.";
            return "";
        }
        if (channel.kind !== "number") {
            animationError = "Animation channel is not numeric.";
            return "";
        }
        if (!_isAnimationNumber(time)) {
            animationError = "Animation key time must be finite.";
            return "";
        }
        var numericTime = Number(time), sourceKeys = channel.keys || [];
        if (sourceKeys.length === 0) {
            animationError = "Animation channel has no keys.";
            return "";
        }
        var existingIndex = _animationFindTime(sourceKeys, numericTime);
        if (existingIndex >= 0) {
            animationError = "";
            return String(sourceKeys[existingIndex].id);
        }
        var nextChannels = (animationChannels || []).slice(), channelIndex = nextChannels.indexOf(channel);
        if (channelIndex < 0) {
            animationError = "Animation channel does not exist.";
            return "";
        }
        var leftIndex = -1;
        for (var i = 0; i + 1 < sourceKeys.length; ++i) {
            if (Number(sourceKeys[i].time) < numericTime && numericTime < Number(sourceKeys[i + 1].time)) {
                leftIndex = i;
                break;
            }
        }
        var left = leftIndex >= 0 ? sourceKeys[leftIndex] : null;
        var right = leftIndex >= 0 ? sourceKeys[leftIndex + 1] : null;
        var nextKey = {
            "id": "animationKey" + (_animationKeySerial++),
            "time": numericTime,
            "value": null,
            "interpolation": "hold",
            "inSlope": 0,
            "outSlope": 0,
            "tangentMode": "broken"
        };
        if (left && right) {
            var dt = Number(right.time) - Number(left.time);
            var u = (numericTime - Number(left.time)) / dt;
            nextKey.value = animationValue(channel.id, numericTime);
            nextKey.interpolation = left.interpolation === "bezier" ? "bezier" : left.interpolation === "hold" ? "hold" : "linear";
            if (nextKey.interpolation === "bezier") {
                var derivative = _animationBezierDerivative(left, right, u);
                nextKey.inSlope = derivative;
                nextKey.outSlope = derivative;
                nextKey.tangentMode = "smooth";
            } else if (nextKey.interpolation === "linear") {
                var secant = _animationSecant(left, right);
                nextKey.inSlope = secant;
                nextKey.outSlope = secant;
            }
        } else if (numericTime < Number(sourceKeys[0].time)) {
            nextKey.value = sourceKeys[0].value;
        } else {
            nextKey.value = sourceKeys[sourceKeys.length - 1].value;
        }
        var nextChannel = _animationChannelClone(channel);
        if (!left && numericTime > Number(sourceKeys[sourceKeys.length - 1].time) && nextChannel.keys.length > 0 && nextChannel.keys[nextChannel.keys.length - 1].interpolation === "bezier" && Number(nextChannel.keys[nextChannel.keys.length - 1].outSlope) !== 0)
            nextChannel.keys[nextChannel.keys.length - 1].interpolation = "hold";
        nextChannel.keys.push(nextKey);
        _animationSortKeys(nextChannel.keys);
        nextChannels[channelIndex] = nextChannel;
        animationChannels = nextChannels;
        animationError = "";
        _animationTouch();
        return String(nextKey.id);
    }
    function editAnimationKey(keyId, time, value, inSlope, outSlope) {
        if (!_isAnimationNumber(time) || !_isAnimationNumber(value) || !_isAnimationNumber(inSlope) || !_isAnimationNumber(outSlope)) {
            animationError = "Animation key edit requires finite numerical values.";
            return false;
        }
        var location = _animationKeyLocation(keyId);
        if (!location) {
            animationError = "Animation key does not exist.";
            return false;
        }
        var channels = animationChannels || [], channel = channels[location.channelIndex];
        if (!channel || channel.kind !== "number") {
            animationError = "Discrete animation has no numeric key edit.";
            return false;
        }
        var sourceKeys = channel.keys || [], numericTime = Number(time);
        for (var i = 0; i < sourceKeys.length; ++i)
            if (i !== location.keyIndex && Math.abs(Number(sourceKeys[i].time) - numericTime) <= 1e-6) {
                animationError = channel.nodeId + " / " + channel.label + ": frame " + numericTime + " already contains key " + sourceKeys[i].id + ".";
                return false;
            }
        var nextChannels = channels.slice(), nextChannel = _animationChannelClone(channel), nextKey = nextChannel.keys[location.keyIndex];
        if (nextKey.tangentMode === "smooth" && Number(inSlope) !== Number(outSlope)) {
            animationError = "Smooth tangents require matching slopes; choose Broken for independent handles.";
            return false;
        }
        var changed = Number(nextKey.time) !== numericTime || Number(nextKey.value) !== Number(value) || Number(nextKey.inSlope) !== Number(inSlope) || Number(nextKey.outSlope) !== Number(outSlope);
        if (!changed) {
            animationError = "";
            return true;
        }
        nextKey.time = numericTime;
        nextKey.value = Number(value);
        nextKey.inSlope = Number(inSlope);
        nextKey.outSlope = Number(outSlope);
        _animationSortKeys(nextChannel.keys);
        nextChannels[location.channelIndex] = nextChannel;
        animationChannels = nextChannels;
        animationError = "";
        _animationTouch();
        return true;
    }
    function keyParameter(nodeId, key) {
        var p = parameter(nodeId, key);
        if (!p) {
            animationError = "Parameter does not exist.";
            return false;
        }
        var channelId = _animationChannelId(nodeId, key), channels = animationChannels || [], channel = _animationChannel(channelId);
        if (channel) {
            var nextChannels = channels.slice(), channelIndex = -1;
            for (var ci = 0; ci < channels.length; ++ci)
                if (String(channels[ci].id) === channelId) {
                    channelIndex = ci;
                    break;
                }
            var nextChannel = _animationChannelClone(channel), keyIndex = _animationFindTime(nextChannel.keys, Number(frame));
            if (keyIndex >= 0) {
                if (nextChannel.keys[keyIndex].value === p.value) {
                    animationError = "";
                    return true;
                }
                nextChannel.keys[keyIndex].value = p.value;
                nextChannels[channelIndex] = nextChannel;
            } else {
                var nextKey = {
                    "id": "animationKey" + (_animationKeySerial++),
                    "time": Number(frame),
                    "value": p.value,
                    "interpolation": nextChannel.kind === "number" ? "linear" : "hold",
                    "inSlope": 0,
                    "outSlope": 0,
                    "tangentMode": "broken"
                };
                nextChannel.keys.push(nextKey);
                _animationSortKeys(nextChannel.keys);
                _animationDefaultTangents(nextChannel.keys, _animationFindTime(nextChannel.keys, Number(frame)));
                nextChannels[channelIndex] = nextChannel;
            }
            animationChannels = nextChannels;
        } else {
            var newChannel = {
                "id": channelId,
                "nodeId": String(nodeId),
                "parameterKey": String(key),
                "label": p.label,
                "kind": p.kind,
                "keys": [{
                        "id": "animationKey" + (_animationKeySerial++),
                        "time": Number(frame),
                        "value": p.value,
                        "interpolation": p.kind === "number" ? "linear" : "hold",
                        "inSlope": 0,
                        "outSlope": 0,
                        "tangentMode": "broken"
                    }]
            };
            animationChannels = channels.concat([newChannel]);
        }
        animationError = "";
        _animationTouch();
        return true;
    }
    function keyStatus(nodeId, key) {
        var channel = _animationChannel(_animationChannelId(nodeId, key));
        if (!channel || !channel.keys || channel.keys.length === 0)
            return "none";
        return _animationFindTime(channel.keys, Number(frame)) >= 0 ? "key" : "animated";
    }
    function setParam(id, key, value) {
        var n = node(id);
        if (!n)
            return;
        for (var i = 0; i < n.params.length; ++i)
            if (String(n.params[i].key) === String(key)) {
                if (n.params[i].value === value)
                    return;
                n.params[i].value = value;
                var channel = _animationChannel(_animationChannelId(id, key)), keyIndex = channel ? _animationFindTime(channel.keys || [], Number(frame)) : -1;
                if (keyIndex >= 0) {
                    var channels = animationChannels.slice(), channelIndex = channels.indexOf(channel), nextChannel = _animationChannelClone(channel);
                    nextChannel.keys[keyIndex].value = value;
                    channels[channelIndex] = nextChannel;
                    animationChannels = channels;
                    animationError = "";
                    _animationTouch();
                } else {
                    revision++;
                }
                return;
            }
    }

    function moveAnimationKeys(ids, deltaTime, deltaValue) {
        var uniqueIds = _animationIds(ids), dt = Number(deltaTime), dv = Number(deltaValue);
        if (!isFinite(dt) || !isFinite(dv)) {
            animationError = "Animation move requires finite deltas.";
            return false;
        }
        var channels = animationChannels || [], records = [], selected = {};
        for (var i = 0; i < uniqueIds.length; ++i) {
            var location = _animationKeyLocation(uniqueIds[i]);
            if (!location) {
                animationError = "Animation key does not exist.";
                return false;
            }
            var sourceChannel = channels[location.channelIndex], sourceKey = sourceChannel.keys[location.keyIndex];
            records.push({
                    "channelIndex": location.channelIndex,
                    "keyIndex": location.keyIndex,
                    "id": uniqueIds[i],
                    "channel": sourceChannel,
                    "key": sourceKey,
                    "time": Number(sourceKey.time) + dt,
                    "value": sourceChannel.kind === "number" && _isAnimationNumber(sourceKey.value) ? Number(sourceKey.value) + dv : sourceKey.value
                });
            selected[uniqueIds[i]] = true;
        }
        for (var r = 0; r < records.length; ++r) {
            for (var s = r + 1; s < records.length; ++s)
                if (records[r].channelIndex === records[s].channelIndex && Math.abs(records[r].time - records[s].time) <= 1e-6) {
                    animationError = records[r].channel.nodeId + " / " + records[r].channel.label + ": two selected keys would occupy frame " + records[r].time + ".";
                    return false;
                }
            var existingKeys = records[r].channel.keys || [];
            for (var k = 0; k < existingKeys.length; ++k)
                if (!selected[String(existingKeys[k].id)] && Math.abs(records[r].time - Number(existingKeys[k].time)) <= 1e-6) {
                    animationError = records[r].channel.nodeId + " / " + records[r].channel.label + ": frame " + records[r].time + " already contains key " + existingKeys[k].id + ".";
                    return false;
                }
        }
        var nextChannels = channels.slice(), cloned = {};
        for (var m = 0; m < records.length; ++m) {
            var rec = records[m], index = rec.channelIndex;
            if (!cloned[index]) {
                cloned[index] = _animationChannelClone(channels[index]);
                nextChannels[index] = cloned[index];
            }
            cloned[index].keys[rec.keyIndex].time = rec.time;
            cloned[index].keys[rec.keyIndex].value = rec.value;
        }
        for (var c in cloned)
            _animationSortKeys(cloned[c].keys);
        animationChannels = nextChannels;
        animationError = "";
        _animationTouch();
        return true;
    }

    function deleteAnimationKeys(ids) {
        var uniqueIds = _animationIds(ids), channels = animationChannels || [], removed = {}, found = false;
        for (var i = 0; i < uniqueIds.length; ++i)
            if (_animationKeyLocation(uniqueIds[i])) {
                removed[uniqueIds[i]] = true;
                found = true;
            }
        if (!found) {
            animationError = "Animation key does not exist.";
            return false;
        }
        var nextChannels = [], affected = false;
        for (var c = 0; c < channels.length; ++c) {
            var source = channels[c], next = _animationChannelClone(source), nextKeys = [];
            for (var k = 0; k < next.keys.length; ++k)
                if (!removed[String(next.keys[k].id)])
                    nextKeys.push(next.keys[k]);
            if (nextKeys.length > 0)
                next.keys = nextKeys, nextChannels.push(next);
            else
                affected = true;
            if (nextKeys.length !== source.keys.length)
                affected = true;
        }
        animationChannels = nextChannels;
        var nextSelectedKeys = [], selectedKeys = selectedAnimationKeyIds || [];
        for (var sk = 0; sk < selectedKeys.length; ++sk)
            if (!removed[String(selectedKeys[sk])])
                nextSelectedKeys.push(selectedKeys[sk]);
        selectedAnimationKeyIds = nextSelectedKeys;
        var selectedChannels = selectedAnimationChannelIds || [], nextSelectedChannels = [];
        for (var sc = 0; sc < selectedChannels.length; ++sc)
            if (_animationChannel(selectedChannels[sc]))
                nextSelectedChannels.push(selectedChannels[sc]);
        selectedAnimationChannelIds = nextSelectedChannels;
        animationError = "";
        _animationTouch();
        return affected;
    }

    function setAnimationInterpolation(ids, mode) {
        var resolvedMode = String(mode), uniqueIds = _animationIds(ids), channels = animationChannels || [], changes = [];
        if (resolvedMode !== "linear" && resolvedMode !== "hold" && resolvedMode !== "bezier") {
            animationError = "Unknown animation interpolation.";
            return false;
        }
        for (var i = 0; i < uniqueIds.length; ++i) {
            var location = _animationKeyLocation(uniqueIds[i]);
            if (!location) {
                animationError = "Animation key does not exist.";
                return false;
            }
            changes.push(location);
        }
        if (changes.length === 0) {
            animationError = "Animation key does not exist.";
            return false;
        }
        var nextChannels = channels.slice(), cloned = {}, changed = false;
        for (var j = 0; j < changes.length; ++j) {
            var change = changes[j], channel = channels[change.channelIndex];
            if (!cloned[change.channelIndex]) {
                cloned[change.channelIndex] = _animationChannelClone(channel);
                nextChannels[change.channelIndex] = cloned[change.channelIndex];
            }
            var nextMode = cloned[change.channelIndex].kind === "number" ? resolvedMode : "hold";
            if (cloned[change.channelIndex].keys[change.keyIndex].interpolation !== nextMode)
                changed = true;
            cloned[change.channelIndex].keys[change.keyIndex].interpolation = nextMode;
        }
        if (!changed) {
            animationError = "";
            return true;
        }
        animationChannels = nextChannels;
        animationError = "";
        _animationTouch();
        return true;
    }

    function setAnimationTangent(keyId, side, slope) {
        var location = _animationKeyLocation(keyId);
        if (!location || (side !== "in" && side !== "out") || !_isAnimationNumber(slope)) {
            animationError = "Invalid animation tangent.";
            return false;
        }
        var numericSlope = Number(slope), channels = animationChannels || [], channel = channels[location.channelIndex];
        if (channel.kind !== "number") {
            animationError = "Discrete animation has no tangents.";
            return false;
        }
        var nextChannels = channels.slice(), nextChannel = _animationChannelClone(channel), key = nextChannel.keys[location.keyIndex];
        var oldIn = Number(key.inSlope), oldOut = Number(key.outSlope);
        if (key.tangentMode === "smooth") {
            key.inSlope = numericSlope;
            key.outSlope = numericSlope;
        } else if (side === "in") {
            key.inSlope = numericSlope;
        } else {
            key.outSlope = numericSlope;
        }
        if (oldIn === Number(key.inSlope) && oldOut === Number(key.outSlope)) {
            animationError = "";
            return true;
        }
        nextChannels[location.channelIndex] = nextChannel;
        animationChannels = nextChannels;
        animationError = "";
        _animationTouch();
        return true;
    }
    function setAnimationTangentMode(ids, mode) {
        var resolvedMode = String(mode), uniqueIds = _animationIds(ids);
        if (resolvedMode !== "smooth" && resolvedMode !== "broken") {
            animationError = "Unknown animation tangent mode.";
            return false;
        }
        if (uniqueIds.length === 0) {
            animationError = "Animation key does not exist.";
            return false;
        }
        var channels = animationChannels || [], locations = [];
        for (var i = 0; i < uniqueIds.length; ++i) {
            var location = _animationKeyLocation(uniqueIds[i]);
            if (!location) {
                animationError = "Animation key does not exist.";
                return false;
            }
            if (channels[location.channelIndex].kind !== "number") {
                animationError = "Discrete animation has no tangents.";
                return false;
            }
            locations.push(location);
        }
        var nextChannels = channels.slice(), cloned = {}, changed = false;
        for (var j = 0; j < locations.length; ++j) {
            var entry = locations[j], index = entry.channelIndex;
            if (!cloned[index]) {
                cloned[index] = _animationChannelClone(channels[index]);
                nextChannels[index] = cloned[index];
            }
            var key = cloned[index].keys[entry.keyIndex], oldMode = key.tangentMode;
            if (resolvedMode === "smooth") {
                var average = (Number(key.inSlope) + Number(key.outSlope)) / 2;
                if (oldMode !== "smooth" || Number(key.inSlope) !== average || Number(key.outSlope) !== average)
                    changed = true;
                key.inSlope = average;
                key.outSlope = average;
            } else if (oldMode !== "broken") {
                changed = true;
            }
            key.tangentMode = resolvedMode;
        }
        if (!changed) {
            animationError = "";
            return true;
        }
        animationChannels = nextChannels;
        animationError = "";
        _animationTouch();
        return true;
    }
    function moveNodes(moves) {
        var graph = _activeGraph();
        if (!graph || !moves)
            return;
        var moved = false;
        for (var i = 0; i < moves.length; ++i) {
            var entry = nodeIndex[moves[i].id];
            if (!entry || entry.graphId !== activeGraphId)
                continue;
            var n = entry.node;
            if (n.x !== moves[i].x || n.y !== moves[i].y) {
                n.x = moves[i].x;
                n.y = moves[i].y;
                moved = true;
            }
        }
        if (moved)
            nodesMoved();
    }
    function _copyGraph(graph, nodes, edgeList) {
        var result = {};
        for (var propertyName in graph)
            result[propertyName] = graph[propertyName];
        result.nodes = nodes;
        result.edges = edgeList;
        return result;
    }
    function deleteNodes(ids) {
        var graph = _activeGraph();
        if (!graph) {
            graphError = "Delete: no active graph.";
            return false;
        }
        var source = ids === undefined || ids === null ? (selectedNodeIds || []) : (Array.isArray(ids) ? ids : [ids]), uniqueIds = [];
        for (var i = 0; i < source.length; ++i) {
            var id = String(source[i] || "");
            if (!id || uniqueIds.indexOf(id) >= 0)
                continue;
            uniqueIds.push(id);
        }
        if (uniqueIds.length === 0) {
            graphError = "Delete: no nodes selected.";
            return false;
        }
        var selectedSet = {}, selectedNodes = [];
        for (var selectedIndex = 0; selectedIndex < uniqueIds.length; ++selectedIndex) {
            var selectedNode = _nodeIn(graph.nodes, uniqueIds[selectedIndex]);
            if (!selectedNode) {
                graphError = "Delete rejected: node is not in the active graph.";
                return false;
            }
            if (selectedNode.type === "Input" || selectedNode.type === "Output") {
                graphError = "Delete rejected: graph interface terminals cannot be deleted.";
                return false;
            }
            selectedSet[uniqueIds[selectedIndex]] = true;
            selectedNodes.push(selectedNode);
        }
        var activeError = _validateEdgeList(graph.edges || [], graph.nodes || []);
        if (activeError) {
            graphError = "Delete rejected: " + activeError;
            return false;
        }
        var removedGraphs = {}, removedNodes = {};
        function collectOwnedGraph(graphId) {
            var key = String(graphId || "");
            if (!key)
                return "";
            if (key === String(activeGraphId))
                return "subnet owns the active graph.";
            if (removedGraphs[key])
                return "";
            var owned = _graph(key);
            if (!owned)
                return "subnet child graph does not exist.";
            removedGraphs[key] = true;
            for (var ownedIndex = 0; ownedIndex < (owned.nodes || []).length; ++ownedIndex) {
                var ownedNode = owned.nodes[ownedIndex];
                removedNodes[String(ownedNode.id)] = true;
            }
            for (var nestedIndex = 0; nestedIndex < (owned.nodes || []).length; ++nestedIndex) {
                var nested = owned.nodes[nestedIndex];
                if (nested.type === "Subnet" && nested.childGraphId) {
                    var nestedError = collectOwnedGraph(nested.childGraphId);
                    if (nestedError)
                        return nestedError;
                }
            }
            return "";
        }
        for (var selectedSubnetIndex = 0; selectedSubnetIndex < selectedNodes.length; ++selectedSubnetIndex) {
            var selectedSubnet = selectedNodes[selectedSubnetIndex];
            if (selectedSubnet.type === "Subnet" && selectedSubnet.childGraphId) {
                var ownedError = collectOwnedGraph(selectedSubnet.childGraphId);
                if (ownedError) {
                    graphError = "Delete rejected: " + ownedError;
                    return false;
                }
            }
        }
        for (var removedIdIndex = 0; removedIdIndex < uniqueIds.length; ++removedIdIndex)
            removedNodes[uniqueIds[removedIdIndex]] = true;
        var nextNodes = [], nextEdges = [];
        for (var nodeIndex = 0; nodeIndex < graph.nodes.length; ++nodeIndex)
            if (!selectedSet[String(graph.nodes[nodeIndex].id)])
                nextNodes.push(graph.nodes[nodeIndex]);
        for (var edgeIndex = 0; edgeIndex < graph.edges.length; ++edgeIndex) {
            var edge = graph.edges[edgeIndex];
            if (!selectedSet[String(edge.from)] && !selectedSet[String(edge.to)])
                nextEdges.push(edge);
        }
        var nextError = _validateEdgeList(nextEdges, nextNodes);
        if (nextError) {
            graphError = "Delete rejected: " + nextError;
            return false;
        }
        var nextGraphs = {};
        for (var existingGraphId in graphs)
            if (!removedGraphs[existingGraphId] && existingGraphId !== String(activeGraphId))
                nextGraphs[existingGraphId] = graphs[existingGraphId];
        var replacement = _copyGraph(graph, nextNodes, nextEdges);
        nextGraphs[activeGraphId] = replacement;
        var nextSelections = {}, selectionState = _selectionByGraph || {};
        for (var survivingGraphId in nextGraphs) {
            var survivingGraph = nextGraphs[survivingGraphId], survivingSelection = selectionState[survivingGraphId] || [], filteredSelection = [];
            for (var selectionIndex = 0; selectionIndex < survivingSelection.length; ++selectionIndex)
                if (_nodeIn(survivingGraph.nodes || [], survivingSelection[selectionIndex]))
                    filteredSelection.push(String(survivingSelection[selectionIndex]));
            nextSelections[survivingGraphId] = filteredSelection;
        }
        var nextContexts = {}, changedContexts = [], contextState = _graphContexts || {};
        for (var contextId in contextState) {
            var context = contextState[contextId] || {}, contextCopy = {};
            for (var contextProperty in context)
                contextCopy[contextProperty] = context[contextProperty];
            var contextGraphId = String(context.graphId || ""), contextNodeId = String(context.nodeId || "");
            if (removedGraphs[contextGraphId] || removedNodes[contextNodeId]) {
                contextCopy.graphId = "";
                contextCopy.nodeId = "";
                changedContexts.push(String(contextId));
            }
            nextContexts[contextId] = contextCopy;
        }
        graphs = nextGraphs;
        _publishActive(replacement);
        _selectionByGraph = nextSelections;
        setSelection(nextSelections[activeGraphId] || []);
        _graphContexts = nextContexts;
        for (var changedContextIndex = 0; changedContextIndex < changedContexts.length; ++changedContextIndex)
            graphContextChanged(changedContexts[changedContextIndex]);
        if (removedNodes[String(viewerNodeId)])
            viewerNodeId = "";
        _pruneAnimationNodes(removedNodes);
        revision++;
        graphError = "";
        return true;
    }
    function setViewer(groupOrId, maybeId) {
        var group = maybeId === undefined ? "A" : String(groupOrId);
        var id = maybeId === undefined ? String(groupOrId) : String(maybeId);
        var entry = nodeIndex[id];
        if (!_validGroup(group) || !entry)
            return false;
        if (!setGraphContext(group, {
                "graphId": entry.graphId,
                "nodeId": id
            }))
            return false;
        if (group === "A")
            viewerNodeId = id;
        return true;
    }
    function loadPanelState(id) {
        return panelStates[id] || null;
    }
    function savePanelState(id, state) {
        var panelId = String(id || ""), next = JSON.parse(JSON.stringify(state || {}));
        if (!panelId)
            return;
        if (panelStates[panelId] && next.viewerRole === undefined)
            next.viewerRole = panelStates[panelId].viewerRole;
        var states = {};
        for (var stateId in panelStates)
            states[stateId] = panelStates[stateId];
        states[panelId] = next;
        panelStates = states;
    }

    function _updateBreadcrumbs() {
        var result = [], graph = _activeGraph(), guard = 0;
        while (graph && guard++ < 100) {
            result.unshift({
                    "id": graph.id,
                    "name": graph.name
                });
            graph = _graph(graph.parentGraphId);
        }
        breadcrumbs = result;
    }
    function _activateGraph() {
        var graph = _activeGraph();
        if (!graph)
            return false;
        _publishActive(graph);
        _updateBreadcrumbs();
        var saved = (_selectionByGraph || {})[activeGraphId] || [];
        setSelection(saved);
        return true;
    }
    function enterSubnet(id) {
        var subnet = _nodeIn((_activeGraph() || {}).nodes || [], id);
        if (!subnet || subnet.type !== "Subnet" || !_graph(subnet.childGraphId))
            return false;
        activeGraphId = subnet.childGraphId;
        return true;
    }
    function navigateGraph(graphId) {
        if (!_graph(graphId))
            return false;
        activeGraphId = graphId;
        return true;
    }

    function _portKey(source, output, type) {
        return String(source) + "|" + String(output) + "|" + type;
    }
    function collapseSelection(name) {
        var graph = _activeGraph(), selected = selectedNodeIds.slice();
        if (!graph || selected.length === 0) {
            graphError = "Select at least one node to collapse.";
            return "";
        }
        var selectedSet = {}, selectedNodes = [];
        for (var i = 0; i < selected.length; ++i) {
            var selectedNode = _nodeIn(graph.nodes, selected[i]);
            if (!selectedNode) {
                graphError = "Selection contains a node outside the active graph.";
                return "";
            }
            if (selectedNode.type === "Input" || selectedNode.type === "Output") {
                graphError = "Collapse rejected: graph interface terminals cannot be selected.";
                return "";
            }
            selectedSet[String(selected[i])] = true;
            selectedNodes.push(selectedNode);
        }
        var subnetId = "subnet" + serial, childId = "graph" + serial, inputs = [], outputs = [], inputMap = {}, outputMap = {};
        var childNodes = selectedNodes.slice(), childEdges = [], parentEdges = [], crossingIn = [], crossingOut = [];
        for (var e = 0; e < graph.edges.length; ++e) {
            var edge = graph.edges[e], fromInside = !!selectedSet[String(edge.from)], toInside = !!selectedSet[String(edge.to)];
            if (fromInside && toInside)
                childEdges.push(edge);
            else if (!fromInside && toInside)
                crossingIn.push(edge);
            else if (fromInside && !toInside)
                crossingOut.push(edge);
        }
        var minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
        for (var sn = 0; sn < selectedNodes.length; ++sn) {
            minX = Math.min(minX, Number(selectedNodes[sn].x) || 0);
            minY = Math.min(minY, Number(selectedNodes[sn].y) || 0);
            maxX = Math.max(maxX, (Number(selectedNodes[sn].x) || 0) + 120);
            maxY = Math.max(maxY, (Number(selectedNodes[sn].y) || 0) + 70);
        }
        var routerIndex = 0;
        for (var ci = 0; ci < crossingIn.length; ++ci) {
            var incoming = crossingIn[ci], destination = _nodeIn(selectedNodes, incoming.to);
            var destinationPort = _portFor(_inputPortsForNode(destination), _edgeInput(incoming));
            if (!destinationPort) {
                graphError = "Cannot collapse: invalid incoming destination port.";
                return "";
            }
            var key = _portKey(incoming.from, _edgeOutput(incoming), destinationPort.type), port = inputMap[key];
            if (!port) {
                var hasMaskPort = false;
                for (var existingPort = 0; existingPort < inputs.length; ++existingPort)
                    if (inputs[existingPort].type === "mask")
                        hasMaskPort = true;
                routerIndex++;
                var portId = destinationPort.type === "mask" ? (hasMaskPort ? "mask" + routerIndex : "mask") : "in" + routerIndex;
                port = _port(portId, destinationPort.type === "mask" ? "Mask" : "Input " + inputs.length, destinationPort.type, destinationPort.type === "mask" ? "right" : "top");
                inputMap[key] = port;
                inputs.push(port);
                var inNode = makeRouter("inputRouter" + serial + "_" + routerIndex, "Input " + portId, "Input", 0, 0, port);
                childNodes.push(inNode);
                parentEdges.push({
                        "from": incoming.from,
                        "to": subnetId,
                        "input": port.id,
                        "output": _edgeOutput(incoming)
                    });
            }
            var proxy = null;
            for (var pn = 0; pn < childNodes.length; ++pn)
                if (childNodes[pn].type === "Input" && childNodes[pn].interfacePort && _samePort(childNodes[pn].interfacePort.id, port.id))
                    proxy = childNodes[pn];
            childEdges.push({
                    "from": proxy.id,
                    "to": incoming.to,
                    "input": _edgeInput(incoming),
                    "output": 0
                });
        }
        // Every subnet has an explicit mask interface. An unconnected Input proxy is
        // retained when the selected region has no incoming mask crossing.
        var hasMask = false;
        for (var mi = 0; mi < inputs.length; ++mi)
            if (inputs[mi].type === "mask")
                hasMask = true;
        if (!hasMask) {
            var maskPort = _port("mask", "Mask", "mask", "right");
            inputs.push(maskPort);
            childNodes.push(makeRouter("inputRouter" + serial + "_mask", "Mask Input", "Input", 0, 0, maskPort));
        }
        for (var co = 0; co < crossingOut.length; ++co) {
            var outgoing = crossingOut[co], source = _nodeIn(selectedNodes, outgoing.from);
            var sourcePort = _portFor(_outputPortsForNode(source), _edgeOutput(outgoing));
            if (!sourcePort) {
                graphError = "Cannot collapse: invalid outgoing source port.";
                return "";
            }
            var outKey = _portKey(outgoing.from, _edgeOutput(outgoing), sourcePort.type), outPort = outputMap[outKey], newOutput = false;
            if (!outPort) {
                var outId = "out" + (outputs.length + 1);
                outPort = _port(outId, "Output " + (outputs.length + 1), sourcePort.type, "bottom");
                outputMap[outKey] = outPort;
                outputs.push(outPort);
                newOutput = true;
                var outNode = makeRouter("outputRouter" + serial + "_" + outputs.length, "Output " + outputs.length, "Output", 0, 0, outPort);
                childNodes.push(outNode);
            }
            if (newOutput) {
                var outputProxy = null;
                for (var op = 0; op < childNodes.length; ++op)
                    if (childNodes[op].type === "Output" && childNodes[op].interfacePort && _samePort(childNodes[op].interfacePort.id, outPort.id))
                        outputProxy = childNodes[op];
                childEdges.push({
                        "from": outgoing.from,
                        "to": outputProxy.id,
                        "input": outPort.id,
                        "output": _edgeOutput(outgoing)
                    });
            }
            parentEdges.push({
                    "from": subnetId,
                    "to": outgoing.to,
                    "input": _edgeInput(outgoing),
                    "output": outPort.id
                });
        }
        if (outputs.length === 0) {
            var candidates = [];
            for (var q = 0; q < selectedNodes.length; ++q) {
                var candidate = selectedNodes[q], candidatePorts = _outputPortsForNode(candidate);
                for (var qp = 0; qp < candidatePorts.length; ++qp) {
                    var consumed = false;
                    for (var ce = 0; ce < childEdges.length; ++ce)
                        if (String(childEdges[ce].from) === String(candidate.id) && _samePort(_edgeOutput(childEdges[ce]), candidatePorts[qp].id))
                            consumed = true;
                    if (!consumed)
                        candidates.push({
                                "node": candidate,
                                "port": candidatePorts[qp]
                            });
                }
            }
            // Viewers inspect an image but cannot supply an output. Expose their
            // incoming image instead, not an arbitrary upstream Read node.
            for (var vi = 0; vi < selectedNodes.length; ++vi) {
                if (selectedNodes[vi].type !== "Viewer")
                    continue;
                for (var ve = 0; ve < childEdges.length; ++ve) {
                    var viewerEdge = childEdges[ve];
                    if (viewerEdge.to !== selectedNodes[vi].id || !_samePort(viewerEdge.input, 0))
                        continue;
                    var viewedSource = _nodeIn(childNodes, viewerEdge.from);
                    var viewedPort = _portFor(_outputPortsForNode(viewedSource), _edgeOutput(viewerEdge));
                    if (!viewedPort)
                        continue;
                    var duplicate = false;
                    for (var vc = 0; vc < candidates.length; ++vc)
                        if (candidates[vc].node.id === viewedSource.id && _samePort(candidates[vc].port.id, viewedPort.id))
                            duplicate = true;
                    if (!duplicate)
                        candidates.push({
                                "node": viewedSource,
                                "port": viewedPort
                            });
                }
            }
            if (candidates.length === 0) {
                graphError = "Collapse rejected: selected nodes have no connected image or output to expose.";
                return "";
            }
            for (var oi = 0; oi < candidates.length; ++oi) {
                var candidateOutput = candidates[oi], fallbackPort = _port("out" + (outputs.length + 1), "Output " + (outputs.length + 1), candidateOutput.port.type, "bottom");
                outputs.push(fallbackPort);
                var fallbackNode = makeRouter("outputRouter" + serial + "_" + outputs.length, "Output " + outputs.length, "Output", 0, 0, fallbackPort);
                childNodes.push(fallbackNode);
                childEdges.push({
                        "from": candidateOutput.node.id,
                        "to": fallbackNode.id,
                        "input": fallbackPort.id,
                        "output": candidateOutput.port.id
                    });
            }
        }
        // Arrange only the generated terminals; keep the user's internal layout intact.
        var inputColumn = 0, outputColumn = 0;
        var inputSpacing = Math.max(160, (maxX - minX - 112) / Math.max(1, inputs.length - 1));
        var outputSpacing = Math.max(160, (maxX - minX - 112) / Math.max(1, outputs.length - 1));
        for (var ri = 0; ri < childNodes.length; ++ri) {
            var terminal = childNodes[ri];
            if (terminal.type === "Input") {
                terminal.x = minX + inputColumn++ * inputSpacing;
                terminal.y = minY - 110;
            } else if (terminal.type === "Output") {
                terminal.x = minX + outputColumn++ * outputSpacing;
                terminal.y = maxY + 80;
            }
        }
        var subnet = makeNode(subnetId, name && String(name).trim() ? String(name).trim() : "Subnet", minX, minY);
        subnet.childGraphId = childId;
        subnet.interfaceInputs = inputs;
        subnet.interfaceOutputs = outputs;
        var retained = [];
        for (var ge = 0; ge < graph.edges.length; ++ge) {
            var old = graph.edges[ge];
            if (!selectedSet[String(old.from)] && !selectedSet[String(old.to)])
                retained.push(old);
        }
        var nextParentEdges = retained.concat(parentEdges);
        var nextParentNodes = [];
        for (var gn = 0; gn < graph.nodes.length; ++gn)
            if (!selectedSet[String(graph.nodes[gn].id)])
                nextParentNodes.push(graph.nodes[gn]);
        nextParentNodes.push(subnet);
        var parentError = _validateEdgeList(nextParentEdges, nextParentNodes);
        if (parentError) {
            graphError = "Collapse rejected: " + parentError;
            return "";
        }
        var childGraph = {
            "id": childId,
            "name": subnet.name,
            "parentGraphId": graph.id,
            "ownerNodeId": subnetId,
            "nodes": childNodes,
            "edges": childEdges
        };
        var childError = _validateEdgeList(childEdges, childNodes);
        if (childError) {
            graphError = "Collapse rejected: " + childError;
            return "";
        }
        // Commit only after both complete graphs validate, making collapse atomic.
        for (var moved = 0; moved < selectedNodes.length; ++moved) {
            if (selectedNodes[moved].type === "Subnet" && selectedNodes[moved].childGraphId && _graph(selectedNodes[moved].childGraphId))
                _graph(selectedNodes[moved].childGraphId).parentGraphId = childId;
        }
        var nextGraphs = {};
        for (var existing in graphs)
            nextGraphs[existing] = graphs[existing];
        nextGraphs[childId] = childGraph;
        graphs = nextGraphs;
        _replaceGraph(graph, nextParentNodes, nextParentEdges);
        serial++;
        revision++;
        graphError = "";
        setSelection([subnetId]);
        return subnetId;
    }

    function leaf(id, type) {
        return {
            "kind": "tabs",
            "id": id,
            "active": id + "_panel",
            "panels": [{
                    "id": id + "_panel",
                    "type": type,
                    "group": "A"
                }]
        };
    }
    function split(id, orientation, ratio, a, b) {
        return {
            "kind": "split",
            "id": id,
            "orientation": orientation,
            "ratio": ratio,
            "children": [a, b]
        };
    }
    function layout(name) {
        var root;
        if (name === "Comp")
            root = split("comp_root", "horizontal", 0.51, split("comp_left", "vertical", 0.55, leaf("comp_viewer", "viewer"), leaf("comp_animation", "animation")), split("comp_right", "vertical", 0.49, leaf("comp_parameters", "parameters"), leaf("comp_graph", "nodegraph")));
        else if (name === "Edit")
            root = split("edit_root", "vertical", 0.58, split("edit_top", "horizontal", 0.36, leaf("edit_media", "mediabin"), leaf("edit_viewer", "viewer")), leaf("edit_timeline", "timeline"));
        else if (name === "Image")
            root = split("image_root", "horizontal", 0.7, leaf("image_viewer", "viewer"), leaf("image_parameters", "parameters"));
        else
            root = split("project_root", "horizontal", 0.65, leaf("project_graph", "nodegraph"), leaf("project_parameters", "parameters"));
        return {
            "version": 1,
            "root": root
        };
    }
    function switchWorkspace(index) {
        if (index < 0 || index >= workspaces.length || index === activeWorkspace)
            return;
        var next = workspaces.slice();
        next[activeWorkspace].layout = workspace.snapshot();
        workspaces = next;
        activeWorkspace = index;
        workspace.restoreSnapshot(workspaces[index].layout);
    }
    function duplicateWorkspace(name) {
        var copy = JSON.parse(JSON.stringify(workspace.snapshot())), suffix = "_w" + (serial++);
        function remap(n) {
            n.id += suffix;
            if (n.kind === "split") {
                remap(n.children[0]);
                remap(n.children[1]);
            } else {
                n.active += suffix;
                for (var i = 0; i < n.panels.length; ++i)
                    n.panels[i].id += suffix;
            }
        }
        remap(copy.root);
        var next = workspaces.slice();
        next[activeWorkspace].layout = workspace.snapshot();
        next.push({
                "name": name.trim() || "Workspace",
                "layout": copy
            });
        workspaces = next;
        activeWorkspace = next.length - 1;
        workspace.restoreSnapshot(copy);
    }
    function renameWorkspace(index, name) {
        if (!name.trim())
            return;
        var next = workspaces.slice();
        next[index] = {
            "name": name.trim(),
            "layout": next[index].layout
        };
        workspaces = next;
    }
    function closeWorkspace(index) {
        if (workspaces.length <= 1)
            return;
        var next = workspaces.slice();
        next[activeWorkspace].layout = workspace.snapshot();
        next.splice(index, 1);
        var selected = activeWorkspace > index ? activeWorkspace - 1 : Math.min(activeWorkspace, next.length - 1);
        workspaces = next;
        activeWorkspace = selected;
        workspace.restoreSnapshot(next[selected].layout);
    }
    function moveWorkspace(index, delta) {
        var target = index + delta;
        if (target < 0 || target >= workspaces.length)
            return;
        var next = workspaces.slice();
        var entry = next.splice(index, 1)[0];
        next.splice(target, 0, entry);
        if (activeWorkspace === index)
            activeWorkspace = target;
        else if (activeWorkspace === target)
            activeWorkspace = index;
        workspaces = next;
    }

    onFrameChanged: {
        _evaluateAnimationFrame(frame);
        revision++;
        if (!_syncingCompatibilityFrame) {
            _syncingCompatibilityFrame = true;
            setTimelineContext("A", {
                    "frame": frame
                });
            setGraphTimeContext("A", {
                    "frame": frame
                });
            _syncingCompatibilityFrame = false;
        }
    }

    onActiveGraphIdChanged: {
        _activateGraph();
        activeGraphChanged();
    }
    Component.onCompleted: {
        var rootNodes = [makeNode("plateA", "Plate_A", "Read", 55, 30), makeNode("plateB", "Plate_B", "Read", 335, 30), makeNode("color1", "ColorCorrect1", "ColorCorrect", 55, 125), makeNode("transform1", "Transform1", "Transform", 335, 125), makeNode("merge1", "Merge1", "Merge", 195, 245), makeNode("viewer1", "Viewer1", "Viewer", 195, 340)];
        var rootEdges = [{
                "from": "plateA",
                "to": "color1",
                "input": 0,
                "output": 0
            }, {
                "from": "plateB",
                "to": "transform1",
                "input": 0,
                "output": 0
            }, {
                "from": "color1",
                "to": "merge1",
                "input": 0,
                "output": 0
            }, {
                "from": "transform1",
                "to": "merge1",
                "input": 1,
                "output": 0
            }, {
                "from": "merge1",
                "to": "viewer1",
                "input": 0,
                "output": 0
            }];
        graphs = {
            "root": {
                "id": "root",
                "name": "Root",
                "parentGraphId": "",
                "ownerNodeId": "",
                "nodes": rootNodes,
                "edges": rootEdges
            }
        };
        _selectionByGraph = {
            "root": []
        };
        activeGraphId = "root";
        _activateGraph();
        _mediaContexts = ({});
        _mediaSourceContexts = ({});
        var initialTime = _sequenceTimeContext();
        _timelineContexts = {
            "A": initialTime,
            "B": initialTime,
            "C": initialTime,
            "D": initialTime,
            "E": initialTime
        };
        _graphTimeContexts = {
            "A": initialTime,
            "B": initialTime,
            "C": initialTime,
            "D": initialTime,
            "E": initialTime
        };
        _graphContexts = {
            "A": {
                "graphId": "root",
                "nodeId": "merge1"
            }
        };
        _viewerRoles = ({});
        mediaRevision++;
        workspaces = [{
                "name": "Project",
                "layout": layout("Project")
            }, {
                "name": "Edit",
                "layout": layout("Edit")
            }, {
                "name": "Image",
                "layout": layout("Image")
            }, {
                "name": "Comp",
                "layout": layout("Comp")
            }];
        _evaluateAnimationFrame(frame);
    }
}
