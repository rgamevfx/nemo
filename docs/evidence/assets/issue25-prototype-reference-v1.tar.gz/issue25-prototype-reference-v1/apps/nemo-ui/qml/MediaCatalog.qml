import QtQuick

// Session-only organizational catalog. Catalog edits never alter timeline media;
// records retain stable sourceId references into the timeline source list.
QtObject {
    id: root

    property var timeline: null
    property var items: []
    property int revision: 0
    property string error: ""

    property var _undo: []
    property var _redo: []
    property int _nextBinSeq: 1
    property int _nextItemSeq: 1
    property bool _seeded: false

    readonly property bool canUndo: _undo.length > 0
    readonly property bool canRedo: _redo.length > 0

    Component.onCompleted: _seedFromTimeline()

    readonly property Connections sourceChanges: Connections {
        target: root.timeline
        function onSourcesChanged() {
            root._seedFromTimeline();
        }
    }

    function _cloneTags(tags) {
        var out = [];
        for (var i = 0; i < (tags || []).length; ++i)
            out.push(String(tags[i]));
        return out;
    }

    function _cloneItem(item) {
        return {
            "id": item.id,
            "parentId": item.id === "root" ? "" : (item.parentId || "root"),
            "kind": item.kind,
            "name": item.name,
            "sourceId": item.sourceId || "",
            "duration": Number(item.duration) || 0,
            "color": item.color || "",
            "tags": _cloneTags(item.tags),
            "description": item.description || "",
            "offline": !!item.offline
        };
    }

    function _cloneItems(list) {
        var out = [];
        for (var i = 0; i < (list || []).length; ++i)
            out.push(_cloneItem(list[i]));
        return out;
    }

    function _snapshot() {
        return {
            "items": _cloneItems(items),
            "nextBinSeq": _nextBinSeq,
            "nextItemSeq": _nextItemSeq
        };
    }

    function _restore(snapshot) {
        items = _cloneItems(snapshot.items);
        // Sequence values are high-water marks. Undo must never make an ID
        // available for reuse while a later operation can still refer to it.
        _nextBinSeq = Math.max(_nextBinSeq, snapshot.nextBinSeq);
        _nextItemSeq = Math.max(_nextItemSeq, snapshot.nextItemSeq);
        revision += 1;
        error = "";
    }

    function _source(sourceId) {
        var list = timeline && timeline.sources ? timeline.sources : [];
        for (var i = 0; i < list.length; ++i)
            if (list[i] && list[i].id === sourceId)
                return list[i];
        return null;
    }

    function _record(id, list) {
        var source = list || items;
        for (var i = 0; i < source.length; ++i)
            if (source[i].id === id)
                return source[i];
        return null;
    }

    function _index(id, list) {
        var source = list || items;
        for (var i = 0; i < source.length; ++i)
            if (source[i].id === id)
                return i;
        return -1;
    }

    function _hasId(id, list) {
        return _index(id, list) >= 0;
    }

    function _childrenRaw(parentId, list) {
        var out = [];
        var source = list || items;
        for (var i = 0; i < source.length; ++i)
            if (source[i].id !== "root" && source[i].parentId === parentId)
                out.push(source[i]);
        return out;
    }

    function _descendantsRaw(id, list) {
        var out = [];
        var source = list || items;
        var queue = _childrenRaw(id, source);
        while (queue.length) {
            var child = queue.shift();
            out.push(child);
            var nested = _childrenRaw(child.id, source);
            for (var i = 0; i < nested.length; ++i)
                queue.push(nested[i]);
        }
        return out;
    }

    function _isAncestor(ancestorId, id, list) {
        if (ancestorId === id)
            return false;
        var source = list || items;
        var current = _record(id, source);
        var guard = {};
        while (current && current.parentId && !guard[current.id]) {
            guard[current.id] = true;
            if (current.parentId === ancestorId)
                return true;
            current = _record(current.parentId, source);
        }
        return false;
    }

    function _normalizeIds(ids, list) {
        var source = list || items;
        var unique = [];
        var seen = {};
        for (var i = 0; i < (ids || []).length; ++i) {
            var id = String(ids[i]);
            if (_record(id, source) && !seen[id] && id !== "root") {
                seen[id] = true;
                unique.push(id);
            }
        }
        var out = [];
        for (i = 0; i < unique.length; ++i) {
            var hasSelectedAncestor = false;
            for (var j = 0; j < unique.length; ++j) {
                if (i !== j && _isAncestor(unique[j], unique[i], source)) {
                    hasSelectedAncestor = true;
                    break;
                }
            }
            if (!hasSelectedAncestor)
                out.push(unique[i]);
        }
        return out;
    }

    function normalizeSelection(ids) {
        return _normalizeIds(ids || [], items);
    }

    function _validName(value) {
        if (typeof value !== "string")
            return false;
        var name = value.trim();
        if (!name.length || name.length > 128)
            return false;
        for (var i = 0; i < name.length; ++i)
            if (name.charCodeAt(i) < 32 || name.charCodeAt(i) === 127)
                return false;
        return true;
    }

    function _normalizedName(value) {
        return typeof value === "string" ? value.trim() : "";
    }

    function _sameName(a, b) {
        return a.trim().toLocaleLowerCase() === b.trim().toLocaleLowerCase();
    }

    function _nameAvailable(s, parentId, name, exceptId) {
        var siblings = _childrenRaw(parentId, s.items);
        for (var i = 0; i < siblings.length; ++i)
            if (siblings[i].id !== exceptId && _sameName(siblings[i].name, name))
                return false;
        return true;
    }

    function _validParent(s, parentId) {
        var parent = _record(parentId, s.items);
        return !!parent && parent.kind === "bin";
    }

    function _newId(s, bin) {
        var prefix = bin ? "bin-user-" : "media-copy-";
        var key = bin ? "nextBinSeq" : "nextItemSeq";
        var id;
        do {
            id = prefix + s[key];
            s[key] += 1;
        } while (_hasId(id, s.items))
        return id;
    }

    function _usedSources() {
        var used = {};
        var clips = timeline && timeline.clips ? timeline.clips : [];
        for (var i = 0; i < clips.length; ++i)
            if (clips[i] && clips[i].sourceId)
                used[clips[i].sourceId] = true;
        return used;
    }

    function _containsUsed(id, s, used) {
        var record = _record(id, s.items);
        if (!record)
            return false;
        if (record.kind !== "bin")
            return !!used[record.sourceId];
        var children = _descendantsRaw(id, s.items);
        for (var i = 0; i < children.length; ++i)
            if (children[i].kind !== "bin" && used[children[i].sourceId])
                return true;
        return false;
    }

    function _isUsedRecord(record, used, s) {
        if (record.kind !== "bin")
            return !!used[record.sourceId];
        var descendants = _descendantsRaw(record.id, s.items);
        for (var i = 0; i < descendants.length; ++i)
            if (descendants[i].kind !== "bin" && used[descendants[i].sourceId])
                return false;
        return true;
    }

    function _validColor(value) {
        return value === "" || (typeof value === "string" && /^#[0-9a-fA-F]{6,8}$/.test(value));
    }

    function _validTags(value) {
        if (!Array.isArray(value) || value.length > 64)
            return false;
        for (var i = 0; i < value.length; ++i) {
            if (typeof value[i] !== "string" || value[i].trim().length > 64 || !value[i].trim().length)
                return false;
            for (var j = 0; j < value[i].length; ++j)
                if (value[i].charCodeAt(j) < 32 || value[i].charCodeAt(j) === 127)
                    return false;
        }
        return true;
    }

    function _cleanTags(value) {
        var out = [];
        var seen = {};
        for (var i = 0; i < value.length; ++i) {
            var tag = value[i].trim();
            var key = tag.toLocaleLowerCase();
            if (!seen[key]) {
                seen[key] = true;
                out.push(tag);
            }
        }
        return out;
    }

    function _fail(message) {
        return {
            "ok": false,
            "error": message || "Catalog edit rejected"
        };
    }

    function _ok(s) {
        return {
            "ok": true,
            "state": s,
            "error": ""
        };
    }

    function _createBin(s, o) {
        var parentId = o.parentId === undefined || o.parentId === null ? "root" : String(o.parentId);
        var name = _normalizedName(o.name);
        if (!_validParent(s, parentId))
            return _fail("Unknown bin " + parentId);
        if (!_validName(name))
            return _fail("Bin name must be 1–128 printable characters");
        if (!_nameAvailable(s, parentId, name, ""))
            return _fail("A bin item with that name already exists");
        s.items.push({
                "id": _newId(s, true),
                "parentId": parentId,
                "kind": "bin",
                "name": name,
                "sourceId": "",
                "duration": 0,
                "color": "",
                "tags": [],
                "description": "",
                "offline": false
            });
        return _ok(s);
    }

    function _rename(s, o) {
        var record = _record(o.id, s.items);
        var name = _normalizedName(o.name);
        if (!record || record.id === "root")
            return _fail("Unknown catalog item " + o.id);
        if (!_validName(name))
            return _fail("Name must be 1–128 printable characters");
        if (!_nameAvailable(s, record.parentId, name, record.id))
            return _fail("A catalog item with that name already exists");
        record.name = name;
        return _ok(s);
    }

    function _validateMoveTargets(s, ids, parentId) {
        if (!_validParent(s, parentId))
            return _fail("Destination must be an existing bin");
        var selected = {};
        for (var i = 0; i < ids.length; ++i)
            selected[ids[i]] = true;
        for (i = 0; i < ids.length; ++i) {
            var record = _record(ids[i], s.items);
            if (!record || record.id === "root")
                return _fail("Unknown catalog item " + ids[i]);
            if (record.kind === "bin" && (record.id === parentId || _isAncestor(record.id, parentId, s.items)))
                return _fail("Cannot move a bin into itself or its descendants");
        }
        var names = {};
        var existing = _childrenRaw(parentId, s.items);
        for (i = 0; i < existing.length; ++i)
            if (!selected[existing[i].id])
                names[existing[i].name.toLocaleLowerCase()] = true;
        for (i = 0; i < ids.length; ++i) {
            var key = _record(ids[i], s.items).name.toLocaleLowerCase();
            if (names[key])
                return _fail("A catalog item with that name already exists in destination");
            names[key] = true;
        }
        return {
            "ok": true
        };
    }

    function _move(s, o) {
        var ids = _normalizeIds(o.ids || [], s.items);
        if (!ids.length)
            return _fail("No catalog items selected");
        var parentId = o.parentId === undefined || o.parentId === null ? "root" : String(o.parentId);
        var valid = _validateMoveTargets(s, ids, parentId);
        if (!valid.ok)
            return valid;
        for (var i = 0; i < ids.length; ++i)
            _record(ids[i], s.items).parentId = parentId;
        return _ok(s);
    }

    function _copyTree(s, sourceId, parentId, map, topLevel) {
        var source = _record(sourceId, s.items);
        var copy = _cloneItem(source);
        copy.id = _newId(s, source.kind === "bin");
        copy.parentId = parentId;
        if (topLevel) {
            var base = source.name + " Copy";
            var candidate = base;
            var n = 2;
            while (!_nameAvailable(s, parentId, candidate, ""))
                candidate = base + " " + n++;
            copy.name = candidate;
        }
        s.items.push(copy);
        map[source.id] = copy.id;
        var children = _childrenRaw(source.id, s.items);
        // Children are read from the old parent before any copied child is
        // attached, so a duplicate never copies its own newly-created tree.
        for (var i = 0; i < children.length; ++i)
            _copyTree(s, children[i].id, copy.id, map, false);
        return copy.id;
    }

    function _duplicate(s, o) {
        var ids = _normalizeIds(o.ids || [], s.items);
        if (!ids.length)
            return _fail("No catalog items selected");
        var parentId = o.parentId === undefined || o.parentId === null ? "root" : String(o.parentId);
        if (!_validParent(s, parentId))
            return _fail("Destination must be an existing bin");
        var map = {};
        for (var i = 0; i < ids.length; ++i)
            _copyTree(s, ids[i], parentId, map, true);
        return _ok(s);
    }

    function _remove(s, o) {
        var ids = _normalizeIds(o.ids || [], s.items);
        if (!ids.length)
            return _fail("No catalog items selected");
        var keepContents = o.keepContents === true;
        var used = _usedSources();
        var removeSet = {};
        for (var i = 0; i < ids.length; ++i) {
            var record = _record(ids[i], s.items);
            if (!record)
                return _fail("Unknown catalog item " + ids[i]);
            if (!keepContents && _containsUsed(record.id, s, used))
                return _fail("Used media cannot be removed from the catalog");
            if (keepContents && record.kind !== "bin" && used[record.sourceId])
                return _fail("Used media cannot be removed from the catalog");
            removeSet[record.id] = true;
            if (!keepContents) {
                var descendants = _descendantsRaw(record.id, s.items);
                for (var j = 0; j < descendants.length; ++j)
                    removeSet[descendants[j].id] = true;
            }
        }
        var flattenParent = {};
        if (keepContents) {
            for (i = 0; i < ids.length; ++i) {
                record = _record(ids[i], s.items);
                if (record.kind !== "bin")
                    continue;
                var children = _descendantsRaw(record.id, s.items);
                for (j = 0; j < children.length; ++j)
                    flattenParent[children[j].id] = record.parentId;
            }
            // Keep-contents deletion is a true flatten: every descendant is
            // promoted to the deleted bin's parent, not merely its first child.
            for (i = 0; i < s.items.length; ++i)
                if (flattenParent[s.items[i].id])
                    s.items[i].parentId = flattenParent[s.items[i].id];
        }
        var retained = [];
        for (i = 0; i < s.items.length; ++i)
            if (!removeSet[s.items[i].id])
                retained.push(s.items[i]);
        s.items = retained;
        return _ok(s);
    }

    function _metadata(s, o) {
        var ids = _normalizeIds(o.ids || [], s.items);
        var changes = o.changes;
        if (!ids.length)
            return _fail("No catalog items selected");
        if (!changes || typeof changes !== "object")
            return _fail("Metadata changes are required");
        var keys = Object.keys(changes);
        for (var k = 0; k < keys.length; ++k)
            if (keys[k] !== "tags" && keys[k] !== "description" && keys[k] !== "color")
                return _fail("Unsupported metadata field " + keys[k]);
        if (changes.tags !== undefined && !_validTags(changes.tags))
            return _fail("Tags must be non-empty printable strings");
        if (changes.description !== undefined && (typeof changes.description !== "string" || changes.description.length > 4096))
            return _fail("Description must be at most 4096 characters");
        if (changes.color !== undefined && !_validColor(changes.color))
            return _fail("Color must be a hexadecimal color");
        for (var i = 0; i < ids.length; ++i) {
            var record = _record(ids[i], s.items);
            if (changes.tags !== undefined)
                record.tags = _cleanTags(changes.tags);
            if (changes.description !== undefined)
                record.description = changes.description;
            if (changes.color !== undefined)
                record.color = changes.color;
        }
        return _ok(s);
    }

    function _collect(s, o) {
        var ids = _normalizeIds(o.ids || [], s.items);
        if (!ids.length)
            return _fail("No catalog items selected");
        var parentId = o.parentId === undefined || o.parentId === null ? "root" : String(o.parentId);
        var name = _normalizedName(o.name);
        if (!_validParent(s, parentId))
            return _fail("Destination must be an existing bin");
        if (!_validName(name))
            return _fail("Bin name must be 1–128 printable characters");
        if (!_nameAvailable(s, parentId, name, ""))
            return _fail("A bin item with that name already exists");
        for (var i = 0; i < ids.length; ++i) {
            var record = _record(ids[i], s.items);
            if (record.id === parentId || (record.kind === "bin" && _isAncestor(record.id, parentId, s.items)))
                return _fail("Selection cannot contain its destination");
        }
        var binId = _newId(s, true);
        s.items.push({
                "id": binId,
                "parentId": parentId,
                "kind": "bin",
                "name": name,
                "sourceId": "",
                "duration": 0,
                "color": "",
                "tags": [],
                "description": "",
                "offline": false
            });
        for (i = 0; i < ids.length; ++i)
            _record(ids[i], s.items).parentId = binId;
        return _ok(s);
    }

    function _validateState(s) {
        var byId = {};
        var rootCount = 0;
        for (var i = 0; i < s.items.length; ++i) {
            var record = s.items[i];
            if (!record || typeof record.id !== "string" || !record.id.length || byId[record.id])
                return _fail("Catalog contains duplicate or invalid IDs");
            byId[record.id] = record;
            if (record.id === "root") {
                rootCount += 1;
                if (record.kind !== "bin" || record.parentId !== "")
                    return _fail("Catalog root is invalid");
            }
            if (record.kind !== "bin" && record.kind !== "video" && record.kind !== "audio" && record.kind !== "still")
                return _fail("Catalog item has an invalid kind");
            if (!_validName(record.name))
                return _fail("Catalog item has an invalid name");
            if (!Array.isArray(record.tags) || !_validColor(record.color || ""))
                return _fail("Catalog item metadata is invalid");
            if (record.kind === "bin" && record.sourceId)
                return _fail("Bins cannot reference media sources");
            if (record.kind !== "bin" && (!record.sourceId || !_source(record.sourceId)))
                return _fail("Catalog item references a missing media source");
        }
        if (rootCount !== 1)
            return _fail("Catalog root is missing");
        for (i = 0; i < s.items.length; ++i) {
            record = s.items[i];
            if (record.id === "root")
                continue;
            if (!byId[record.parentId] || byId[record.parentId].kind !== "bin")
                return _fail("Catalog item has a missing bin parent");
            var seen = {};
            var current = record;
            while (current.id !== "root") {
                if (seen[current.id])
                    return _fail("Catalog hierarchy contains a cycle");
                seen[current.id] = true;
                current = byId[current.parentId];
                if (!current)
                    return _fail("Catalog hierarchy is disconnected");
            }
        }
        for (i = 0; i < s.items.length; ++i) {
            var siblings = _childrenRaw(s.items[i].parentId, s.items);
            for (var j = i + 1; j < s.items.length; ++j)
                if (s.items[j].parentId === s.items[i].parentId && _sameName(s.items[i].name, s.items[j].name))
                    return _fail("Sibling catalog names must be unique");
        }
        return {
            "ok": true
        };
    }

    function _candidate(operation) {
        if (!operation || typeof operation.type !== "string")
            return _fail("Operation type is required");
        var s = _snapshot();
        var result;
        switch (operation.type) {
        case "createBin":
            result = _createBin(s, operation);
            break;
        case "rename":
            result = _rename(s, operation);
            break;
        case "move":
            result = _move(s, operation);
            break;
        case "duplicate":
            result = _duplicate(s, operation);
            break;
        case "remove":
            result = _remove(s, operation);
            break;
        case "metadata":
            result = _metadata(s, operation);
            break;
        case "collect":
            result = _collect(s, operation);
            break;
        default:
            return _fail("Unknown operation " + operation.type);
        }
        if (!result.ok)
            return result;
        var valid = _validateState(s);
        return valid.ok ? _ok(s) : valid;
    }

    function preview(operation) {
        var result = _candidate(operation);
        return {
            "ok": result.ok,
            "error": result.error || "",
            "items": _cloneItems(result.ok ? result.state.items : items)
        };
    }

    function apply(operation) {
        var result = _candidate(operation);
        if (!result.ok) {
            error = result.error;
            return false;
        }
        var before = _snapshot();
        if (JSON.stringify(before.items) === JSON.stringify(result.state.items)) {
            error = "";
            return true;
        }
        var undoNext = _undo.slice();
        undoNext.push(before);
        while (undoNext.length > 100)
            undoNext.shift();
        _undo = undoNext;
        _redo = [];
        _restore(result.state);
        return true;
    }

    function undo() {
        if (!_undo.length) {
            error = "Nothing to undo";
            return false;
        }
        var old = _undo[_undo.length - 1];
        var undoNext = _undo.slice(0, _undo.length - 1);
        var redoNext = _redo.slice();
        redoNext.push(_snapshot());
        while (redoNext.length > 100)
            redoNext.shift();
        _undo = undoNext;
        _redo = redoNext;
        _restore(old);
        return true;
    }

    function redo() {
        if (!_redo.length) {
            error = "Nothing to redo";
            return false;
        }
        var next = _redo[_redo.length - 1];
        var redoNext = _redo.slice(0, _redo.length - 1);
        var undoNext = _undo.slice();
        undoNext.push(_snapshot());
        while (undoNext.length > 100)
            undoNext.shift();
        _undo = undoNext;
        _redo = redoNext;
        _restore(next);
        return true;
    }

    function _seedFromTimeline() {
        if (_seeded || !timeline || !timeline.sources || !timeline.sources.length)
            return;
        var seeded = [{
                "id": "root",
                "parentId": "",
                "kind": "bin",
                "name": "Media",
                "sourceId": "",
                "duration": 0,
                "color": "",
                "tags": [],
                "description": "",
                "offline": false
            }, {
                "id": "bin-footage",
                "parentId": "root",
                "kind": "bin",
                "name": "Footage",
                "sourceId": "",
                "duration": 0,
                "color": "",
                "tags": [],
                "description": "",
                "offline": false
            }, {
                "id": "bin-video",
                "parentId": "bin-footage",
                "kind": "bin",
                "name": "Video",
                "sourceId": "",
                "duration": 0,
                "color": "",
                "tags": [],
                "description": "",
                "offline": false
            }, {
                "id": "bin-sound",
                "parentId": "root",
                "kind": "bin",
                "name": "Sound",
                "sourceId": "",
                "duration": 0,
                "color": "",
                "tags": [],
                "description": "",
                "offline": false
            }, {
                "id": "bin-audio",
                "parentId": "bin-sound",
                "kind": "bin",
                "name": "Audio",
                "sourceId": "",
                "duration": 0,
                "color": "",
                "tags": [],
                "description": "",
                "offline": false
            }, {
                "id": "bin-stills",
                "parentId": "root",
                "kind": "bin",
                "name": "Stills",
                "sourceId": "",
                "duration": 0,
                "color": "",
                "tags": [],
                "description": "",
                "offline": false
            }];
        for (var i = 0; i < timeline.sources.length; ++i) {
            var source = timeline.sources[i];
            if (!source || !source.id || (source.kind !== "video" && source.kind !== "audio" && source.kind !== "still"))
                continue;
            var parentId = source.kind === "video" ? "bin-video" : (source.kind === "audio" ? "bin-audio" : "bin-stills");
            seeded.push({
                    "id": "media-source-" + source.id,
                    "parentId": parentId,
                    "kind": source.kind,
                    "name": _normalizedName(source.name) || String(source.id),
                    "sourceId": String(source.id),
                    "duration": Number(source.duration) || 0,
                    "color": source.color || "",
                    "tags": _cloneTags(source.tags),
                    "description": source.description || "",
                    "offline": !!source.offline
                });
        }
        var candidate = {
            "items": seeded,
            "nextBinSeq": 1,
            "nextItemSeq": 1
        };
        var valid = _validateState(candidate);
        if (!valid.ok) {
            error = valid.error;
            return;
        }
        items = _cloneItems(seeded);
        _undo = [];
        _redo = [];
        revision = 0;
        error = "";
        _seeded = true;
    }

    function item(id) {
        var record = _record(id, items);
        return record ? _cloneItem(record) : null;
    }

    function children(parentId) {
        var id = parentId === undefined || parentId === null ? "root" : String(parentId);
        var records = _childrenRaw(id, items);
        return _cloneItems(records);
    }

    function descendants(id) {
        return _cloneItems(_descendantsRaw(String(id), items));
    }

    function path(id) {
        var record = _record(String(id), items);
        if (!record)
            return [];
        var out = [];
        var seen = {};
        while (record && !seen[record.id]) {
            seen[record.id] = true;
            out.unshift(record);
            if (record.id === "root")
                break;
            record = _record(record.parentId, items);
        }
        var cloned = [];
        for (var i = 0; i < out.length; ++i)
            cloned.push(_cloneItem(out[i]));
        return cloned;
    }

    function _matchesText(record, text) {
        if (!text)
            return true;
        var needle = String(text).toLocaleLowerCase();
        if (String(record.name).toLocaleLowerCase().indexOf(needle) >= 0 || String(record.sourceId).toLocaleLowerCase().indexOf(needle) >= 0 || String(record.description).toLocaleLowerCase().indexOf(needle) >= 0)
            return true;
        for (var i = 0; i < (record.tags || []).length; ++i)
            if (String(record.tags[i]).toLocaleLowerCase().indexOf(needle) >= 0)
                return true;
        return false;
    }

    function _matchesFilter(record, filter, used) {
        filter = filter || {};
        if (filter.kind !== undefined) {
            var kinds = Array.isArray(filter.kind) ? filter.kind : [filter.kind];
            var kindFound = false;
            for (var i = 0; i < kinds.length; ++i)
                if (record.kind === kinds[i])
                    kindFound = true;
            if (!kindFound)
                return false;
        }
        if (filter.offline !== undefined && record.kind !== "bin" && !!record.offline !== !!filter.offline)
            return false;
        if (filter.offline === true && record.kind === "bin")
            return false;
        if (filter.unused !== undefined) {
            var unused = !_isUsedRecord(record, used, {
                    "items": items
                });
            if (!!filter.unused !== unused)
                return false;
        }
        return true;
    }

    function query(parentId, text, recursive, filter) {
        var scope = parentId === undefined || parentId === null ? "root" : String(parentId);
        filter = filter || {};
        var project = scope === "project" || scope === "all" || scope === "*" || filter.scope === "project" || filter.scope === "all";
        var recurse = recursive === true || filter.recursive === true || project;
        var candidates;
        if (project) {
            candidates = [];
            for (var i = 0; i < items.length; ++i)
                if (items[i].id !== "root")
                    candidates.push(items[i]);
        } else if (recurse) {
            candidates = _descendantsRaw(scope, items);
        } else {
            candidates = _childrenRaw(scope, items);
        }
        var used = _usedSources();
        var out = [];
        for (i = 0; i < candidates.length; ++i)
            if (_matchesText(candidates[i], text) && _matchesFilter(candidates[i], filter, used))
                out.push(_cloneItem(candidates[i]));
        return out;
    }

    function sourceItem(sourceId) {
        var id = String(sourceId);
        for (var i = 0; i < items.length; ++i)
            if (id && items[i].kind !== "bin" && items[i].sourceId === id)
                return _cloneItem(items[i]);
        return null;
    }

    function itemsForSource(sourceId) {
        var id = String(sourceId);
        var out = [];
        for (var i = 0; i < items.length; ++i)
            if (items[i].sourceId === id)
                out.push(_cloneItem(items[i]));
        return out;
    }

    function isUsed(sourceId) {
        return !!_usedSources()[String(sourceId)];
    }

    function newBinFromSelection(ids, name, parentId) {
        return apply({
                "type": "collect",
                "ids": ids || [],
                "name": name,
                "parentId": parentId === undefined ? "root" : parentId
            });
    }
}
