// Throwaway viewer prototype entry point. No document, media runtime, or saved user settings.
#include "WorkspaceController.hpp"
#include <QDebug>
#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlComponent>
#include <QQmlContext>
#include <QQuickStyle>
#include <QQuickWindow>
#include <QTemporaryDir>

int main(int argc, char** argv) {
    QGuiApplication app(argc, argv);
    app.setApplicationName("Nemo Viewer Prototype");
    app.setOrganizationName("NemoPrototype");
    QQuickStyle::setStyle("Basic");
    QTemporaryDir scratch;
    if (!scratch.isValid())
        return 1;
    nemo::workspace::WorkspaceController workspace(scratch.filePath("workspace.json"));
    QQmlApplicationEngine engine;
    engine.rootContext()->setContextProperty("workspace", &workspace);
    QQmlComponent themeComponent(&engine, QUrl::fromLocalFile(QStringLiteral(PROTOTYPE_QML_DIR "/Theme.qml")));
    QObject* theme = themeComponent.create();
    if (!theme) {
        qWarning() << themeComponent.errors();
        return 1;
    }
    theme->setParent(&engine);
    engine.rootContext()->setContextProperty("theme", theme);
    QQmlComponent studioComponent(&engine, QUrl::fromLocalFile(QStringLiteral(PROTOTYPE_QML_DIR "/StudioModel.qml")));
    QObject* studio = studioComponent.create();
    if (!studio) {
        qWarning() << studioComponent.errors();
        return 1;
    }
    studio->setParent(&engine);
    engine.rootContext()->setContextProperty("studio", studio);
    engine.load(QUrl::fromLocalFile(QStringLiteral(PROTOTYPE_QML_DIR "/Main.qml")));
    if (engine.rootObjects().isEmpty())
        return 1;
    auto* window = qobject_cast<QQuickWindow*>(engine.rootObjects().front());
    QObject::connect(
        window, &QQuickWindow::frameSwapped, window, [] { qInfo("PROTOTYPE_READY — simulated viewer transport"); },
        Qt::SingleShotConnection);
    return app.exec();
}
