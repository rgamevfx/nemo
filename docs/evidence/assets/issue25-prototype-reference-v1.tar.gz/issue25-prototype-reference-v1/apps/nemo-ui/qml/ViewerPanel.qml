import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

// Compact viewer prototype: display controls stay in the panel header when
// space permits and move to a narrow fallback row below the image.
FocusScope {
    id: viewerPrototype

    objectName: "viewerPrototype"
    focus: true
    activeFocusOnTab: true
    clip: true

    property string panelId: ""
    property string panelGroup: "A"
    property string viewSource: "graph"
    property bool roleReady: false
    property bool syncingContext: false
    property var themeContext: typeof theme === "undefined" ? null : theme
    property var studioContext: typeof studio === "undefined" ? null : studio
    readonly property bool displayControlsInHeader: width >= 560
    readonly property int headerPreferredHeight: 32
    property int studioRevision: studioContext ? studioContext.revision : 0
    property int mediaRevision: studioContext ? studioContext.mediaRevision : 0

    function contextValue() {
        if (!studioContext)
            return {
                "sourceId": "",
                "frame": 1001,
                "inFrame": 1001,
                "outFrame": 1001
            };
        if (viewSource === "timeline" && studioContext.timelineContext)
            return studioContext.timelineContext(panelGroup);
        if (viewSource === "graph" && studioContext.graphTimeContext)
            return studioContext.graphTimeContext(panelGroup);
        if (viewSource === "media" && studioContext.mediaContext)
            return studioContext.mediaContext(panelGroup);
        return {
            "sourceId": "",
            "frame": 1001,
            "inFrame": 1001,
            "outFrame": 1001
        };
    }

    readonly property var currentMediaSource: sourceRecord(contextValue().sourceId)

    function sourceRecord(sourceId) {
        var sources = studioContext && studioContext.timeline ? studioContext.timeline.sources : [];
        for (var i = 0; i < sources.length; ++i)
            if (String(sources[i].id) === String(sourceId))
                return sources[i];
        return null;
    }

    readonly property int firstFrame: studioContext && studioContext.timeline ? Number(studioContext.timeline.startFrame) : 1001
    readonly property int lastFrame: {
        var revision = mediaRevision;
        if (viewSource === "media" && currentMediaSource)
            return firstFrame + Math.max(1, Number(currentMediaSource.duration) || 1) - 1;
        return Math.max(firstFrame, studioContext && studioContext.timeline ? Number(studioContext.timeline.sequenceEnd()) - 1 : firstFrame);
    }
    property int frame: contextValue().frame
    property int inFrame: contextValue().inFrame
    property int outFrame: contextValue().outFrame
    property bool playing: false
    property string selectedLayer: "rgb"
    property string channel: "RGBA"
    property int proxyScale: 1
    property real zoom: 1.0
    property string zoomMode: "Fit"

    readonly property string viewerTargetName: {
        var revision = mediaRevision;
        if (!studioContext)
            return "";
        if (viewSource === "graph")
            return studioContext.graphTargetName ? String(studioContext.graphTargetName(panelGroup) || "") : "";
        if (viewSource === "timeline")
            return studioContext.timeline ? "Timeline" : "";
        var context = contextValue(), targets = studioContext.availableMediaTargets ? studioContext.availableMediaTargets(panelGroup) : [];
        for (var i = 0; i < targets.length; ++i)
            if (String(targets[i].id) === String(context.sourceId))
                return String(targets[i].name || targets[i].id);
        return "";
    }

    function graphTargets() {
        return studioContext && studioContext.availableGraphTargets ? studioContext.availableGraphTargets(panelGroup) : [];
    }

    function mediaTargets() {
        return studioContext && studioContext.availableMediaTargets ? studioContext.availableMediaTargets(panelGroup) : [];
    }

    function mediaTargetName() {
        if (!studioContext)
            return "No source";
        var sourceId = studioContext.mediaContext(panelGroup).sourceId;
        var entry = studioContext.media.sourceItem(sourceId);
        return entry ? entry.name : "No source";
    }

    function setViewSource(role) {
        var next = String(role || "");
        if (["graph", "timeline", "media"].indexOf(next) < 0)
            return false;
        if (viewSource !== next) {
            playing = false;
            viewSource = next;
        }
        if (studioContext && panelId && studioContext.setViewerRole)
            studioContext.setViewerRole(panelId, next);
        return true;
    }

    function syncRole() {
        if (studioContext && panelId && studioContext.viewerRole)
            viewSource = studioContext.viewerRole(panelId);
        roleReady = true;
        syncContext();
    }

    function syncContext() {
        if (!studioContext)
            return;
        var context = contextValue();
        syncingContext = true;
        inFrame = Math.max(firstFrame, Math.min(lastFrame, Number(context.inFrame)));
        outFrame = Math.max(inFrame, Math.min(lastFrame, Number(context.outFrame)));
        frame = Math.max(firstFrame, Math.min(lastFrame, Number(context.frame)));
        syncingContext = false;
        syncFields();
        scene.requestPaint();
    }

    property Component displayControlsComponent: Component {
        Flow {
            id: displayControls
            objectName: "viewerDisplayControls"
            spacing: 4
            flow: Flow.LeftToRight
            StudioComboBox {
                objectName: "layerMenu"
                model: ["rgb", "depth"]
                currentIndex: viewerPrototype.selectedLayer === "depth" ? 1 : 0
                height: 24
                onActivated: viewerPrototype.selectedLayer = currentText
                Accessible.name: "Image layer"
            }
            StudioComboBox {
                objectName: "channelMenu"
                model: ["RGBA", "R", "G", "B", "A"]
                currentIndex: model.indexOf(viewerPrototype.channel)
                height: 24
                onActivated: viewerPrototype.channel = currentText
                Accessible.name: "Display channels"
            }
            StudioComboBox {
                objectName: "zoomMenu"
                model: ["Fit", "100%", "50%"]
                currentIndex: model.indexOf(viewerPrototype.zoomMode)
                height: 24
                onActivated: viewerPrototype.setZoom(currentText)
                Accessible.name: "Viewer zoom"
            }
            StudioComboBox {
                objectName: "proxyMenu"
                model: ["Full", "Half", "Quarter"]
                currentIndex: viewerPrototype.proxyScale === 4 ? 2 : viewerPrototype.proxyScale === 2 ? 1 : 0
                height: 24
                onActivated: viewerPrototype.proxyScale = [1, 2, 4][currentIndex]
                Accessible.name: "Proxy resolution"
            }
        }
    }

    property Component headerTools: Component {
        Item {
            id: viewerHeaderTools
            implicitHeight: Math.max(24, headerDisplayControls.implicitHeight)
            implicitWidth: headerDisplayControls.implicitWidth + targetButton.implicitWidth + 4

            RowLayout {
                anchors.fill: parent
                spacing: 4

                Loader {
                    id: headerDisplayControls
                    Layout.fillWidth: true
                    sourceComponent: viewerPrototype.displayControlsInHeader ? viewerPrototype.displayControlsComponent : null
                }
                Button {
                    id: targetButton
                    objectName: "viewerTargetMenu_" + viewerPrototype.panelId
                    Layout.preferredWidth: Math.min(190, Math.max(80, targetMetrics.width + 24))
                    Layout.minimumWidth: 80
                    Layout.maximumWidth: 190
                    Layout.alignment: Qt.AlignVCenter
                    flat: true
                    padding: 4
                    implicitHeight: 24
                    text: viewerPrototype.viewerTargetName || (viewerPrototype.viewSource === "graph" ? "No node graph target" : viewerPrototype.viewSource === "media" ? "No media source" : "Timeline")
                    Accessible.name: "Viewer target"
                    onClicked: targetMenu.open()
                    contentItem: Row {
                        spacing: 3
                        Text {
                            text: targetButton.text
                            color: viewerPrototype.themeContext ? viewerPrototype.themeContext.text : "transparent"
                            font.pixelSize: viewerPrototype.themeContext ? viewerPrototype.themeContext.fontSize : 11
                            elide: Text.ElideRight
                            verticalAlignment: Text.AlignVCenter
                            width: Math.max(0, targetButton.width - 19)
                        }
                        Text {
                            text: "⌄"
                            color: viewerPrototype.themeContext ? viewerPrototype.themeContext.muted : "transparent"
                            font.pixelSize: 12
                            verticalAlignment: Text.AlignVCenter
                        }
                    }
                    background: Rectangle {
                        radius: viewerPrototype.themeContext ? viewerPrototype.themeContext.smallRadius : 4
                        color: targetButton.hovered ? (viewerPrototype.themeContext ? viewerPrototype.themeContext.hover : "transparent") : "transparent"
                    }
                    Menu {
                        id: targetMenu
                        objectName: "viewerTargetChoices_" + viewerPrototype.panelId
                        x: 0
                        y: targetButton.height
                        MenuItem {
                            objectName: "viewerRole_graph"
                            text: "Node Graph — " + (viewerPrototype.studioContext && viewerPrototype.studioContext.graphTargetName ? (viewerPrototype.studioContext.graphTargetName(viewerPrototype.panelGroup) || "Unavailable") : "Unavailable")
                            checkable: true
                            checked: viewerPrototype.viewSource === "graph"
                            onTriggered: viewerPrototype.setViewSource("graph")
                        }
                        MenuItem {
                            objectName: "viewerRole_timeline"
                            text: "Timeline — " + (viewerPrototype.studioContext && viewerPrototype.studioContext.timeline ? "Timeline" : "Unavailable")
                            checkable: true
                            checked: viewerPrototype.viewSource === "timeline"
                            onTriggered: viewerPrototype.setViewSource("timeline")
                        }
                        MenuItem {
                            objectName: "viewerRole_media"
                            text: "Media Bin — " + viewerPrototype.mediaTargetName()
                            checkable: true
                            checked: viewerPrototype.viewSource === "media"
                            onTriggered: viewerPrototype.setViewSource("media")
                        }
                    }
                }
            }
            TextMetrics {
                id: targetMetrics
                text: targetButton.text
                font: targetButton.font
            }
        }
    }

    function fixtureColorCorrection() {
        var exposure = 0;
        var saturation = 1;
        if (!studioContext || !studioContext.nodes)
            return {
                "exposure": exposure,
                "saturation": saturation
            };
        var nodes = studioContext.nodes;
        for (var nodeIndex = 0; nodeIndex < nodes.length; ++nodeIndex) {
            var node = nodes[nodeIndex];
            if (!node || !node.params)
                continue;
            for (var paramIndex = 0; paramIndex < node.params.length; ++paramIndex) {
                var param = node.params[paramIndex];
                if (!param || param.value === undefined)
                    continue;
                var key = String(param.key || "").toLowerCase();
                if (key === "exposure")
                    exposure = Number(param.value);
                else if (key === "saturation")
                    saturation = Number(param.value);
            }
        }
        return {
            "exposure": isFinite(exposure) ? exposure : 0,
            "saturation": isFinite(saturation) ? saturation : 1
        };
    }

    function correctedColor(red, green, blue, alpha) {
        var correction = fixtureColorCorrection();
        var gain = Math.pow(2, correction.exposure);
        red = Math.max(0, Math.min(1, red * gain));
        green = Math.max(0, Math.min(1, green * gain));
        blue = Math.max(0, Math.min(1, blue * gain));
        var luminance = red * 0.2126 + green * 0.7152 + blue * 0.0722;
        var saturation = correction.saturation;
        red = Math.max(0, Math.min(1, luminance + (red - luminance) * saturation));
        green = Math.max(0, Math.min(1, luminance + (green - luminance) * saturation));
        blue = Math.max(0, Math.min(1, luminance + (blue - luminance) * saturation));
        return {
            "red": red,
            "green": green,
            "blue": blue,
            "alpha": alpha
        };
    }

    function themeColor(role, fallback) {
        return themeContext && themeContext[role] !== undefined ? themeContext[role] : fallback;
    }

    readonly property int frameRate: 24
    readonly property real fixtureWidth: 760
    readonly property real fixtureHeight: 430

    function clampFrame(value) {
        return Math.max(firstFrame, Math.min(lastFrame, Math.round(value)));
    }

    function seek(value) {
        frame = clampFrame(value);
    }

    function markIn(value) {
        inFrame = Math.max(firstFrame, Math.min(outFrame, clampFrame(value)));
        if (frame < inFrame)
            frame = inFrame;
    }

    function markOut(value) {
        outFrame = Math.min(lastFrame, Math.max(inFrame, clampFrame(value)));
        if (frame > outFrame)
            frame = outFrame;
    }

    function step(delta) {
        frame = clampFrame(frame + delta);
    }

    function togglePlayback() {
        if (!playing && (frame < inFrame || frame > outFrame))
            frame = inFrame;
        playing = !playing;
    }

    function stopPlayback() {
        playing = false;
        frame = inFrame;
    }

    function timecodeForFrame(value) {
        var elapsed = Math.max(0, clampFrame(value) - firstFrame);
        var ff = elapsed % frameRate;
        var totalSeconds = Math.floor(elapsed / frameRate);
        var ss = totalSeconds % 60;
        var totalMinutes = Math.floor(totalSeconds / 60);
        var mm = totalMinutes % 60;
        var hh = Math.floor(totalMinutes / 60);
        function pad(number) {
            return number < 10 ? "0" + number : String(number);
        }
        return pad(hh) + ":" + pad(mm) + ":" + pad(ss) + ":" + pad(ff);
    }

    function frameForTimecode(value) {
        var parts = String(value).trim().split(":");
        if (parts.length !== 4)
            return frame;
        var hh = Number(parts[0]);
        var mm = Number(parts[1]);
        var ss = Number(parts[2]);
        var ff = Number(parts[3]);
        if (!isFinite(hh) || !isFinite(mm) || !isFinite(ss) || !isFinite(ff) || hh < 0 || mm < 0 || mm > 59 || ss < 0 || ss > 59 || ff < 0 || ff >= frameRate)
            return frame;
        return clampFrame(firstFrame + (((hh * 60 + mm) * 60 + ss) * frameRate) + ff);
    }

    function syncFields() {
        if (!timecodeField.activeFocus)
            timecodeField.text = timecodeForFrame(frame);
        if (!frameField.activeFocus)
            frameField.text = String(frame);
    }

    function commitTimecode() {
        frame = frameForTimecode(timecodeField.text);
        timecodeField.text = timecodeForFrame(frame);
        frameField.text = String(frame);
    }

    function commitFrame() {
        var value = Number(frameField.text);
        if (isFinite(value))
            frame = clampFrame(value);
        timecodeField.text = timecodeForFrame(frame);
        frameField.text = String(frame);
    }

    function fitToSurface() {
        if (sceneSurface.width <= 0 || sceneSurface.height <= 0)
            return;
        var horizontal = (sceneSurface.width - 12) / fixtureWidth;
        var vertical = (sceneSurface.height - 12) / fixtureHeight;
        zoom = Math.max(0.1, Math.min(horizontal, vertical));

    }
    function scheduleFit() {
        if (zoomMode === "Fit")
            fitTimer.restart();
    }

    function setZoom(mode) {
        zoomMode = mode;
        if (mode === "Fit")
            scheduleFit();
        else if (mode === "100%")
            zoom = 1.0;
        else
            zoom = 0.5;
    }

    function channelColor(red, green, blue, alpha) {
        var corrected = correctedColor(red, green, blue, alpha);
        red = corrected.red;
        green = corrected.green;
        blue = corrected.blue;
        alpha = corrected.alpha;
        if (selectedLayer === "depth") {
            var depth = Math.max(0, Math.min(1, green * 1.8));
            return Qt.rgba(depth, depth, depth, alpha);
        }
        if (channel === "R")
            return Qt.rgba(red, red, red, 1);
        if (channel === "G")
            return Qt.rgba(green, green, green, 1);
        if (channel === "B")
            return Qt.rgba(blue, blue, blue, 1);
        if (channel === "A")
            return Qt.rgba(alpha, alpha, alpha, 1);
        return Qt.rgba(red, green, blue, alpha);
    }

    onStudioRevisionChanged: scene.requestPaint()
    onMediaRevisionChanged: {
        syncContext();
        scene.requestPaint();
    }
    onPanelGroupChanged: syncContext()
    onPanelIdChanged: syncRole()
    onViewSourceChanged: {
        syncContext();
        scene.requestPaint();
    }

    function setTimeContext(changes) {
        if (!studioContext)
            return;
        if (viewSource === "media" && studioContext.setMediaContext)
            studioContext.setMediaContext(panelGroup, changes);
        else if (viewSource === "timeline" && studioContext.setTimelineContext)
            studioContext.setTimelineContext(panelGroup, changes);
        else if (viewSource === "graph" && studioContext.setGraphTimeContext)
            studioContext.setGraphTimeContext(panelGroup, changes);
    }

    onFrameChanged: {
        if (!syncingContext)
            setTimeContext({
                    "frame": frame
                });
        syncFields();
        scene.requestPaint();
    }
    onInFrameChanged: {
        if (!syncingContext)
            setTimeContext({
                    "inFrame": inFrame
                });
    }
    onOutFrameChanged: {
        if (!syncingContext)
            setTimeContext({
                    "outFrame": outFrame
                });
    }
    onChannelChanged: scene.requestPaint()
    onSelectedLayerChanged: scene.requestPaint()
    onProxyScaleChanged: scene.requestPaint()
    onWidthChanged: scheduleFit()
    onHeightChanged: scheduleFit()
    Connections {
        target: studioContext
        function onMediaContextChanged(group) {
            if (String(group) === String(viewerPrototype.panelGroup) && viewerPrototype.viewSource === "media")
                viewerPrototype.syncContext();
        }
        function onTimelineContextChanged(group) {
            if (String(group) === String(viewerPrototype.panelGroup) && viewerPrototype.viewSource === "timeline")
                viewerPrototype.syncContext();
        }
        function onGraphTimeContextChanged(group) {
            if (String(group) === String(viewerPrototype.panelGroup) && viewerPrototype.viewSource === "graph")
                viewerPrototype.syncContext();
        }
        function onViewerRoleChanged(id) {
            if (String(id) === String(viewerPrototype.panelId))
                viewerPrototype.syncRole();
        }
        function onGraphContextChanged(group) {
            if (String(group) === String(viewerPrototype.panelGroup))
                scene.requestPaint();
        }
    }
    Component.onCompleted: {
        syncRole();
        scheduleFit();
    }
    Timer {
        id: fitTimer
        interval: 32
        repeat: false
        onTriggered: if (viewerPrototype.zoomMode === "Fit")
            viewerPrototype.fitToSurface()
    }

    Timer {
        id: playbackTimer
        interval: Math.round(1000 / viewerPrototype.frameRate)
        repeat: true
        running: viewerPrototype.playing
        onTriggered: {
            if (viewerPrototype.frame >= viewerPrototype.outFrame)
                viewerPrototype.frame = viewerPrototype.inFrame;
            else
                viewerPrototype.frame++;
        }
    }

    ColumnLayout {
        anchors.fill: parent
        spacing: 0


        RowLayout {
            id: imageArea
            objectName: "viewerImageArea"
            Layout.fillWidth: true
            Layout.fillHeight: true
            spacing: 6
            Item {
                id: sceneSurface
                objectName: "viewerSurface"
                onWidthChanged: if (viewerPrototype.zoomMode === "Fit")
                    viewerPrototype.fitToSurface()
                onHeightChanged: if (viewerPrototype.zoomMode === "Fit")
                    viewerPrototype.fitToSurface()
                Layout.fillWidth: true
                Layout.fillHeight: true
                Layout.minimumWidth: 0
                clip: true
                focus: true

                Rectangle {
                    anchors.fill: parent
                    color: viewerPrototype.themeColor("imageSurround", "transparent")
                }

                Item {
                    id: sceneArt
                    width: viewerPrototype.fixtureWidth
                    height: viewerPrototype.fixtureHeight
                    anchors.centerIn: parent
                    scale: viewerPrototype.zoom
                    visible: viewerPrototype.viewSource === "timeline" || (viewerPrototype.viewSource === "graph" && viewerPrototype.viewerTargetName !== "")

                    Canvas {
                        id: scene
                        width: viewerPrototype.fixtureWidth / viewerPrototype.proxyScale
                        height: viewerPrototype.fixtureHeight / viewerPrototype.proxyScale
                        scale: viewerPrototype.proxyScale
                        transformOrigin: Item.TopLeft
                        smooth: true
                        antialiasing: true

                        onPaint: {
                            var ctx = getContext("2d");
                            ctx.reset();
                            ctx.scale(1 / viewerPrototype.proxyScale, 1 / viewerPrototype.proxyScale);
                            var width = viewerPrototype.fixtureWidth;
                            var height = viewerPrototype.fixtureHeight;
                            var color = viewerPrototype.channelColor;
                            var sky = ctx.createLinearGradient(0, 0, 0, height);
                            sky.addColorStop(0, color(0.19, 0.29, 0.38, 1));
                            sky.addColorStop(0.53, color(0.73, 0.66, 0.53, 1));
                            sky.addColorStop(1, color(0.17, 0.24, 0.28, 1));
                            ctx.fillStyle = sky;
                            ctx.fillRect(0, 0, width, height);
                            var phase = (viewerPrototype.frame - viewerPrototype.firstFrame) / 239;
                            var sunX = 530 + phase * 18;
                            var glow = ctx.createRadialGradient(sunX, 154, 1, sunX, 154, 130);
                            glow.addColorStop(0, color(0.95, 0.79, 0.53, 0.55));
                            glow.addColorStop(1, color(0.95, 0.79, 0.53, 0));
                            ctx.fillStyle = glow;
                            ctx.fillRect(sunX - 130, 24, 260, 260);
                            ctx.fillStyle = color(0.96, 0.86, 0.65, 1);
                            ctx.beginPath();
                            ctx.arc(sunX, 154, 15, 0, Math.PI * 2);
                            ctx.fill();
                            for (var ridge = 0; ridge < 4; ++ridge) {
                                var shade = 0.36 - ridge * 0.065;
                                ctx.fillStyle = color(shade * 0.8, shade, shade * 1.13, 1);
                                ctx.beginPath();
                                ctx.moveTo(0, height);
                                for (var x = 0; x <= width; x += 4) {
                                    var elevation = Math.sin(x * 0.009 + ridge * 1.7) * 42 + Math.sin(x * 0.023 + ridge) * 13 + Math.sin(x * 0.071) * 3;
                                    ctx.lineTo(x, 238 + ridge * 44 + elevation);
                                }
                                ctx.lineTo(width, height);
                                ctx.closePath();
                                ctx.fill();
                            }
                        }
                    }
                }
                Item {
                    id: mediaPlaceholder
                    objectName: "mediaPlaceholder"
                    visible: viewerPrototype.viewSource === "media" || (viewerPrototype.viewSource === "graph" && viewerPrototype.viewerTargetName === "")
                    width: 230
                    height: 86
                    anchors.centerIn: parent
                    Column {
                        anchors.centerIn: parent
                        spacing: 8
                        Rectangle {
                            anchors.horizontalCenter: parent.horizontalCenter
                            width: 44
                            height: 30
                            radius: 3
                            color: "transparent"
                            border.color: viewerPrototype.themeColor("muted", "transparent")
                            Text {
                                anchors.centerIn: parent
                                text: "?"
                                color: viewerPrototype.themeColor("muted", "transparent")
                                font.pixelSize: 16
                            }
                        }
                        Text {
                            anchors.horizontalCenter: parent.horizontalCenter
                            text: viewerPrototype.viewSource === "graph" ? "No node graph target" : viewerPrototype.currentMediaSource ? "Media preview unavailable" : "No source opened"
                            color: viewerPrototype.themeColor("muted", "transparent")
                            font.pixelSize: 12
                        }
                    }
                }

                MouseArea {
                    anchors.fill: parent
                    acceptedButtons: Qt.LeftButton
                    hoverEnabled: true
                    onClicked: sceneSurface.forceActiveFocus()
                    onWheel: function (wheel) {
                        viewerPrototype.setZoom(wheel.angleDelta.y > 0 ? "100%" : "50%");
                        wheel.accepted = true;
                    }
                }
            }
        }

        Loader {
            id: belowDisplayControls
            objectName: "belowDisplayControls"
            visible: !viewerPrototype.displayControlsInHeader
            Layout.fillWidth: true
            Layout.preferredHeight: visible && item ? item.implicitHeight + 8 : 0
            Layout.minimumHeight: 0
            sourceComponent: !viewerPrototype.displayControlsInHeader ? viewerPrototype.displayControlsComponent : null
        }
        FrameRuler {
            id: frameRuler
            compact: true
            Layout.fillWidth: true
            Layout.preferredHeight: 36
            frame: viewerPrototype.frame
            firstFrame: viewerPrototype.firstFrame
            lastFrame: viewerPrototype.lastFrame
            inFrame: viewerPrototype.inFrame
            outFrame: viewerPrototype.outFrame
            onSeek: function (value) {
                viewerPrototype.seek(value);
            }
            onMarkIn: function (value) {
                viewerPrototype.markIn(value);
            }
            onMarkOut: function (value) {
                viewerPrototype.markOut(value);
            }
        }

        Rectangle {
            id: transportBar
            objectName: "transportBar"
            Layout.fillWidth: true
            Layout.preferredHeight: compact ? 64 : 36
            readonly property bool compact: width < 530
            color: viewerPrototype.themeColor("panel", "transparent")
            clip: true

            Row {
                id: transportControls
                objectName: "transportControls"
                x: transportBar.compact ? (parent.width - width) / 2 : (parent.width - (65 + 8 + width + 8 + 119)) / 2 + 65 + 8
                y: 4
                spacing: 3
                TransportButton {
                    objectName: "inButton"
                    glyph: "markIn"
                    tooltipText: "Mark in at current frame"
                    onClicked: viewerPrototype.markIn(viewerPrototype.frame)
                }
                TransportButton {
                    objectName: "startButton"
                    glyph: "start"
                    tooltipText: "Go to in point"
                    onClicked: viewerPrototype.seek(viewerPrototype.inFrame)
                }
                TransportButton {
                    objectName: "previousButton"
                    glyph: "previous"
                    tooltipText: "Previous frame"
                    onClicked: viewerPrototype.step(-1)
                }
                TransportButton {
                    objectName: "playButton"
                    glyph: viewerPrototype.playing ? "pause" : "play"
                    active: viewerPrototype.playing
                    tooltipText: viewerPrototype.playing ? "Pause playback" : "Play playback"
                    onClicked: viewerPrototype.togglePlayback()
                }
                TransportButton {
                    objectName: "stopButton"
                    glyph: "stop"
                    tooltipText: "Stop and return to in point"
                    onClicked: viewerPrototype.stopPlayback()
                }
                TransportButton {
                    objectName: "nextButton"
                    glyph: "next"
                    tooltipText: "Next frame"
                    onClicked: viewerPrototype.step(1)
                }
                TransportButton {
                    objectName: "endButton"
                    glyph: "end"
                    tooltipText: "Go to out point"
                    onClicked: viewerPrototype.seek(viewerPrototype.outFrame)
                }
                TransportButton {
                    objectName: "outButton"
                    glyph: "markOut"
                    tooltipText: "Mark out at current frame"
                    onClicked: viewerPrototype.markOut(viewerPrototype.frame)
                }
            }
            TextField {
                id: timecodeField
                objectName: "timecodeField"
                x: transportBar.compact ? transportBar.width / 2 + 4 : transportControls.x + transportControls.width + 8
                y: transportBar.compact ? 34 : 4
                width: 119
                height: 28
                text: viewerPrototype.timecodeForFrame(viewerPrototype.frame)
                horizontalAlignment: Text.AlignHCenter
                font.family: "Monospace"
                font.pixelSize: 11
                palette.text: viewerPrototype.themeColor("text", "transparent")
                selectByMouse: true
                Accessible.name: "Timecode"
                background: Rectangle {
                    color: viewerPrototype.themeColor("field", "transparent")
                    radius: viewerPrototype.themeContext ? viewerPrototype.themeContext.smallRadius : 4
                    border.color: timecodeField.activeFocus ? viewerPrototype.themeColor("accent", "transparent") : viewerPrototype.themeColor("border", "transparent")
                }
                onAccepted: viewerPrototype.commitTimecode()
                onEditingFinished: viewerPrototype.commitTimecode()
            }
            TextField {
                id: frameField
                objectName: "frameField"
                x: transportBar.compact ? transportBar.width / 2 - width - 4 : transportControls.x - width - 8
                y: transportBar.compact ? 34 : 4
                width: 65
                height: 28
                text: String(viewerPrototype.frame)
                horizontalAlignment: Text.AlignHCenter
                font.family: "Monospace"
                font.pixelSize: 11
                palette.text: viewerPrototype.themeColor("text", "transparent")
                selectByMouse: true
                Accessible.name: "Frame"
                background: Rectangle {
                    color: viewerPrototype.themeColor("field", "transparent")
                    radius: viewerPrototype.themeContext ? viewerPrototype.themeContext.smallRadius : 4
                    border.color: frameField.activeFocus ? viewerPrototype.themeColor("accent", "transparent") : viewerPrototype.themeColor("border", "transparent")
                }
                validator: IntValidator {
                    bottom: viewerPrototype.firstFrame
                    top: viewerPrototype.lastFrame
                }
                onAccepted: viewerPrototype.commitFrame()
                onEditingFinished: viewerPrototype.commitFrame()
            }
        }
    }

    Keys.onPressed: function (event) {
        if (timecodeField.activeFocus || frameField.activeFocus)
            return;
        if (event.key === Qt.Key_Space) {
            togglePlayback();
            event.accepted = true;
        } else if (event.key === Qt.Key_Left) {
            step(-1);
            event.accepted = true;
        } else if (event.key === Qt.Key_Right) {
            step(1);
            event.accepted = true;
        } else if (event.key === Qt.Key_I) {
            markIn(frame);
            event.accepted = true;
        } else if (event.key === Qt.Key_O) {
            markOut(frame);
            event.accepted = true;
        } else if (event.key === Qt.Key_Home) {
            seek(inFrame);
            event.accepted = true;
        } else if (event.key === Qt.Key_End) {
            seek(outFrame);
            event.accepted = true;
        }
    }
}
