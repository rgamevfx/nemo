import QtQuick

QtObject {
    property string preset: "Graphite"
    property string accentOverride: ""
    readonly property bool light: preset === "Paper"
    readonly property bool cool: preset === "Slate"
    readonly property color background: light ? "#e8eaed" : cool ? "#171d27" : "#181a1d"
    readonly property color panel: light ? "#f8f9fa" : cool ? "#202837" : "#1e2023"
    readonly property color header: light ? "#f0f2f4" : cool ? "#242d3c" : "#212428"
    readonly property color raised: light ? "#ffffff" : cool ? "#2b3547" : "#282c31"
    readonly property color hover: light ? "#dce2e9" : cool ? "#364258" : "#343940"
    readonly property color border: light ? "#ccd1d7" : cool ? "#354052" : "#30343a"
    readonly property color text: light ? "#252a32" : "#dce0e6"
    readonly property color muted: light ? "#616b78" : "#979ea8"
    readonly property color disabled: light ? "#929aa5" : "#5f6670"
    readonly property color accent: accentOverride.length ? accentOverride : "#3485f6"
    readonly property color field: light ? "#e9edf1" : cool ? "#1c2432" : "#24272c"
    readonly property color imageSurround: "#17191b"
    readonly property color node: light ? "#e1e6ee" : "#2a2e33"
    readonly property color nodeSelected: light ? "#c7dbf7" : "#293e57"
    readonly property int radius: 7
    readonly property int smallRadius: 4
    readonly property int fontSize: 11
    readonly property var defaultNodeCategoryColors: ({
            "Merge": "#60656b",
            "Filter": "#a96832",
            "IO": "#386b91",
            "Color": "#71608c",
            "Distort": "#54816b",
            "Utility": "#59646f"
        })
    property var nodeCategoryColors: defaultNodeCategoryColors

    function nodeCategoryColor(category) {
        var key = String(category || ""), colors = nodeCategoryColors || {};
        return colors[key] || colors.Utility || defaultNodeCategoryColors.Utility;
    }

    function _relativeLuminance(channel) {
        var value = channel / 255;
        return value <= 0.03928 ? value / 12.92 : Math.pow((value + 0.055) / 1.055, 2.4);
    }

    function nodeCategoryTextColor(category) {
        var fill = String(nodeCategoryColor(category)), red = parseInt(fill.slice(1, 3), 16);
        var green = parseInt(fill.slice(3, 5), 16), blue = parseInt(fill.slice(5, 7), 16);
        if (!isFinite(red) || !isFinite(green) || !isFinite(blue))
            return "#ffffff";
        var luminance = 0.2126 * _relativeLuminance(red) + 0.7152 * _relativeLuminance(green) + 0.0722 * _relativeLuminance(blue);
        var darkLuminance = 0.2126 * _relativeLuminance(0x17) + 0.7152 * _relativeLuminance(0x1a) + 0.0722 * _relativeLuminance(0x1f);
        var whiteContrast = 1.05 / (luminance + 0.05);
        var darkContrast = (Math.max(luminance, darkLuminance) + 0.05) / (Math.min(luminance, darkLuminance) + 0.05);
        return whiteContrast >= darkContrast ? "#ffffff" : "#171a1f";
    }

    function setNodeCategoryColor(category, value) {
        var key = String(category || ""), next = String(value || "");
        if (!defaultNodeCategoryColors[key] || !/^#[0-9a-fA-F]{6}$/.test(next))
            return false;
        var colors = {};
        for (var existing in nodeCategoryColors)
            colors[existing] = nodeCategoryColors[existing];
        colors[key] = next;
        nodeCategoryColors = colors;
        return true;
    }

    function resetNodeCategoryColors() {
        nodeCategoryColors = defaultNodeCategoryColors;
    }
}
