import QtQuick
import QtQuick.Controls

// Small, icon-led timeline controls. The panel owns all editing behavior; this
// header only forwards user intent through the editor facade.
Item {
    id: root
    required property var editor
    implicitHeight: 24
    implicitWidth: toolsRow.implicitWidth

    function refocusEditor() {
        if (editor && editor.forceActiveFocus)
            Qt.callLater(function () {
                    editor.forceActiveFocus();
                });
    }

    function setSnap(value) {
        if (!editor)
            return;
        if (editor.setSnapping)
            editor.setSnapping(value);
        else
            editor.snapping = value;
        refocusEditor();
    }

    function setLinked(value) {
        if (!editor)
            return;
        if (editor.setLinkedSelection)
            editor.setLinkedSelection(value);
        else
            editor.linkedSelection = value;
        refocusEditor();
    }

    component GlyphButton: Button {
        id: control
        property string glyph: ""
        property bool activeMode: false
        implicitWidth: 24
        implicitHeight: 24
        width: 24
        height: 24
        padding: 0
        flat: true
        background: Rectangle {
            radius: theme.smallRadius
            color: control.activeMode ? Qt.rgba(theme.accent.r, theme.accent.g, theme.accent.b, 0.15) : control.hovered ? theme.hover : "transparent"
            border.width: control.activeFocus ? 1 : 0
            border.color: theme.accent
            opacity: control.enabled ? 1 : 0.55
        }
        contentItem: Canvas {
            id: glyphCanvas
            anchors.fill: parent
            anchors.margins: 5
            antialiasing: true
            onPaint: {
                var ctx = getContext("2d");
                ctx.reset();
                var foreground = !control.enabled ? theme.disabled : control.activeMode ? theme.accent : control.hovered ? theme.text : theme.muted;
                ctx.strokeStyle = foreground;
                ctx.fillStyle = foreground;
                ctx.lineWidth = 1.25;
                ctx.lineCap = "round";
                ctx.lineJoin = "round";
                var w = width;
                var h = height;
                var cx = w * 0.5;
                var cy = h * 0.5;
                if (control.glyph === "select") {
                    ctx.beginPath();
                    ctx.moveTo(w * .25, h * .14);
                    ctx.lineTo(w * .72, h * .55);
                    ctx.lineTo(w * .51, h * .58);
                    ctx.lineTo(w * .62, h * .87);
                    ctx.lineTo(w * .51, h * .91);
                    ctx.lineTo(w * .39, h * .61);
                    ctx.lineTo(w * .25, h * .75);
                    ctx.closePath();
                    ctx.fill();
                } else if (control.glyph === "ripple") {
                    ctx.beginPath();
                    ctx.moveTo(w * .18, h * .32);
                    ctx.lineTo(w * .82, h * .32);
                    ctx.moveTo(w * .18, h * .68);
                    ctx.lineTo(w * .82, h * .68);
                    ctx.moveTo(w * .18, h * .32);
                    ctx.lineTo(w * .28, h * .22);
                    ctx.moveTo(w * .18, h * .32);
                    ctx.lineTo(w * .28, h * .42);
                    ctx.moveTo(w * .82, h * .68);
                    ctx.lineTo(w * .72, h * .58);
                    ctx.moveTo(w * .82, h * .68);
                    ctx.lineTo(w * .72, h * .78);
                    ctx.stroke();
                } else if (control.glyph === "roll") {
                    ctx.strokeRect(w * .12, h * .30, w * .30, h * .40);
                    ctx.strokeRect(w * .58, h * .30, w * .30, h * .40);
                    ctx.beginPath();
                    ctx.moveTo(w * .42, cy);
                    ctx.lineTo(w * .58, cy);
                    ctx.stroke();
                    ctx.beginPath();
                    ctx.moveTo(w * .48, h * .42);
                    ctx.lineTo(w * .42, cy);
                    ctx.lineTo(w * .48, h * .58);
                    ctx.moveTo(w * .52, h * .42);
                    ctx.lineTo(w * .58, cy);
                    ctx.lineTo(w * .52, h * .58);
                    ctx.stroke();
                } else if (control.glyph === "slip") {
                    ctx.strokeRect(w * .25, h * .27, w * .50, h * .46);
                    ctx.beginPath();
                    ctx.moveTo(w * .10, cy);
                    ctx.lineTo(w * .36, cy);
                    ctx.moveTo(w * .10, cy);
                    ctx.lineTo(w * .20, h * .40);
                    ctx.moveTo(w * .10, cy);
                    ctx.lineTo(w * .20, h * .60);
                    ctx.moveTo(w * .90, cy);
                    ctx.lineTo(w * .64, cy);
                    ctx.moveTo(w * .90, cy);
                    ctx.lineTo(w * .80, h * .40);
                    ctx.moveTo(w * .90, cy);
                    ctx.lineTo(w * .80, h * .60);
                    ctx.stroke();
                } else if (control.glyph === "slide") {
                    ctx.beginPath();
                    ctx.moveTo(w * .18, cy);
                    ctx.lineTo(w * .82, cy);
                    ctx.moveTo(w * .18, cy);
                    ctx.lineTo(w * .30, h * .38);
                    ctx.moveTo(w * .18, cy);
                    ctx.lineTo(w * .30, h * .62);
                    ctx.moveTo(w * .82, cy);
                    ctx.lineTo(w * .70, h * .38);
                    ctx.moveTo(w * .82, cy);
                    ctx.lineTo(w * .70, h * .62);
                    ctx.stroke();
                    ctx.strokeRect(w * .40, h * .32, w * .20, h * .36);
                } else if (control.glyph === "blade") {
                    ctx.beginPath();
                    ctx.moveTo(w * .24, h * .78);
                    ctx.lineTo(w * .72, h * .22);
                    ctx.stroke();
                    ctx.beginPath();
                    ctx.arc(w * .28, h * .75, w * .14, 0, Math.PI * 2);
                    ctx.stroke();
                    ctx.beginPath();
                    ctx.moveTo(w * .57, h * .37);
                    ctx.lineTo(w * .77, h * .57);
                    ctx.stroke();
                } else if (control.glyph === "snap") {
                    ctx.beginPath();
                    ctx.moveTo(w * .18, cy);
                    ctx.lineTo(w * .82, cy);
                    ctx.moveTo(cx, h * .18);
                    ctx.lineTo(cx, h * .82);
                    ctx.stroke();
                    ctx.beginPath();
                    ctx.arc(cx, cy, w * .18, 0, Math.PI * 2);
                    ctx.stroke();
                } else if (control.glyph === "link") {
                    ctx.strokeRect(w * .12, h * .42, w * .42, h * .27);
                    ctx.strokeRect(w * .46, h * .31, w * .42, h * .27);
                    ctx.beginPath();
                    ctx.moveTo(w * .38, h * .55);
                    ctx.lineTo(w * .62, h * .45);
                    ctx.stroke();
                } else if (control.glyph === "frame") {
                    ctx.beginPath();
                    ctx.moveTo(w * .18, h * .35);
                    ctx.lineTo(w * .18, h * .18);
                    ctx.lineTo(w * .35, h * .18);
                    ctx.moveTo(w * .65, h * .18);
                    ctx.lineTo(w * .82, h * .18);
                    ctx.lineTo(w * .82, h * .35);
                    ctx.moveTo(w * .18, h * .65);
                    ctx.lineTo(w * .18, h * .82);
                    ctx.lineTo(w * .35, h * .82);
                    ctx.moveTo(w * .65, h * .82);
                    ctx.lineTo(w * .82, h * .82);
                    ctx.lineTo(w * .82, h * .65);
                    ctx.stroke();
                    ctx.beginPath();
                    ctx.arc(cx, cy, 1.35, 0, Math.PI * 2);
                    ctx.fill();
                } else if (control.glyph === "media") {
                    ctx.strokeRect(w * .14, h * .21, w * .72, h * .58);
                    ctx.beginPath();
                    ctx.moveTo(w * .25, h * .35);
                    ctx.lineTo(w * .75, h * .35);
                    ctx.moveTo(w * .25, h * .52);
                    ctx.lineTo(w * .62, h * .52);
                    ctx.moveTo(w * .25, h * .67);
                    ctx.lineTo(w * .50, h * .67);
                    ctx.stroke();
                } else if (control.glyph === "menu") {
                    ctx.beginPath();
                    ctx.arc(cx - 4.1, cy, 1.2, 0, Math.PI * 2);
                    ctx.arc(cx, cy, 1.2, 0, Math.PI * 2);
                    ctx.arc(cx + 4.1, cy, 1.2, 0, Math.PI * 2);
                    ctx.fill();
                }
            }
            onWidthChanged: requestPaint()
            onHeightChanged: requestPaint()
            Component.onCompleted: requestPaint()
        }
        Connections {
            target: theme
            function onTextChanged() {
                glyphCanvas.requestPaint();
            }
            function onMutedChanged() {
                glyphCanvas.requestPaint();
            }
            function onDisabledChanged() {
                glyphCanvas.requestPaint();
            }
            function onAccentChanged() {
                glyphCanvas.requestPaint();
            }
            function onHoverChanged() {
                glyphCanvas.requestPaint();
            }
            function onSmallRadiusChanged() {
                glyphCanvas.requestPaint();
            }
        }
        onGlyphChanged: glyphCanvas.requestPaint()
        onActiveModeChanged: glyphCanvas.requestPaint()
        onHoveredChanged: glyphCanvas.requestPaint()
        onEnabledChanged: glyphCanvas.requestPaint()
        ToolTip.visible: hovered
        ToolTip.delay: 450
        ToolTip.text: ""
    }

    Row {
        id: toolsRow
        anchors.fill: parent
        spacing: 2
        GlyphButton {
            id: toolButton
            objectName: "timelineToolButton"
            glyph: root.editor && root.editor.tool ? root.editor.tool : "select"
            ToolTip.text: "Editing tool: Select, Ripple, Roll, Slip, Slide, or Blade"
            Accessible.name: "Editing tool menu"
            onClicked: {
                toolMenu.x = toolButton.x;
                toolMenu.y = root.height;
                toolMenu.open();
            }
        }
        GlyphButton {
            id: snapButton
            objectName: "timelineSnapButton"
            glyph: "snap"
            activeMode: checked
            checkable: true
            checked: root.editor ? !!root.editor.snapping : false
            ToolTip.text: "Toggle timeline snapping"
            Accessible.name: "Toggle timeline snapping"
            onToggled: root.setSnap(checked)
        }
        GlyphButton {
            id: linkButton
            objectName: "timelineLinkButton"
            glyph: "link"
            activeMode: checked
            checkable: true
            checked: root.editor ? !!root.editor.linkedSelection : true
            ToolTip.text: "Toggle linked selection"
            Accessible.name: "Toggle linked selection"
            onToggled: root.setLinked(checked)
        }
        GlyphButton {
            id: frameButton
            objectName: "timelineFrameButton"
            glyph: "frame"
            ToolTip.text: "Frame all; Shift-click to frame selected"
            Accessible.name: "Frame all. Shift-click to frame selected"
            onClicked: {
                if (root.editor)
                    root.editor.frameAll();
                root.refocusEditor();
            }
            MouseArea {
                id: frameModifierArea
                anchors.fill: parent
                z: 2
                hoverEnabled: true
                acceptedButtons: Qt.LeftButton
                property bool shiftClick: false
                onPressed: function (mouse) {
                    shiftClick = !!(mouse.modifiers & Qt.ShiftModifier);
                    mouse.accepted = shiftClick;
                }
                onClicked: function (mouse) {
                    if (shiftClick) {
                        if (root.editor)
                            root.editor.frameSelected();
                        root.refocusEditor();
                        mouse.accepted = true;
                    } else {
                        mouse.accepted = false;
                    }
                    shiftClick = false;
                }
                onCanceled: shiftClick = false
            }
        }
        GlyphButton {
            id: mediaButton
            objectName: "timelineMediaButton"
            glyph: "media"
            ToolTip.text: "Open media bin"
            Accessible.name: "Open media bin"
            onClicked: {
                if (root.editor && root.editor.requestMediaPanel)
                    root.editor.requestMediaPanel();
                else if (root.editor && root.editor.openMedia)
                    root.editor.openMedia(mediaButton);
            }
        }
        GlyphButton {
            id: menuButton
            objectName: "timelineMenuButton"
            glyph: "menu"
            ToolTip.text: "Timeline editor menu"
            Accessible.name: "Timeline editor menu"
            onClicked: {
                if (root.editor && root.editor.openEditorMenu)
                    root.editor.openEditorMenu(menuButton);
            }
        }
    }

    Menu {
        id: toolMenu
        objectName: "timelineToolMenu"
        title: "Editing tool"
        MenuItem {
            text: "Select                         V"
            checkable: true
            checked: root.editor && root.editor.tool === "select"
            onTriggered: if (root.editor)
                root.editor.setTool("select")
        }
        MenuItem {
            text: "Ripple                         R"
            checkable: true
            checked: root.editor && root.editor.tool === "ripple"
            onTriggered: if (root.editor)
                root.editor.setTool("ripple")
        }
        MenuItem {
            text: "Roll                           T"
            checkable: true
            checked: root.editor && root.editor.tool === "roll"
            onTriggered: if (root.editor)
                root.editor.setTool("roll")
        }
        MenuItem {
            text: "Slip                           Y"
            checkable: true
            checked: root.editor && root.editor.tool === "slip"
            onTriggered: if (root.editor)
                root.editor.setTool("slip")
        }
        MenuItem {
            text: "Slide                          U"
            checkable: true
            checked: root.editor && root.editor.tool === "slide"
            onTriggered: if (root.editor)
                root.editor.setTool("slide")
        }
        MenuItem {
            text: "Blade                          B"
            checkable: true
            checked: root.editor && root.editor.tool === "blade"
            onTriggered: if (root.editor)
                root.editor.setTool("blade")
        }
        onClosed: root.refocusEditor()
    }
}
