import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

FocusScope {
    id: parametersPrototype

    objectName: "parametersPrototype"
    property string panelId: ""
    property var inspectors: []
    readonly property var openInspectors: inspectors
    property int inspectorLimit: 3
    property bool twoColumns: true
    property string restoredForPanelId: ""

    function validNode(id) {
        return id !== undefined && id !== null && String(id).length > 0;
    }

    function nodeCategoryId(node) {
        return studio && studio.nodeCategory ? studio.nodeCategory(node && node.type !== undefined ? String(node.type) : "") : "Utility";
    }

    function nodeCategoryColor(node) {
        return theme.nodeCategoryColor(nodeCategoryId(node));
    }

    function fixtureExists(id) {
        return validNode(id) && studio && studio.node(String(id)) !== null;
    }

    function normalizedEntry(entry) {
        return {
            "id": String(entry.id),
            "pinned": entry.pinned === true,
            "collapsed": entry.collapsed === true
        };
    }

    function defaultInspectors() {
        var initial = [];
        if (fixtureExists("merge1"))
            initial.push({
                    "id": "merge1",
                    "pinned": false,
                    "collapsed": false
                });
        if (fixtureExists("color1"))
            initial.push({
                    "id": "color1",
                    "pinned": false,
                    "collapsed": false
                });
        return initial;
    }

    function restoreState() {
        if (!panelId || restoredForPanelId === panelId || !studio)
            return;
        restoredForPanelId = panelId;
        var saved = studio.loadPanelState(panelId);
        var loaded = [];
        if (saved && saved.inspectors && saved.inspectors.length !== undefined) {
            for (var i = 0; i < saved.inspectors.length; ++i) {
                var entry = saved.inspectors[i];
                if (!entry || !fixtureExists(entry.id))
                    continue;
                var normalized = normalizedEntry(entry);
                var duplicate = false;
                for (var j = 0; j < loaded.length; ++j) {
                    if (loaded[j].id === normalized.id) {
                        duplicate = true;
                        break;
                    }
                }
                if (!duplicate)
                    loaded.push(normalized);
            }
        }
        inspectors = saved && saved.inspectors ? loaded : defaultInspectors();
        if (saved && Number.isFinite(Number(saved.limit)))
            inspectorLimit = Math.max(1, Math.min(20, Math.round(Number(saved.limit))));
        if (saved && typeof saved.columns === "boolean")
            twoColumns = saved.columns;
        enforceLimit("");
    }

    function stateEntries() {
        var result = [];
        for (var i = 0; i < inspectors.length; ++i) {
            var entry = inspectors[i];
            result.push({
                    "id": String(entry.id),
                    "pinned": entry.pinned === true,
                    "collapsed": entry.collapsed === true
                });
        }
        return result;
    }

    function saveState(destination) {
        var key = destination || panelId;
        if (!studio || !key)
            return;
        studio.savePanelState(key, {
                "inspectors": stateEntries(),
                "limit": inspectorLimit,
                "columns": twoColumns
            });
    }

    function removeAt(index) {
        if (index < 0 || index >= inspectors.length)
            return;
        var next = inspectors.slice();
        next.splice(index, 1);
        inspectors = next;
    }

    function oldestUnpinned(excludeId) {
        for (var i = inspectors.length - 1; i >= 0; --i) {
            if (inspectors[i].pinned !== true && String(inspectors[i].id) !== String(excludeId))
                return i;
        }
        return -1;
    }

    function enforceLimit(excludeId) {
        var unpinned = 0;
        for (var i = 0; i < inspectors.length; ++i)
            if (inspectors[i].pinned !== true)
                ++unpinned;
        while (unpinned > inspectorLimit) {
            var index = oldestUnpinned(excludeId);
            if (index < 0)
                break;
            removeAt(index);
            --unpinned;
        }
    }

    function openInspector(nodeId) {
        if (!fixtureExists(nodeId))
            return;
        var id = String(nodeId);
        for (var i = 0; i < inspectors.length; ++i) {
            if (String(inspectors[i].id) === id)
                return;
        }
        var next = inspectors.slice();
        next.unshift({
                "id": id,
                "pinned": false,
                "collapsed": false
            });
        inspectors = next;
        enforceLimit("");
        scrollToTop();
    }

    function columnEntries(columnIndex) {
        if (!twoColumns)
            return columnIndex === 0 ? inspectors : [];
        var result = [];
        for (var i = 0; i < inspectors.length; ++i) {
            if (i % 2 === columnIndex)
                result.push(inspectors[i]);
        }
        return result;
    }

    function scrollToTop() {
        Qt.callLater(function () {
                if (inspectorScroll.contentItem)
                    inspectorScroll.contentItem.contentY = 0;
            });
    }

    function closeInspector(nodeId) {
        for (var i = 0; i < inspectors.length; ++i) {
            if (String(inspectors[i].id) === String(nodeId)) {
                removeAt(i);
                return;
            }
        }
    }

    function closeAllInspectors() {
        inspectors = [];
    }

    function setPinned(nodeId, pinned) {
        var next = [];
        for (var i = 0; i < inspectors.length; ++i) {
            var current = inspectors[i];
            var copy = {
                "id": String(current.id),
                "pinned": current.pinned === true,
                "collapsed": current.collapsed === true
            };
            if (String(current.id) === String(nodeId))
                copy.pinned = pinned === true;
            next.push(copy);
        }
        inspectors = next;
        if (!pinned)
            enforceLimit(String(nodeId));
    }

    function setCollapsed(nodeId, collapsed) {
        var next = [];
        for (var i = 0; i < inspectors.length; ++i) {
            var current = inspectors[i];
            var copy = {
                "id": String(current.id),
                "pinned": current.pinned === true,
                "collapsed": current.collapsed === true
            };
            if (String(current.id) === String(nodeId))
                copy.collapsed = collapsed === true;
            next.push(copy);
        }
        inspectors = next;
    }

    function setLimit(value) {
        inspectorLimit = Math.max(1, Math.min(20, Math.round(Number(value))));
        enforceLimit("");
    }

    Component.onCompleted: restoreState()
    onPanelIdChanged: {
        if (restoredForPanelId && restoredForPanelId !== panelId)
            saveState(restoredForPanelId);
        restoreState();
    }
    Component.onDestruction: saveState()

    Connections {
        target: studio
        enabled: parametersPrototype.visible
        function onInspectorRequested(nodeId) {
            parametersPrototype.openInspector(nodeId);
        }
    }

    property alias headerTools: headerToolsComponent

    Component {
        id: headerToolsComponent
        Item {
            implicitWidth: toolsRow.implicitWidth
            implicitHeight: toolsRow.implicitHeight

            RowLayout {
                id: toolsRow
                anchors.fill: parent
                spacing: 4

                SpinBox {
                    id: limitBox
                    objectName: "accumulationLimit"
                    from: 1
                    to: 20
                    value: parametersPrototype.inspectorLimit
                    editable: true
                    implicitWidth: 48
                    implicitHeight: 23
                    font.pixelSize: theme.fontSize
                    leftPadding: 4
                    rightPadding: 4
                    up.indicator: Item {
                        width: 0
                        height: 0
                    }
                    down.indicator: Item {
                        width: 0
                        height: 0
                    }
                    Accessible.name: "Unpinned inspector limit"
                    onValueChanged: {
                        if (value !== parametersPrototype.inspectorLimit)
                            parametersPrototype.setLimit(value);
                    }
                    contentItem: TextInput {
                        text: limitBox.textFromValue(limitBox.value, limitBox.locale)
                        color: theme.text
                        font: limitBox.font
                        horizontalAlignment: Text.AlignHCenter
                        verticalAlignment: Text.AlignVCenter
                        selectByMouse: true
                        validator: IntValidator {
                            bottom: 1
                            top: 20
                        }
                        onEditingFinished: limitBox.value = limitBox.valueFromText(text, limitBox.locale)
                    }
                    background: Rectangle {
                        color: theme.field
                        border.color: limitBox.activeFocus ? theme.accent : theme.border
                        radius: theme.smallRadius
                    }
                }

                Button {
                    id: columnToggle
                    objectName: "columnToggle"
                    checkable: true
                    checked: parametersPrototype.twoColumns
                    implicitWidth: 28
                    implicitHeight: 24
                    padding: 0
                    Accessible.name: "Two inspector columns"
                    onToggled: parametersPrototype.twoColumns = checked
                    background: Rectangle {
                        radius: theme.smallRadius
                        color: columnToggle.hovered ? theme.hover : "transparent"
                    }
                    contentItem: Item {
                        Row {
                            anchors.centerIn: parent
                            spacing: 3
                            Repeater {
                                model: 2
                                Rectangle {
                                    width: 5
                                    height: 12
                                    radius: 1
                                    color: "transparent"
                                    border.color: columnToggle.checked ? theme.accent : theme.muted
                                }
                            }
                        }
                    }
                }

                Button {
                    id: closeAllButton
                    objectName: "closeAllInspectors"
                    flat: true
                    text: "Close all"
                    implicitWidth: 58
                    implicitHeight: 23
                    padding: 0
                    font.pixelSize: theme.fontSize
                    onClicked: parametersPrototype.closeAllInspectors()
                    contentItem: Text {
                        text: closeAllButton.text
                        color: closeAllButton.down ? theme.accent : theme.text
                        font: closeAllButton.font
                        horizontalAlignment: Text.AlignHCenter
                        verticalAlignment: Text.AlignVCenter
                    }
                    background: Rectangle {
                        color: closeAllButton.hovered ? theme.hover : theme.panel
                        radius: theme.smallRadius
                    }
                }

                Text {
                    visible: width > 0
                    text: String(parametersPrototype.inspectors.length) + " open"
                    color: theme.muted
                    font.pixelSize: theme.fontSize
                    horizontalAlignment: Text.AlignRight
                }
            }
        }
    }

    ScrollView {
        id: inspectorScroll
        anchors.fill: parent
        objectName: "inspectorScroll"
        anchors.margins: 7
        clip: true
        contentWidth: inspectorContent.width
        contentHeight: inspectorContent.height
        ScrollBar.horizontal.policy: ScrollBar.AsNeeded
        ScrollBar.vertical.policy: ScrollBar.AsNeeded

        Item {
            id: inspectorContent
            property real columnGap: 6
            property real minCardWidth: 260
            property real columnWidth: parametersPrototype.twoColumns ? Math.max(minCardWidth, (inspectorScroll.availableWidth - columnGap) / 2) : Math.max(minCardWidth, inspectorScroll.availableWidth)
            width: parametersPrototype.twoColumns ? columnWidth * 2 + columnGap : columnWidth
            height: Math.max(leftInspectorColumn.implicitHeight, rightInspectorColumn.implicitHeight)

            Column {
                id: leftInspectorColumn
                objectName: "inspectorColumn_0"
                width: inspectorContent.columnWidth
                spacing: inspectorContent.columnGap

                Repeater {
                    model: parametersPrototype.columnEntries(0)
                    delegate: inspectorCardComponent
                }
            }

            Column {
                id: rightInspectorColumn
                objectName: "inspectorColumn_1"
                visible: parametersPrototype.twoColumns
                x: leftInspectorColumn.width + inspectorContent.columnGap
                width: inspectorContent.columnWidth
                spacing: inspectorContent.columnGap

                Repeater {
                    model: parametersPrototype.columnEntries(1)
                    delegate: inspectorCardComponent
                }
            }
        }
    }

    Component {
        id: inspectorCardComponent
        Rectangle {
            id: card
            property var delegateData: modelData
            property string inspectorId: String(delegateData.id)
            property var inspectorState: delegateData
            readonly property var nodeData: studio.node(card.inspectorId)
            readonly property var sectionModel: {
                return card.sections();
            }
            width: parent ? parent.width : implicitWidth
            height: bodyColumn.implicitHeight + 2
            implicitWidth: 260
            implicitHeight: bodyColumn.implicitHeight + 2
            color: theme.panel
            border.color: theme.border
            border.width: 1
            radius: theme.radius
            objectName: "inspector_" + inspectorId

            function displayName() {
                return nodeData && nodeData.name ? String(nodeData.name) : inspectorId + " (unavailable)";
            }

            function displayType() {
                return nodeData && nodeData.type ? String(nodeData.type) : "Node";
            }

            function sections() {
                var groups = [];
                var byName = {};
                var params = nodeData && nodeData.params ? nodeData.params : [];
                for (var i = 0; i < params.length; ++i) {
                    var parameter = params[i];
                    var name = parameter.section ? String(parameter.section) : "Properties";
                    if (!byName[name]) {
                        byName[name] = {
                            "name": name,
                            "params": []
                        };
                        groups.push(byName[name]);
                    }
                    byName[name].params.push(parameter);
                }
                return groups;
            }

            ColumnLayout {
                id: bodyColumn
                anchors {
                    left: parent.left
                    right: parent.right
                    top: parent.top
                    leftMargin: 1
                    rightMargin: 1
                    topMargin: 1
                }
                spacing: 0

                RowLayout {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 30
                    spacing: 3

                    Rectangle {
                        Layout.preferredWidth: 7
                        Layout.preferredHeight: 7
                        radius: 3
                        color: parametersPrototype.nodeCategoryColor(nodeData)
                    }

                    Button {
                        id: collapseButton
                        flat: true
                        text: card.inspectorState.collapsed === true ? "▸" : "▾"
                        implicitWidth: 19
                        objectName: "collapse_" + card.inspectorId
                        padding: 0
                        onClicked: parametersPrototype.setCollapsed(card.inspectorId, card.inspectorState.collapsed !== true)
                        contentItem: Text {
                            text: collapseButton.text
                            color: theme.muted
                            font.pixelSize: theme.fontSize
                            horizontalAlignment: Text.AlignHCenter
                            verticalAlignment: Text.AlignVCenter
                        }
                    }

                    RowLayout {
                        Layout.fillWidth: true
                        spacing: 6
                        Text {
                            text: card.displayName()
                            color: theme.text
                            font.pixelSize: theme.fontSize
                            font.weight: Font.Medium
                            elide: Text.ElideRight
                            Layout.fillWidth: true
                        }
                        Text {
                            visible: card.width >= 330
                            text: card.displayType()
                            color: theme.muted
                            font.pixelSize: Math.max(9, theme.fontSize - 1)
                            elide: Text.ElideRight
                            Layout.maximumWidth: 84
                        }
                    }

                    Button {
                        id: pinButton
                        objectName: "pin_" + card.inspectorId
                        flat: true
                        implicitWidth: 22
                        implicitHeight: 23
                        padding: 0
                        Accessible.name: card.inspectorState.pinned ? "Unpin inspector" : "Pin inspector"
                        onClicked: parametersPrototype.setPinned(card.inspectorId, card.inspectorState.pinned !== true)
                        contentItem: Canvas {
                            id: pinGlyph
                            onPaint: {
                                var ctx = getContext("2d");
                                ctx.reset();
                                ctx.strokeStyle = card.inspectorState.pinned ? theme.accent : theme.muted;
                                ctx.fillStyle = ctx.strokeStyle;
                                ctx.lineWidth = 1;
                                var cx = width / 2, cy = height / 2;
                                ctx.beginPath();
                                ctx.moveTo(cx - 3, cy - 5);
                                ctx.lineTo(cx + 3, cy - 5);
                                ctx.lineTo(cx + 2, cy - 1);
                                ctx.lineTo(cx + 4, cy + 2);
                                ctx.lineTo(cx - 4, cy + 2);
                                ctx.lineTo(cx - 2, cy - 1);
                                ctx.closePath();
                                if (card.inspectorState.pinned)
                                    ctx.fill();
                                else
                                    ctx.stroke();
                                ctx.beginPath();
                                ctx.moveTo(cx, cy + 2);
                                ctx.lineTo(cx, cy + 6);
                                ctx.stroke();
                            }
                            Connections {
                                target: theme
                                function onAccentChanged() {
                                    pinGlyph.requestPaint();
                                }
                                function onMutedChanged() {
                                    pinGlyph.requestPaint();
                                }
                            }
                        }
                    }

                    Button {
                        id: closeButton
                        objectName: "close_" + card.inspectorId
                        flat: true
                        text: "×"
                        implicitWidth: 22
                        implicitHeight: 23
                        padding: 0
                        onClicked: parametersPrototype.closeInspector(card.inspectorId)
                        contentItem: Text {
                            text: closeButton.text
                            color: closeButton.down ? theme.accent : theme.muted
                            font.pixelSize: theme.fontSize + 1
                            horizontalAlignment: Text.AlignHCenter
                            verticalAlignment: Text.AlignVCenter
                        }
                    }
                }

                ColumnLayout {
                    visible: card.inspectorState.collapsed !== true
                    Layout.fillWidth: true
                    spacing: 4

                    Repeater {
                        model: card.sectionModel
                        delegate: sectionComponent
                    }
                }
            }
        }
    }

    Component {
        id: sectionComponent
        Rectangle {
            id: section
            property var sectionData: modelData
            property bool collapsed: false
            Layout.fillWidth: true
            implicitHeight: sectionColumn.implicitHeight
            color: theme.panel
            radius: theme.smallRadius

            ColumnLayout {
                id: sectionColumn
                anchors {
                    left: parent.left
                    right: parent.right
                    top: parent.top
                }
                spacing: 0

                Button {
                    id: sectionButton
                    Layout.fillWidth: true
                    Layout.preferredHeight: 24
                    flat: true
                    padding: 5
                    text: (section.collapsed ? "▸ " : "▾ ") + String(section.sectionData.name)
                    contentItem: Text {
                        text: sectionButton.text
                        color: theme.text
                        font.pixelSize: theme.fontSize
                        verticalAlignment: Text.AlignVCenter
                        elide: Text.ElideRight
                    }
                    onClicked: section.collapsed = !section.collapsed
                    background: Rectangle {
                        color: sectionButton.hovered ? theme.hover : theme.panel
                        radius: theme.smallRadius
                    }
                }

                ColumnLayout {
                    visible: !section.collapsed
                    Layout.fillWidth: true
                    Layout.leftMargin: 7
                    Layout.rightMargin: 7
                    Layout.bottomMargin: 5
                    spacing: 4

                    Repeater {
                        model: section.sectionData.params
                        delegate: parameterComponent
                    }
                }
            }
        }
    }

    Component {
        id: parameterComponent
        Item {
            id: parameterRow
            readonly property var parameter: {
                var revision = studio.revision;
                return studio.parameter(nodeId, String(modelData.key)) || modelData;
            }
            property int modelRevision: studio ? Number(studio.revision || 0) : 0
            property int animationModelRevision: studio ? Number(studio.animationRevision || 0) : 0
            property int animationFrame: studio ? Number(studio.frame || 0) : 0
            onAnimationFrameChanged: {
                numberField.pendingNumericEdit = false;
                var current = studio.parameter(nodeId, parameterKey);
                if (current && current.kind === "number")
                    numberField.text = parametersPrototype.formatParameter(current.value, current.step);
            }
            readonly property string nodeId: parametersPrototype.findInspectorId(parameterRow)
            readonly property string parameterKey: parameter && parameter.key !== undefined ? String(parameter.key) : ""
            readonly property string currentKeyStatus: {
                var frame = animationFrame;
                var revision = animationModelRevision;
                var model = modelRevision;
                if (!studio || !studio.keyStatus || !parameter)
                    return "none";
                return String(studio.keyStatus(nodeId, parameterKey));
            }
            implicitHeight: Math.max(label.implicitHeight, controlColumn.implicitHeight)
            Layout.fillWidth: true

            function currentKeyId() {
                if (!studio || !studio.animationChannels)
                    return "";
                var channelId = nodeId + "::" + parameterKey;
                var channels = studio.animationChannels;
                for (var i = 0; i < channels.length; ++i) {
                    var channel = channels[i];
                    if (!channel || String(channel.id) !== channelId || !channel.keys)
                        continue;
                    for (var j = 0; j < channel.keys.length; ++j) {
                        var key = channel.keys[j];
                        if (key && Math.abs(Number(key.time) - animationFrame) <= 1e-6)
                            return String(key.id);
                    }
                }
                return "";
            }

            function commitPendingNumericForKey() {
                if (!parameter || parameter.kind !== "number" || !numberField.activeFocus || !numberField.pendingNumericEdit || !numberField.acceptableInput)
                    return;
                var typed = String(numberField.text).trim();
                if (!typed.length || !Number.isFinite(Number(typed)))
                    return;
                parametersPrototype.commitNumeric(parameterRow, typed);
                numberField.pendingNumericEdit = false;
            }

            function keyAtCurrentFrame() {
                if (!studio || !parameter)
                    return false;
                commitPendingNumericForKey();
                return studio.keyParameter ? studio.keyParameter(nodeId, parameterKey) : false;
            }

            function removeCurrentKey() {
                var id = currentKeyId();
                return id.length > 0 && studio && studio.deleteAnimationKeys ? studio.deleteAnimationKeys([id]) : false;
            }

            RowLayout {
                anchors.fill: parent
                spacing: 6

                Text {
                    id: label
                    objectName: "label_" + parameterRow.nodeId + "_" + parameterRow.parameterKey
                    text: parameterRow.parameter.label ? String(parameterRow.parameter.label) : parameterRow.parameterKey
                    color: theme.text
                    font.pixelSize: theme.fontSize
                    elide: Text.ElideRight
                    Layout.preferredWidth: 78
                    Layout.minimumWidth: 48

                    MouseArea {
                        anchors.fill: parent
                        onPressed: function (mouse) {
                            mouse.accepted = !!(mouse.modifiers & Qt.AltModifier);
                        }
                        onClicked: parameterRow.keyAtCurrentFrame()
                    }
                    ToolTip.visible: labelHover.hovered
                    ToolTip.text: parameterRow.currentKeyStatus === "key" ? "Keyed at frame " + parameterRow.animationFrame : parameterRow.currentKeyStatus === "animated" ? "Animated; Alt-click to key at frame " + parameterRow.animationFrame : "Alt-click to add a key at frame " + parameterRow.animationFrame
                    HoverHandler {
                        id: labelHover
                    }
                }

                Rectangle {
                    id: keyIndicator
                    property string keyStatus: parameterRow.currentKeyStatus
                    objectName: "key_" + parameterRow.nodeId + "_" + parameterRow.parameterKey
                    Layout.preferredWidth: 24
                    Layout.preferredHeight: 22
                    radius: theme.smallRadius
                    color: keyIndicatorMouse.containsMouse ? theme.hover : "transparent"
                    border.width: 1
                    border.color: parameterRow.currentKeyStatus === "key" ? theme.accent : parameterRow.currentKeyStatus === "animated" ? theme.muted : theme.border
                    Accessible.name: "Animation key status: " + parameterRow.currentKeyStatus
                    Accessible.description: "Click to insert or update a key at the current frame. Right-click to remove a key at the current frame."

                    Text {
                        anchors.centerIn: parent
                        text: parameterRow.currentKeyStatus === "key" ? "◆" : parameterRow.currentKeyStatus === "animated" ? "◇" : "○"
                        color: parameterRow.currentKeyStatus === "none" ? theme.muted : theme.accent
                        font.pixelSize: 15
                    }

                    MouseArea {
                        id: keyIndicatorMouse
                        anchors.fill: parent
                        acceptedButtons: Qt.LeftButton | Qt.RightButton
                        hoverEnabled: true
                        onClicked: function (mouse) {
                            if (mouse.button === Qt.RightButton) {
                                keyContextMenu.popup();
                                return;
                            }
                            parameterRow.keyAtCurrentFrame();
                        }
                    }

                    Menu {
                        id: keyContextMenu
                        MenuItem {
                            text: "Key at frame " + parameterRow.animationFrame
                            onTriggered: parameterRow.keyAtCurrentFrame()
                        }
                        MenuItem {
                            text: "Remove key at frame " + parameterRow.animationFrame
                            enabled: parameterRow.currentKeyStatus === "key"
                            onTriggered: parameterRow.removeCurrentKey()
                        }
                    }

                    ToolTip.visible: indicatorHover.hovered
                    ToolTip.text: parameterRow.currentKeyStatus === "key" ? "Key at frame " + parameterRow.animationFrame + ". Click to update; right-click to remove." : parameterRow.currentKeyStatus === "animated" ? "Animated parameter. Click to add a key at frame " + parameterRow.animationFrame : "Not animated. Click to add a key at frame " + parameterRow.animationFrame
                    HoverHandler {
                        id: indicatorHover
                    }
                }

                ColumnLayout {
                    id: controlColumn
                    Layout.fillWidth: true
                    spacing: 2

                    RowLayout {
                        visible: parameterRow.parameter.kind === "number"
                        Layout.fillWidth: true
                        spacing: 4

                        Slider {
                            id: numberSlider
                            property int revision: parameterRow.modelRevision + parameterRow.animationModelRevision
                            objectName: "slider_" + parameterRow.nodeId + "_" + parameterRow.parameterKey
                            from: parameterRow.parameter.min !== undefined ? Number(parameterRow.parameter.min) : 0
                            to: parameterRow.parameter.max !== undefined ? Number(parameterRow.parameter.max) : 1
                            stepSize: parameterRow.parameter.step !== undefined ? Number(parameterRow.parameter.step) : 0.01
                            value: Number(parameterRow.parameter.value)
                            Layout.fillWidth: true
                            implicitHeight: 20
                            onMoved: parametersPrototype.studioCommit(parameterRow, numberSlider.value)
                            onPressedChanged: {
                                if (pressed)
                                    studio.beginAnimationEdit();
                                else
                                    studio.endAnimationEdit();
                            }
                            Component.onDestruction: if (pressed)
                                studio.endAnimationEdit()
                            onRevisionChanged: if (!pressed)
                                value = Number(parameterRow.parameter.value)
                            background: Rectangle {
                                x: 0
                                y: numberSlider.topPadding + numberSlider.availableHeight / 2 - height / 2
                                width: numberSlider.availableWidth
                                height: 3
                                radius: 2
                                color: theme.border
                            }
                            handle: Rectangle {
                                x: numberSlider.leftPadding + numberSlider.visualPosition * (numberSlider.availableWidth - width)
                                y: numberSlider.topPadding + numberSlider.availableHeight / 2 - height / 2
                                width: 10
                                height: 10
                                radius: 5
                                color: theme.accent
                            }
                            MouseArea {
                                anchors.fill: parent
                                onPressed: function (mouse) {
                                    mouse.accepted = !!(mouse.modifiers & Qt.AltModifier);
                                }
                                onClicked: parameterRow.keyAtCurrentFrame()
                            }
                        }

                        TextField {
                            id: numberField
                            property bool pendingNumericEdit: false
                            objectName: "param_" + parameterRow.nodeId + "_" + parameterRow.parameterKey
                            property int revision: parameterRow.modelRevision + parameterRow.animationModelRevision
                            text: parametersPrototype.formatParameter(parameterRow.parameter.value, parameterRow.parameter.step)
                            implicitWidth: 52
                            implicitHeight: 23
                            font.pixelSize: theme.fontSize
                            color: theme.text
                            selectByMouse: true
                            horizontalAlignment: Text.AlignRight
                            validator: DoubleValidator {
                                bottom: parameterRow.parameter.min !== undefined ? Number(parameterRow.parameter.min) : -1e9
                                top: parameterRow.parameter.max !== undefined ? Number(parameterRow.parameter.max) : 1e9
                            }
                            onEditingFinished: {
                                if (pendingNumericEdit)
                                    parametersPrototype.commitNumeric(parameterRow, numberField.text);
                                pendingNumericEdit = false;
                            }
                            onTextEdited: pendingNumericEdit = true
                            onRevisionChanged: if (!activeFocus || !pendingNumericEdit) {
                                var current = studio.parameter(parameterRow.nodeId, parameterRow.parameterKey);
                                if (current && current.kind === "number")
                                    text = parametersPrototype.formatParameter(current.value, current.step);
                                pendingNumericEdit = false;
                            }
                            background: Rectangle {
                                color: theme.field
                                border.color: numberField.activeFocus ? theme.accent : theme.border
                                radius: theme.smallRadius
                            }
                            MouseArea {
                                anchors.fill: parent
                                onPressed: function (mouse) {
                                    mouse.accepted = !!(mouse.modifiers & Qt.AltModifier);
                                }
                                onClicked: parameterRow.keyAtCurrentFrame()
                            }
                        }
                    }

                    StudioComboBox {
                        id: choiceBox
                        visible: parameterRow.parameter.kind === "choice"
                        property int revision: parameterRow.modelRevision + parameterRow.animationModelRevision
                        objectName: "choice_" + parameterRow.nodeId + "_" + parameterRow.parameterKey
                        model: parameterRow.parameter.options || []
                        currentIndex: Math.max(0, model.indexOf(parameterRow.parameter.value))
                        onRevisionChanged: currentIndex = Math.max(0, model.indexOf(parameterRow.parameter.value))
                        Layout.fillWidth: true
                        implicitHeight: 23
                        font.pixelSize: theme.fontSize
                        onActivated: parametersPrototype.studioCommit(parameterRow, currentText)
                        MouseArea {
                            anchors.fill: parent
                            onPressed: function (mouse) {
                                mouse.accepted = !!(mouse.modifiers & Qt.AltModifier);
                            }
                            onClicked: parameterRow.keyAtCurrentFrame()
                        }
                    }

                    Switch {
                        id: toggleBox
                        visible: parameterRow.parameter.kind === "toggle"
                        property int revision: parameterRow.modelRevision + parameterRow.animationModelRevision
                        objectName: "toggle_" + parameterRow.nodeId + "_" + parameterRow.parameterKey
                        checked: parameterRow.parameter.value === true
                        implicitWidth: 30
                        implicitHeight: 20
                        onToggled: parametersPrototype.studioCommit(parameterRow, checked)
                        onRevisionChanged: checked = parameterRow.parameter.value === true
                        indicator: Rectangle {
                            x: 1
                            y: (toggleBox.height - height) / 2
                            width: 28
                            height: 16
                            radius: 8
                            color: toggleBox.checked ? theme.accent : theme.raised
                            border.color: theme.border
                            Rectangle {
                                x: toggleBox.checked ? parent.width - width - 2 : 2
                                y: 2
                                width: 12
                                height: 12
                                radius: 6
                                color: theme.text
                            }
                        }
                        contentItem: Item {
                        }
                        MouseArea {
                            anchors.fill: parent
                            onPressed: function (mouse) {
                                mouse.accepted = !!(mouse.modifiers & Qt.AltModifier);
                            }
                            onClicked: parameterRow.keyAtCurrentFrame()
                        }
                    }
                }
            }
        }
    }

    function findInspectorId(item) {
        var current = item;
        while (current) {
            if (current.inspectorId !== undefined)
                return String(current.inspectorId);
            current = current.parent;
        }
        return "node";
    }

    function studioCommit(parameterRow, value) {
        if (parameterRow && parameterRow.parameter && studio)
            studio.setParam(findInspectorId(parameterRow), String(parameterRow.parameter.key), value);
    }

    function formatParameter(value, step) {
        return Number(value).toFixed(step >= 1 ? 0 : step < 0.01 ? 3 : 2);
    }

    function commitNumeric(parameterRow, value) {
        var parameter = parameterRow.parameter;
        var number = Number(value);
        if (!Number.isFinite(number))
            return;
        var minimum = parameter.min !== undefined ? Number(parameter.min) : number;
        var maximum = parameter.max !== undefined ? Number(parameter.max) : number;
        number = Math.max(minimum, Math.min(maximum, number));
        var step = parameter.step !== undefined ? Number(parameter.step) : 0;
        if (step > 0)
            number = minimum + Math.round((number - minimum) / step) * step;
        studio.setParam(findInspectorId(parameterRow), String(parameter.key), number);
    }
}
