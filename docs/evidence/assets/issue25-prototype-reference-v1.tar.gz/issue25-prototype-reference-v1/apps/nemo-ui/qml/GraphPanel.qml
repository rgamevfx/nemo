import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

FocusScope {
    id: graphPrototype

    objectName: "graphPrototype"
    focus: true
    activeFocusOnTab: true
    clip: true

    property string panelId: ""
    property string panelGroup: "A"
    property string restoredPanelId: ""
    property string lastGraphId: ""
    property real zoom: 1.0
    property real zoomTarget: 1.0
    property bool zoomQueued: false
    property real zoomAnchorX: 0
    property real zoomAnchorY: 0
    property bool autoFrame: true
    property bool stateReady: false
    property bool toolsOpen: false
    property bool toolMenuOpen: false
    property real lastClickSceneX: 0
    property real lastClickSceneY: 0
    property bool lastClickValid: false
    property string creationAnchorId: ""
    property string creationGraphId: ""
    property real creationSceneX: 0
    property real creationSceneY: 0
    property real pressSceneX: 0
    property real pressSceneY: 0
    property bool pressSceneValid: false
    property real pointerX: 0
    property real pointerY: 0
    property bool wireDragging: false
    property string wireFromId: ""
    property string wireToId: ""
    property var wireInput: null
    property var wireOutput: 0
    property var wireOldEdge: null
    property bool wireFromInput: false
    property var wireHoverEdge: null
    property var wireHoverPort: null
    property var pipeHoverEdge: null
    property bool pipeHoverOutput: true
    property bool shiftHeld: false
    property string graphError: (typeof studio !== "undefined" && studio) ? studio.graphError : ""
    property real wirePressX: 0
    property bool pipePullPending: false
    property var pipePullEdge: null
    property bool pipePullEndpointOutput: true
    property real wirePressY: 0
    property bool rerouteDragging: false
    property var rerouteEdge: null
    property int rerouteIndex: -1
    property bool rerouteAltRemove: false

    // A single canvas gesture owner uses these transient values. The model is
    // updated once, on release, so pointer motion never increments revision.
    property string gesture: ""
    property bool gestureMoved: false
    property real gesturePressX: 0
    property real gesturePressY: 0
    property real panOriginX: 0
    property real panOriginY: 0
    property real boxStartX: 0
    property real boxStartY: 0
    property var boxSelectionBase: []
    property var dragIds: []
    property var dragStartPositions: ({})
    property real dragDeltaX: 0
    property real dragDeltaY: 0
    property string disconnectedInsertId: ""
    property int positionEpoch: 0
    property bool lastClickMoved: false
    property string contextNodeId: ""
    property real contextMenuX: 0
    property real contextMenuY: 0
    property var graphViews: ({})
    property point searchAnchor: Qt.point(0, 0)

    readonly property real nodeWidth: (studioObject() && studioObject().graphNodeWidth !== undefined) ? Number(studioObject().graphNodeWidth) : 112
    readonly property real nodeHeight: (studioObject() && studioObject().graphNodeHeight !== undefined) ? Number(studioObject().graphNodeHeight) : 28
    readonly property real portGlyphSize: 8
    readonly property real portHitRadius: 14
    readonly property real sceneWidth: 2600
    readonly property real sceneHeight: 1500
    property Component headerTools: headerToolsComponent

    function clampZoom(value) {
        return Math.max(0.2, Math.min(2.5, Number(value) || 1.0));
    }

    function studioObject() {
        return (typeof studio !== "undefined" && studio) ? studio : null;
    }

    function activeNodes() {
        var model = studioObject();
        return model && model.nodes ? model.nodes : [];
    }

    function activeEdges() {
        var model = studioObject();
        return model && model.edges ? model.edges : [];
    }

    function graphId() {
        var model = studioObject();
        return model && model.activeGraphId !== undefined ? String(model.activeGraphId) : "root";
    }

    function nodeLabel(node) {
        if (!node)
            return "";
        return node.name && String(node.name).length > 0 ? String(node.name) : String(node.type || "Node");
    }

    function nodeCategoryId(node) {
        var model = studioObject();
        return model && model.nodeCategory ? model.nodeCategory(node && node.type !== undefined ? String(node.type) : "") : "Utility";
    }

    function nodeCategoryFill(node) {
        return theme.nodeCategoryColor(nodeCategoryId(node));
    }

    function nodeCategoryText(node) {
        return theme.nodeCategoryTextColor(nodeCategoryId(node));
    }

    function availableTypes() {
        var model = studioObject();
        return model && model.nodeTypes ? model.nodeTypes() : [];
    }

    function filteredTypes() {
        var needle = addSearch.text.toLowerCase();
        return availableTypes().filter(function (type) {
                return String(type).toLowerCase().indexOf(needle) >= 0;
            });
    }

    function currentSelection() {
        var model = studioObject();
        if (!model)
            return [];
        var selected = model.selectedNodeIds;
        if (selected && selected.length !== undefined) {
            var result = [];
            for (var i = 0; i < selected.length; ++i)
                result.push(String(selected[i]));
            return result;
        }
        return model.selectedNodeId ? [String(model.selectedNodeId)] : [];
    }

    function isSelected(id) {
        var wanted = String(id);
        var selected = currentSelection();
        return selected.indexOf(wanted) >= 0;
    }

    function setSelection(ids) {
        var model = studioObject();
        if (!model)
            return;
        var normalized = [];
        for (var i = 0; i < (ids || []).length; ++i) {
            var id = String(ids[i]);
            if (normalized.indexOf(id) < 0 && model.node && model.node(id))
                normalized.push(id);
        }
        if (model.setSelection)
            model.setSelection(normalized);
        else if (normalized.length && model.selectNode)
            model.selectNode(normalized[0]);
    }

    function toggleSelection(id) {
        var model = studioObject();
        if (!model)
            return;
        if (model.selectNode) {
            model.selectNode(id, true);
            return;
        }
        var selected = currentSelection();
        var index = selected.indexOf(String(id));
        if (index >= 0)
            selected.splice(index, 1);
        else
            selected.push(String(id));
        setSelection(selected);
    }

    function nodeById(id) {
        var model = studioObject();
        if (!model || !model.node)
            return null;
        var result = model.node(id);
        if (!result)
            result = model.node(String(id));
        return result;
    }

    function portId(port, fallback) {
        return port && port.id !== undefined ? port.id : fallback;
    }

    function inputPorts(id) {
        var model = studioObject();
        if (!model || !model.inputPorts)
            return [];
        return model.inputPorts(id) || [];
    }

    function outputPorts(id) {
        var model = studioObject();
        if (!model || !model.outputPorts)
            return [];
        return model.outputPorts(id) || [];
    }

    function portSide(port, output) {
        if (port && port.side)
            return String(port.side);
        return output ? "bottom" : (port && port.type === "mask" ? "right" : "top");
    }

    function samePort(a, b) {
        return !!a && !!b && String(a.nodeId) === String(b.nodeId) && String(a.portId) === String(b.portId) && !!a.output === !!b.output;
    }

    function portsOnSide(node, output, side) {
        var ports = output ? outputPorts(node.id) : inputPorts(node.id);
        var result = [];
        for (var i = 0; i < ports.length; ++i)
            if (portSide(ports[i], output) === side)
                result.push({
                        "port": ports[i],
                        "index": i
                    });
        return result;
    }

    function nodeSceneXFor(node) {
        var epoch = positionEpoch;
        var start = dragStartPositions[String(node.id)];
        return start ? start.x + dragDeltaX : Number((nodeById(node.id) || node).x);
    }

    function nodeSceneYFor(node) {
        var epoch = positionEpoch;
        var start = dragStartPositions[String(node.id)];
        return start ? start.y + dragDeltaY : Number((nodeById(node.id) || node).y);
    }

    function portLocalPoint(node, port, output, fallbackIndex) {
        var side = portSide(port, output);
        var sidePorts = portsOnSide(node, output, side);
        var index = 0;
        for (var i = 0; i < sidePorts.length; ++i) {
            if (String(portId(sidePorts[i].port, sidePorts[i].index)) === String(portId(port, fallbackIndex))) {
                index = i;
                break;
            }
        }
        var count = Math.max(1, sidePorts.length);
        var fraction = count === 1 ? 0.5 : (index + 1) / (count + 1);
        if (side === "right")
            return {
                "x": nodeWidth,
                "y": nodeHeight * fraction
            };
        if (side === "bottom")
            return {
                "x": nodeWidth * fraction,
                "y": nodeHeight
            };
        return {
            "x": nodeWidth * fraction,
            "y": 0
        };
    }

    function portScenePoint(node, port, output, fallbackIndex) {
        var local = portLocalPoint(node, port, output, fallbackIndex);
        return {
            "x": nodeSceneXFor(node) + local.x,
            "y": nodeSceneYFor(node) + local.y
        };
    }

    // Keep the generous screen-space radius at the node boundary, but reserve
    // the low-zoom node core for node selection/dragging. This makes an 8px
    // off-centre press acquire a port without creating a giant invisible lobe.
    function portHitAllowed(node, port, output, px, py) {
        var side = portSide(port, output);
        var left = sceneRoot.x + nodeSceneXFor(node) * zoom;
        var top = sceneRoot.y + nodeSceneYFor(node) * zoom;
        var width = nodeWidth * zoom;
        var height = nodeHeight * zoom;
        if (side === "right")
            return px >= left + width * 0.55;
        if (side === "bottom")
            return py >= top + height * 0.55;
        return py <= top + height * 0.45;
    }

    function canvasPoint(scenePoint) {
        return {
            "x": sceneRoot.x + scenePoint.x * zoom,
            "y": sceneRoot.y + scenePoint.y * zoom
        };
    }

    function sceneCoordinate(px, py) {
        return {
            "x": (px - sceneRoot.x) / zoom - nodeWidth / 2,
            "y": (py - sceneRoot.y) / zoom - nodeHeight / 2
        };
    }

    function nodeSceneX(id, modelX, epoch) {
        // epoch is intentionally read by the binding so model moves that do
        // not reset the nodes array still refresh every delegate.
        var ignored = epoch;
        var start = dragStartPositions[String(id)];
        var current = nodeById(id);
        return start ? start.x + dragDeltaX : (current ? Number(current.x) : Number(modelX));
    }

    function nodeSceneY(id, modelY, epoch) {
        var ignored = epoch;
        var start = dragStartPositions[String(id)];
        var current = nodeById(id);
        return start ? start.y + dragDeltaY : (current ? Number(current.y) : Number(modelY));
    }

    function portAt(px, py, output) {
        var nodes = activeNodes();
        var best = null;
        var bestDistance = portHitRadius + 0.001;
        for (var i = 0; i < nodes.length; ++i) {
            var node = nodes[i];
            var ports = output ? outputPorts(node.id) : inputPorts(node.id);
            for (var j = 0; j < ports.length; ++j) {
                var p = ports[j];
                var scene = portScenePoint(node, p, output, j);
                var point = canvasPoint(scene);
                var distance = Math.hypot(px - point.x, py - point.y);
                if (distance <= bestDistance && portHitAllowed(node, p, output, px, py)) {
                    bestDistance = distance;
                    best = {
                        "nodeId": String(node.id),
                        "portId": portId(p, j),
                        "port": p,
                        "output": output,
                        "x": point.x,
                        "y": point.y,
                        "distance": distance
                    };
                }
            }
        }
        return best;
    }

    function inputAt(px, py) {
        return portAt(px, py, false);
    }

    function outputAt(px, py) {
        return portAt(px, py, true);
    }

    function edgeInput(edge) {
        return edge && edge.input !== undefined ? edge.input : 0;
    }

    function edgeOutput(edge) {
        return edge && edge.output !== undefined ? edge.output : 0;
    }

    function edgeRoutePoints(edge) {
        if (rerouteDragging && rerouteEdge && sameEdge(edge, rerouteEdge))
            return rerouteEdge.routePoints || [];
        var model = studioObject();
        return model && model.edgeRoute ? model.edgeRoute(edge) : (edge && edge.routePoints ? edge.routePoints : []);
    }

    function copyEdge(edge) {
        return edge ? {
            "from": String(edge.from),
            "to": String(edge.to),
            "input": edgeInput(edge),
            "output": edgeOutput(edge),
            "routePoints": edgeRoutePoints(edge)
        } : null;
    }

    function sameEdge(a, b) {
        return !!a && !!b && String(a.from) === String(b.from) && String(a.to) === String(b.to) && String(edgeInput(a)) === String(edgeInput(b)) && String(edgeOutput(a)) === String(edgeOutput(b));
    }

    function findPort(node, output, wanted) {
        var ports = output ? outputPorts(node.id) : inputPorts(node.id);
        for (var i = 0; i < ports.length; ++i)
            if (String(portId(ports[i], i)) === String(wanted))
                return ports[i];
        return ports.length ? ports[0] : null;
    }
    function anyPortAt(px, py) {
        var output = portAt(px, py, true);
        var input = portAt(px, py, false);
        if (!output)
            return input;
        if (!input || output.distance <= input.distance)
            return output;
        return input;
    }

    function edgeCanvasGeometry(edge) {
        var from = nodeById(edge.from);
        var to = nodeById(edge.to);
        if (!from || !to)
            return null;
        var fromPort = findPort(from, true, edgeOutput(edge));
        var toPort = findPort(to, false, edgeInput(edge));
        if (!fromPort || !toPort)
            return null;
        var points = [canvasPoint(portScenePoint(from, fromPort, true, 0))];
        var route = edgeRoutePoints(edge);
        for (var i = 0; i < route.length; ++i)
            points.push(canvasPoint(route[i]));
        points.push(canvasPoint(portScenePoint(to, toPort, false, 0)));
        return {
            "points": points,
            "sx": points[0].x,
            "sy": points[0].y,
            "tx": points[points.length - 1].x,
            "ty": points[points.length - 1].y
        };
    }

    function wireProjectionAt(edge, px, py) {
        var geometry = edgeCanvasGeometry(edge);
        if (!geometry)
            return null;
        var points = geometry.points, best = null;
        for (var i = 0; i + 1 < points.length; ++i) {
            var a = points[i], b = points[i + 1];
            var dx = b.x - a.x, dy = b.y - a.y;
            var length2 = dx * dx + dy * dy;
            var along = length2 > 0 ? Math.max(0, Math.min(1, ((px - a.x) * dx + (py - a.y) * dy) / length2)) : 0;
            var x = a.x + along * dx, y = a.y + along * dy;
            var distance = Math.hypot(px - x, py - y);
            if (!best || distance < best.distance)
                best = {
                    "distance": distance,
                    "segmentIndex": i,
                    "x": x,
                    "y": y
                };
        }
        return best;
    }

    function distanceToWire(edge, px, py) {
        var projection = wireProjectionAt(edge, px, py);
        return projection ? projection.distance : Number.POSITIVE_INFINITY;
    }

    function wireAt(px, py) {
        var edges = activeEdges();
        var best = null;
        var bestDistance = 12;
        for (var i = 0; i < edges.length; ++i) {
            var projection = wireProjectionAt(edges[i], px, py);
            if (projection && projection.distance <= bestDistance) {
                bestDistance = projection.distance;
                best = edges[i];
            }
        }
        return best ? copyEdge(best) : null;
    }
    function pipeBodyAt(px, py) {
        if (anyPortAt(px, py) || wireEndpointAt(px, py) || nodeAt(px, py) || rerouteDotAt(px, py))
            return null;
        return wireAt(px, py);
    }

    function scenePointFromCanvas(px, py) {
        return {
            "x": (px - sceneRoot.x) / zoom,
            "y": (py - sceneRoot.y) / zoom
        };
    }

    function rerouteDotAt(px, py) {
        var edges = activeEdges(), best = null, bestDistance = 9;
        for (var i = 0; i < edges.length; ++i) {
            var edge = edges[i], geometry = edgeCanvasGeometry(edge);
            if (!geometry)
                continue;
            for (var j = 1; j + 1 < geometry.points.length; ++j) {
                var point = geometry.points[j], distance = Math.hypot(px - point.x, py - point.y);
                if (distance <= bestDistance) {
                    bestDistance = distance;
                    best = {
                        "edge": copyEdge(edge),
                        "index": j - 1,
                        "x": point.x,
                        "y": point.y,
                        "distance": distance
                    };
                }
            }
        }
        return best;
    }

    function beginReroute(edge, index, altRemove) {
        rerouteEdge = copyEdge(edge);
        rerouteIndex = Number(index);
        rerouteAltRemove = !!altRemove;
        rerouteDragging = true;
        gesture = "reroute";
        autoFrame = false;
        wires.requestPaint();
    }

    function beginRerouteOnSegment(px, py) {
        var best = null, edges = activeEdges();
        for (var i = 0; i < edges.length; ++i) {
            var projection = wireProjectionAt(edges[i], px, py);
            if (projection && (!best || projection.distance < best.projection.distance))
                best = {
                    "edge": edges[i],
                    "projection": projection
                };
        }
        if (!best || best.projection.distance > 12)
            return false;
        var route = edgeRoutePoints(best.edge);
        route.splice(best.projection.segmentIndex, 0, scenePointFromCanvas(best.projection.x, best.projection.y));
        beginReroute(best.edge, best.projection.segmentIndex, false);
        rerouteEdge.routePoints = route;
        return true;
    }

    function updateReroutePreview(px, py) {
        if (!rerouteDragging || rerouteIndex < 0 || !rerouteEdge)
            return;
        var point = scenePointFromCanvas(px, py);
        var route = edgeRoutePoints(rerouteEdge);
        if (rerouteIndex < route.length)
            route[rerouteIndex] = {
                "x": point.x,
                "y": point.y
            };
        rerouteEdge.routePoints = route;
        wires.requestPaint();
    }

    function finishReroute() {
        if (!rerouteDragging)
            return;
        var model = studioObject(), edge = rerouteEdge;
        if (model && model.setEdgeRoute && edge) {
            if (rerouteAltRemove && !gestureMoved)
                model.removeEdgeRoutePoint(edge, rerouteIndex);
            else
                model.setEdgeRoute(edge, edge.routePoints || []);
        }
        rerouteDragging = false;
        rerouteEdge = null;
        rerouteIndex = -1;
        rerouteAltRemove = false;
        wires.requestPaint();
    }

    function cancelReroute() {
        rerouteDragging = false;
        rerouteEdge = null;
        rerouteIndex = -1;
        rerouteAltRemove = false;
        wires.requestPaint();
    }

    function wireEndpointAt(px, py) {
        var edges = activeEdges();
        var best = null;
        var bestDistance = portHitRadius + 0.001;
        for (var i = 0; i < edges.length; ++i) {
            var edge = edges[i];
            var from = nodeById(edge.from);
            var to = nodeById(edge.to);
            if (!from || !to)
                continue;
            var fromPort = findPort(from, true, edgeOutput(edge));
            var toPort = findPort(to, false, edgeInput(edge));
            if (!fromPort || !toPort)
                continue;
            var points = [{
                    "point": canvasPoint(portScenePoint(from, fromPort, true, 0)),
                    "output": true,
                    "allowed": portHitAllowed(from, fromPort, true, px, py)
                }, {
                    "point": canvasPoint(portScenePoint(to, toPort, false, 0)),
                    "output": false,
                    "allowed": portHitAllowed(to, toPort, false, px, py)
                }];
            for (var j = 0; j < points.length; ++j) {
                var distance = Math.hypot(px - points[j].point.x, py - points[j].point.y);
                if (points[j].allowed && distance <= bestDistance) {
                    bestDistance = distance;
                    best = {
                        "edge": copyEdge(edge),
                        "output": points[j].output,
                        "distance": distance
                    };
                }
            }
        }
        return best;
    }

    function nodeAt(px, py) {
        var sceneX = (px - sceneRoot.x) / zoom;
        var sceneY = (py - sceneRoot.y) / zoom;
        var nodes = activeNodes();
        for (var i = nodes.length - 1; i >= 0; --i) {
            var node = nodes[i];
            var x = nodeSceneX(node.id, node.x, positionEpoch);
            var y = nodeSceneY(node.id, node.y, positionEpoch);
            if (sceneX >= x && sceneX <= x + nodeWidth && sceneY >= y && sceneY <= y + nodeHeight)
                return String(node.id);
        }
        return "";
    }

    function enterAt(px, py) {
        var id = nodeAt(px, py);
        if (!id)
            return "";
        var node = nodeById(id);
        if (!node || node.type !== "Subnet")
            return "";
        var x = nodeSceneX(id, node.x, positionEpoch);
        var y = nodeSceneY(id, node.y, positionEpoch);
        var sceneX = (px - sceneRoot.x) / zoom;
        var sceneY = (py - sceneRoot.y) / zoom;
        return sceneX >= x + nodeWidth - 24 && sceneX <= x + nodeWidth - 3 && sceneY >= y + 3 && sceneY <= y + 24 ? id : "";
    }

    function edgeForInput(id, input) {
        var edges = activeEdges();
        for (var i = 0; i < edges.length; ++i)
            if (String(edges[i].to) === String(id) && String(edgeInput(edges[i])) === String(input))
                return copyEdge(edges[i]);
        return null;
    }

    function isDisconnected(id) {
        var edges = activeEdges();
        for (var i = 0; i < edges.length; ++i)
            if (String(edges[i].from) === String(id) || String(edges[i].to) === String(id))
                return false;
        return true;
    }
    function updateWireHover(px, py) {
        var nextEdge = disconnectedInsertId.length > 0 ? wireAt(px, py) : null;
        if ((nextEdge || wireHoverEdge) && !sameEdge(nextEdge, wireHoverEdge)) {
            wireHoverEdge = nextEdge;
            wires.requestPaint();
        }
        var nextPipe = !gesture.length && !wireDragging ? pipeBodyAt(px, py) : pipePullPending ? pipePullEdge : null;
        var nextPipeOutput = pipePullPending ? pipePullEndpointOutput : !shiftHeld;
        if ((nextPipe || pipeHoverEdge) && (!nextPipe || !pipeHoverEdge || !sameEdge(nextPipe, pipeHoverEdge) || pipeHoverOutput !== nextPipeOutput)) {
            pipeHoverEdge = nextPipe;
            pipeHoverOutput = nextPipeOutput;
            wires.requestPaint();
        }
        var nextPort = wireDragging ? (wireFromInput ? outputAt(px, py) : inputAt(px, py)) : (!gesture.length ? anyPortAt(px, py) : null);
        if ((nextPort || wireHoverPort) && !samePort(nextPort, wireHoverPort))
            wireHoverPort = nextPort;
        if (wireDragging)
            wires.requestPaint();
    }

    function updateModifierIndicator(modifiers) {
        var nextShift = (modifiers & Qt.ShiftModifier) !== 0;
        if (shiftHeld === nextShift)
            return;
        shiftHeld = nextShift;
        updateWireHover(pointerX, pointerY);
        wires.requestPaint();
    }

    function beginPipePullPress(edge, moveOutput) {
        if (!edge)
            return;
        autoFrame = false;
        pipePullPending = true;
        pipePullEdge = copyEdge(edge);
        pipePullEndpointOutput = !!moveOutput;
        pipeHoverEdge = pipePullEdge;
        pipeHoverOutput = pipePullEndpointOutput;
        wirePressX = pointerX;
        wirePressY = pointerY;
        gesturePressX = pointerX;
        gesturePressY = pointerY;
        wires.requestPaint();
    }

    function beginPipePull() {
        if (!pipePullPending || !pipePullEdge)
            return;
        var edge = pipePullEdge;
        var moveOutput = pipePullEndpointOutput;
        var pressX = wirePressX;
        var pressY = wirePressY;
        pipePullPending = false;
        pipePullEdge = null;
        if (moveOutput)
            beginInputWire(edge.to, edge.input);
        else
            beginOutputWire(edge.from, edge.output, edge);
        wirePressX = pressX;
        wirePressY = pressY;
        gesture = "wire";
    }

    function updatePointer(px, py) {
        pointerX = px;
        pointerY = py;
        updateWireHover(px, py);
    }

    function clearWireDrag() {
        wireDragging = false;
        wireFromId = "";
        wireToId = "";
        wireInput = null;
        wireOutput = 0;
        wireOldEdge = null;
        wireFromInput = false;
        wireHoverPort = null;
        pipePullPending = false;
        pipePullEdge = null;
        pipePullEndpointOutput = true;
        pipeHoverEdge = null;
        wires.requestPaint();
    }

    function beginOutputWire(id, output, oldEdge) {
        if (!outputPorts(id).length)
            return;
        autoFrame = false;
        wireDragging = true;
        wireFromInput = false;
        wireFromId = String(id);
        wireOutput = output;
        wireToId = "";
        wireInput = null;
        wireOldEdge = oldEdge ? copyEdge(oldEdge) : null;
        wirePressX = pointerX;
        wirePressY = pointerY;
        forceActiveFocus();
        wires.requestPaint();
    }

    function beginInputWire(id, input) {
        autoFrame = false;
        wireDragging = true;
        wireFromInput = true;
        wireToId = String(id);
        wireInput = input;
        wireOldEdge = edgeForInput(id, input);
        wireFromId = wireOldEdge ? String(wireOldEdge.from) : "";
        wireOutput = wireOldEdge ? edgeOutput(wireOldEdge) : 0;
        wirePressX = pointerX;
        wirePressY = pointerY;
        forceActiveFocus();
        wires.requestPaint();
    }

    function finishWireInput(id, input) {
        var model = studioObject();
        if (!wireDragging || wireFromInput || !model)
            return;
        var old = wireOldEdge || edgeForInput(id, input);
        var error = model.connectionError ? model.connectionError(wireFromId, String(id), input, old, wireOutput) : "";
        if (!error.length && model.connectNodes)
            model.connectNodes(wireFromId, String(id), input, old, wireOutput);
        clearWireDrag();
    }

    function finishWireOutput(id, output) {
        var model = studioObject();
        if (!wireDragging || !wireFromInput || !model)
            return;
        var error = model.connectionError ? model.connectionError(String(id), wireToId, wireInput, wireOldEdge, output) : "";
        if (!error.length && model.connectNodes)
            model.connectNodes(String(id), wireToId, wireInput, wireOldEdge, output);
        clearWireDrag();
    }

    function releaseWireAt() {
        var model = studioObject();
        if (!wireDragging)
            return;
        if (Math.hypot(pointerX - wirePressX, pointerY - wirePressY) < 3) {
            clearWireDrag();
            return;
        }
        if (pointerX < 0 || pointerY < 0 || pointerX > graphSurface.width || pointerY > graphSurface.height) {
            clearWireDrag();
            return;
        }
        if (wireFromInput) {
            var output = outputAt(pointerX, pointerY);
            if (output)
                finishWireOutput(output.nodeId, output.portId);
            else if (inputAt(pointerX, pointerY) || nodeAt(pointerX, pointerY))
                setGraphError(wireToId + " [input " + wireInput + "]: drop on an output to reconnect.");
            else if (wireOldEdge && model && model.disconnectEdge)
                model.disconnectEdge(wireOldEdge);
        } else {
            var input = inputAt(pointerX, pointerY);
            if (input)
                finishWireInput(input.nodeId, input.portId);
            else if (outputAt(pointerX, pointerY) || nodeAt(pointerX, pointerY))
                setGraphError(wireFromId + ": drop on an input to connect.");
            else if (wireOldEdge && model && model.disconnectEdge)
                model.disconnectEdge(wireOldEdge);
        }
        clearWireDrag();
    }

    function creationFallbackPoint() {
        var point = lastClickValid ? {
            "x": lastClickSceneX,
            "y": lastClickSceneY
        } : sceneCoordinate(graphSurface.width / 2, graphSurface.height / 2);
        var snappedX = snappedNodeCoordinate(point.x, "x");
        var snappedY = snappedNodeCoordinate(point.y, "y");
        return {
            "x": isFinite(snappedX) ? snappedX : point.x,
            "y": isFinite(snappedY) ? snappedY : point.y
        };
    }

    function captureCreationContext() {
        var model = studioObject();
        var fallback = creationFallbackPoint();
        creationSceneX = fallback.x;
        creationSceneY = fallback.y;
        creationAnchorId = "";
        if (model && model.selectedNodeId !== undefined && nodeById(model.selectedNodeId))
            creationAnchorId = String(model.selectedNodeId);
        creationGraphId = graphId();
    }

    function createNodeFromContext(type) {
        var model = studioObject();
        if (!type || availableTypes().indexOf(type) < 0 || !model || !model.createNode)
            return "";
        if (!creationGraphId.length || creationGraphId !== graphId())
            captureCreationContext();
        autoFrame = false;
        var id = model.createNode(String(type), creationSceneX, creationSceneY, creationAnchorId);
        if (id) {
            positionEpoch++;
            forceActiveFocus();
            wires.requestPaint();
        }
        return id || "";
    }

    function queueZoom(factor, px, py) {
        autoFrame = false;
        zoomTarget = clampZoom(zoomTarget * factor);
        zoomAnchorX = px;
        zoomAnchorY = py;
        if (!zoomQueued) {
            zoomQueued = true;
            zoomFrame.start();
        }
    }

    function applyZoomTarget() {
        zoomQueued = false;
        var oldZoom = zoom;
        var nextZoom = clampZoom(zoomTarget);
        if (nextZoom === oldZoom)
            return;
        var sceneX = (zoomAnchorX - sceneRoot.x) / oldZoom;
        var sceneY = (zoomAnchorY - sceneRoot.y) / oldZoom;
        zoom = nextZoom;
        sceneRoot.x = zoomAnchorX - sceneX * nextZoom;
        sceneRoot.y = zoomAnchorY - sceneY * nextZoom;
        persistView();
        grid.requestPaint();
        wires.requestPaint();
    }

    function zoomAt(factor, px, py) {
        zoomTarget = zoom;
        queueZoom(factor, px, py);
    }

    function viewKey(id, panel) {
        return String(panel === undefined ? panelId : panel) + "::" + String(id || "root");
    }

    function saveViewFor(id, panel) {
        var model = studioObject();
        var targetPanel = panel === undefined ? panelId : panel;
        if (!model || !model.savePanelState || !stateReady || !targetPanel || !id)
            return;
        var next = {};
        for (var key in graphViews)
            next[key] = graphViews[key];
        next[viewKey(id, targetPanel)] = {
            "autoFrame": autoFrame,
            "zoom": Number(zoom),
            "x": Number(sceneRoot.x),
            "y": Number(sceneRoot.y),
            "lastClickValid": lastClickValid,
            "lastClickSceneX": Number(lastClickSceneX),
            "lastClickSceneY": Number(lastClickSceneY)
        };
        graphViews = next;
        model.savePanelState(targetPanel, {
                "graphViews": graphViews,
                "activeGraphId": String(id),
                "autoFrame": autoFrame,
                "zoom": Number(zoom),
                "x": Number(sceneRoot.x),
                "y": Number(sceneRoot.y),
                "lastClickValid": lastClickValid,
                "lastClickSceneX": Number(lastClickSceneX),
                "lastClickSceneY": Number(lastClickSceneY)
            });
    }

    function persistView(destination) {
        saveViewFor(destination || graphId());
    }

    function frameAll() {
        autoFrame = true;
        var items = activeNodes();
        if (!items.length || graphSurface.width <= 2 || graphSurface.height <= 2)
            return;
        var minX = Number.POSITIVE_INFINITY;
        var minY = Number.POSITIVE_INFINITY;
        var maxX = Number.NEGATIVE_INFINITY;
        var maxY = Number.NEGATIVE_INFINITY;
        for (var i = 0; i < items.length; ++i) {
            var item = items[i];
            var x = Number(item.x) || 0;
            var y = Number(item.y) || 0;
            minX = Math.min(minX, x);
            minY = Math.min(minY, y);
            maxX = Math.max(maxX, x + nodeWidth);
            maxY = Math.max(maxY, y + nodeHeight);
        }
        var routedEdges = activeEdges();
        for (var edgeIndex = 0; edgeIndex < routedEdges.length; ++edgeIndex) {
            var route = edgeRoutePoints(routedEdges[edgeIndex]);
            for (var routeIndex = 0; routeIndex < route.length; ++routeIndex) {
                minX = Math.min(minX, route[routeIndex].x);
                minY = Math.min(minY, route[routeIndex].y);
                maxX = Math.max(maxX, route[routeIndex].x);
                maxY = Math.max(maxY, route[routeIndex].y);
            }
        }
        var boundsWidth = Math.max(nodeWidth, maxX - minX);
        var boundsHeight = Math.max(nodeHeight, maxY - minY);
        zoomTarget = clampZoom(Math.min((graphSurface.width - 42) / boundsWidth, (graphSurface.height - 42) / boundsHeight));
        zoom = zoomTarget;
        sceneRoot.x = (graphSurface.width - boundsWidth * zoom) / 2 - minX * zoom;
        sceneRoot.y = (graphSurface.height - boundsHeight * zoom) / 2 - minY * zoom;
        persistView();
        grid.requestPaint();
        wires.requestPaint();
    }

    function restoreView(id) {
        var model = studioObject();
        if (!model || !panelId || graphSurface.width <= 2 || graphSurface.height <= 2)
            return;
        var state = graphViews[viewKey(id)];
        if (!state && model.loadPanelState) {
            var saved = model.loadPanelState(panelId);
            if (saved) {
                if (saved.graphViews)
                    graphViews = saved.graphViews;
                state = graphViews[viewKey(id)];
            }
        }
        if (state && isFinite(Number(state.zoom)) && isFinite(Number(state.x)) && isFinite(Number(state.y))) {
            zoom = clampZoom(Number(state.zoom));
            zoomTarget = zoom;
            sceneRoot.x = Number(state.x);
            sceneRoot.y = Number(state.y);
            autoFrame = state.autoFrame !== false;
            lastClickValid = state.lastClickValid === true && isFinite(Number(state.lastClickSceneX)) && isFinite(Number(state.lastClickSceneY));
            lastClickSceneX = lastClickValid ? Number(state.lastClickSceneX) : 0;
            lastClickSceneY = lastClickValid ? Number(state.lastClickSceneY) : 0;
        } else {
            lastClickValid = false;
            lastClickSceneX = 0;
            lastClickSceneY = 0;
            frameAll();
        }
        stateReady = true;
        restoredPanelId = panelId;
        lastGraphId = String(id);
    }

    function openSearch() {
        captureCreationContext();
        addSearch.text = "";
        searchAnchor = graphSurface.mapToItem(Overlay.overlay, pointerX, pointerY);
        addPopup.open();
        addSearch.forceActiveFocus();
    }

    function closeSearch() {
        addPopup.close();
        forceActiveFocus();
    }

    function popupX() {
        if (!Overlay.overlay)
            return 0;
        return Math.max(4, Math.min(Overlay.overlay.width - addPopup.width - 4, searchAnchor.x - addPopup.width / 2));
    }

    function popupY() {
        if (!Overlay.overlay)
            return 0;
        return Math.max(4, Math.min(Overlay.overlay.height - addPopup.height - 4, searchAnchor.y - addPopup.height / 2));
    }

    function snappedNodeCoordinate(value, axis, excludedIds) {
        var threshold = 6 / zoom;
        var best = Number.NaN;
        var bestDistance = threshold + 0.000001;
        var nodes = activeNodes();
        for (var i = 0; i < nodes.length; ++i) {
            var node = nodes[i];
            if (excludedIds && excludedIds.indexOf(node.id) >= 0)
                continue;
            var coordinate = axis === "x" ? Number(node.x) || 0 : Number(node.y) || 0;
            var distance = Math.abs(coordinate - value);
            if (distance < bestDistance) {
                bestDistance = distance;
                best = coordinate;
            }
        }
        return best;
    }

    function snapNodeDrag(rawX, rawY) {
        var bestX = rawX;
        var bestY = rawY;
        var bestXDistance = 6 / zoom + 0.000001;
        var bestYDistance = 6 / zoom + 0.000001;
        for (var i = 0; i < dragIds.length; ++i) {
            var start = dragStartPositions[String(dragIds[i])];
            if (!start)
                continue;
            var movingX = start.x + rawX;
            var snappedX = snappedNodeCoordinate(movingX, "x", dragIds);
            var xCorrection = snappedX - movingX;
            var xDistance = Math.abs(xCorrection);
            if (xDistance < bestXDistance) {
                bestXDistance = xDistance;
                bestX = rawX + xCorrection;
            }
            var movingY = start.y + rawY;
            var snappedY = snappedNodeCoordinate(movingY, "y", dragIds);
            var yCorrection = snappedY - movingY;
            var yDistance = Math.abs(yCorrection);
            if (yDistance < bestYDistance) {
                bestYDistance = yDistance;
                bestY = rawY + yCorrection;
            }
        }
        dragDeltaX = bestX;
        dragDeltaY = bestY;
    }

    function beginNodeDrag(id) {
        var selected = currentSelection();
        if (selected.indexOf(String(id)) < 0)
            selected = [String(id)];
        dragIds = selected;
        var starts = {};
        for (var i = 0; i < dragIds.length; ++i) {
            var node = nodeById(dragIds[i]);
            if (node)
                starts[String(dragIds[i])] = {
                    "x": Number(node.x) || 0,
                    "y": Number(node.y) || 0
                };
        }
        dragStartPositions = starts;
        dragDeltaX = 0;
        dragDeltaY = 0;
        disconnectedInsertId = dragIds.length === 1 && isDisconnected(id) && inputPorts(id).length > 0 && outputPorts(id).length > 0 ? String(id) : "";
        gesture = "nodes";
        autoFrame = false;
    }

    function updateNodeDrag(px, py) {
        var rawX = (px - gesturePressX) / zoom;
        var rawY = (py - gesturePressY) / zoom;
        if (gestureMoved)
            snapNodeDrag(rawX, rawY);
        else {
            dragDeltaX = 0;
            dragDeltaY = 0;
        }
        wires.requestPaint();
    }

    function finishNodeDrag() {
        var model = studioObject();
        if (!dragIds.length)
            return;
        var moves = gestureMoved ? [] : null;
        if (moves) {
            for (var i = 0; i < dragIds.length; ++i) {
                var id = String(dragIds[i]);
                var start = dragStartPositions[id];
                if (start)
                    moves.push({
                            "id": id,
                            "x": start.x + dragDeltaX,
                            "y": start.y + dragDeltaY
                        });
            }
        }
        if (moves && moves.length && model && model.moveNodes)
            model.moveNodes(moves);
        var insertedEdge = disconnectedInsertId ? wireAt(pointerX, pointerY) : null;
        if (insertedEdge && model && model.insertNodeIntoEdge)
            model.insertNodeIntoEdge(disconnectedInsertId, insertedEdge);
        positionEpoch++;
        dragIds = [];
        dragStartPositions = ({});
        disconnectedInsertId = "";
        updateWireHover(pointerX, pointerY);
        persistView();
        wires.requestPaint();
    }

    function finishSelectionBox() {
        var left = Math.min(boxStartX, pointerX);
        var right = Math.max(boxStartX, pointerX);
        var top = Math.min(boxStartY, pointerY);
        var bottom = Math.max(boxStartY, pointerY);
        var selected = boxSelectionBase.slice();
        var nodes = activeNodes();
        for (var i = 0; i < nodes.length; ++i) {
            var node = nodes[i];
            var x = nodeSceneX(node.id, node.x, positionEpoch);
            var y = nodeSceneY(node.id, node.y, positionEpoch);
            var point = canvasPoint({
                    "x": x,
                    "y": y
                });
            var nodeRight = point.x + nodeWidth * zoom;
            var nodeBottom = point.y + nodeHeight * zoom;
            if (point.x <= right && nodeRight >= left && point.y <= bottom && nodeBottom >= top && selected.indexOf(String(node.id)) < 0)
                selected.push(String(node.id));
        }
        setSelection(selected);
    }

    function openContextMenu(id, px, py) {
        var model = studioObject();
        contextNodeId = String(id || "");
        if (contextNodeId && !isSelected(contextNodeId))
            setSelection([contextNodeId]);
        contextMenuX = Math.max(2, Math.min(graphSurface.width - 190, px));
        contextMenuY = Math.max(2, Math.min(graphSurface.height - 120, py));
        graphContextMenu.x = contextMenuX;
        graphContextMenu.y = contextMenuY;
        graphContextMenu.open();
    }

    function collapseSelection() {
        var model = studioObject();
        if (!model || !model.collapseSelection || !currentSelection().length)
            return;
        var id = model.collapseSelection("Subnet");
        if (id)
            setSelection([id]);
    }

    function enterSubnet(id) {
        var model = studioObject();
        if (model && model.enterSubnet)
            model.enterSubnet(String(id));
    }
    function deleteSelection() {
        var model = studioObject();
        var selected = currentSelection();
        if (model && model.deleteNodes && selected.length)
            return !!model.deleteNodes(selected);
        return false;
    }

    onPanelIdChanged: {
        if (restoredPanelId && restoredPanelId !== panelId)
            saveViewFor(lastGraphId || graphId(), restoredPanelId);
        pressSceneValid = false;
        toolMenuOpen = false;
        clearWireDrag();
        cancelReroute();
        gesture = "";
        graphContextMenu.close();
        addPopup.close();
        stateReady = false;
        Qt.callLater(function () {
                restoreView(graphId());
            });
    }

    onWidthChanged: {
        grid.requestPaint();
        if (!stateReady)
            Qt.callLater(function () {
                    restoreView(graphId());
                });
        else if (autoFrame)
            Qt.callLater(frameAll);
    }

    onHeightChanged: {
        grid.requestPaint();
        if (!stateReady)
            Qt.callLater(function () {
                    restoreView(graphId());
                });
        else if (autoFrame)
            Qt.callLater(frameAll);
    }

    onZoomChanged: {
        zoomTarget = zoom;
        wires.requestPaint();
    }
    Keys.onPressed: function (event) {
        if (event.key === Qt.Key_Shift) {
            updateModifierIndicator(event.modifiers | Qt.ShiftModifier);
            event.accepted = false;
        }
    }

    Keys.onReleased: function (event) {
        if (event.key === Qt.Key_Shift) {
            updateModifierIndicator(event.modifiers & ~Qt.ShiftModifier);
            event.accepted = false;
        }
    }

    Connections {
        target: studio
        function onActiveGraphIdChanged() {
            var next = graphPrototype.graphId();
            if (graphPrototype.lastGraphId && graphPrototype.lastGraphId !== next)
                graphPrototype.saveViewFor(graphPrototype.lastGraphId);
            graphPrototype.pressSceneValid = false;
            graphPrototype.toolMenuOpen = false;
            graphPrototype.clearWireDrag();
            addPopup.close();
            graphContextMenu.close();
            graphPrototype.cancelReroute();
            graphPrototype.gesture = "";
            graphPrototype.lastGraphId = next;
            Qt.callLater(function () {
                    graphPrototype.restoreView(next);
                });
        }
        function onNodesChanged() {
            graphPrototype.positionEpoch++;
            wires.requestPaint();
        }
        function onEdgesChanged() {
            wires.requestPaint();
        }
        function onNodesMoved() {
            graphPrototype.positionEpoch++;
            wires.requestPaint();
        }
        function onRevisionChanged() {
            graphPrototype.positionEpoch++;
            wires.requestPaint();
        }
        function onSelectedNodeIdChanged() {
            wires.requestPaint();
        }
        function onSelectedNodeIdsChanged() {
            wires.requestPaint();
        }
        function onBreadcrumbsChanged() {
        }
    }

    Component.onCompleted: Qt.callLater(function () {
            restoreView(graphId());
        })
    Component.onDestruction: saveViewFor(lastGraphId || graphId())

    Timer {
        id: zoomFrame
        interval: 0
        repeat: false
        onTriggered: graphPrototype.applyZoomTarget()
    }

    Shortcut {
        sequence: "Tab"
        context: Qt.WindowShortcut
        enabled: graphPrototype.activeFocus && !addPopup.opened && !graphPrototype.wireDragging && !graphPrototype.gesture.length && !graphPrototype.toolMenuOpen
        onActivated: graphPrototype.openSearch()
    }

    function cancelInteraction() {
        gesture = "";
        gestureMoved = false;
        dragIds = [];
        dragStartPositions = ({});
        disconnectedInsertId = "";
        cancelReroute();
        wireHoverEdge = null;
        pressSceneValid = false;
        clearWireDrag();
        positionEpoch++;
    }

    Shortcut {
        sequence: "Escape"
        context: Qt.WindowShortcut
        enabled: !addPopup.opened && !graphPrototype.toolMenuOpen && (graphPrototype.wireDragging || graphPrototype.gesture.length > 0)
        onActivated: graphPrototype.cancelInteraction()
    }

    Shortcut {
        sequence: "Delete"
        context: Qt.WindowShortcut
        enabled: graphPrototype.activeFocus && !addPopup.opened && !addSearch.activeFocus && !graphContextMenu.opened && !graphPrototype.toolMenuOpen && !graphPrototype.wireDragging && !graphPrototype.pipePullPending && !graphPrototype.gesture.length
        onActivated: graphPrototype.deleteSelection()
    }

    Shortcut {
        sequence: "1"
        context: Qt.WindowShortcut
        enabled: graphPrototype.activeFocus && !addPopup.opened && !graphPrototype.wireDragging && !graphPrototype.gesture.length && !graphPrototype.toolMenuOpen
        onActivated: {
            var model = graphPrototype.studioObject();
            var selected = graphPrototype.currentSelection();
            if (model && model.setViewer && selected.length)
                model.setViewer(graphPrototype.panelGroup, selected[0]);
        }
    }

    Component {
        id: headerToolsComponent
        RowLayout {
            spacing: 4
            Button {
                objectName: "graphFrameAll"
                text: "Frame all"
                implicitHeight: 24
                implicitWidth: 67
                padding: 5
                font.pixelSize: 11
                onClicked: graphPrototype.frameAll()
                background: Rectangle {
                    radius: 4
                    color: parent.down ? theme.hover : parent.hovered ? theme.raised : theme.panel
                    border.color: theme.border
                }
                contentItem: Text {
                    text: parent.text
                    color: theme.text
                    font: parent.font
                    horizontalAlignment: Text.AlignHCenter
                    verticalAlignment: Text.AlignVCenter
                }
            }
            Button {
                objectName: "graphToolsButton"
                text: "Tools"
                implicitHeight: 24
                implicitWidth: 49
                padding: 5
                font.pixelSize: 11
                onClicked: graphPrototype.toolsOpen = !graphPrototype.toolsOpen
                background: Rectangle {
                    radius: 4
                    color: parent.down ? theme.hover : parent.hovered ? theme.raised : theme.panel
                    border.color: graphPrototype.toolsOpen ? theme.accent : theme.border
                }
                contentItem: Text {
                    text: parent.text
                    color: theme.text
                    font: parent.font
                    horizontalAlignment: Text.AlignHCenter
                    verticalAlignment: Text.AlignVCenter
                }
            }
            Item {
                Layout.fillWidth: true
            }
            Text {
                objectName: "graphZoomLabel"
                text: Math.round(graphPrototype.zoom * 100) + "%"
                color: theme.muted
                font.pixelSize: 11
                verticalAlignment: Text.AlignVCenter
                Layout.preferredWidth: 38
                horizontalAlignment: Text.AlignRight
            }
        }
    }

    Rectangle {
        anchors.fill: parent
        color: theme.background
        objectName: "graphCanvas"

        Item {
            id: graphCanvas
            anchors.fill: parent
            anchors.topMargin: toolsBar.visible ? toolsBar.height : 0
            clip: true

            Rectangle {
                id: breadcrumbBar
                objectName: "graphBreadcrumbBar"
                anchors.top: parent.top
                anchors.left: parent.left
                anchors.right: parent.right
                height: 27
                color: Qt.rgba(theme.panel.r, theme.panel.g, theme.panel.b, 0.94)
                border.color: theme.border
                z: 30
                Row {
                    anchors.fill: parent
                    anchors.leftMargin: 6
                    spacing: 2
                    Repeater {
                        model: {
                            var model = graphPrototype.studioObject();
                            return model && model.breadcrumbs ? model.breadcrumbs : [];
                        }
                        delegate: Button {
                            objectName: "graphBreadcrumb_" + String(modelData.id)
                            text: (index > 0 ? "›  " : "") + (modelData.name || modelData.id)
                            flat: true
                            padding: 4
                            implicitHeight: 25
                            font.pixelSize: 11
                            onClicked: {
                                var model = graphPrototype.studioObject();
                                if (model && model.navigateGraph)
                                    model.navigateGraph(String(modelData.id));
                            }
                            background: Rectangle {
                                radius: 3
                                color: parent.hovered ? theme.hover : "transparent"
                            }
                            contentItem: Text {
                                text: parent.text
                                color: theme.text
                                font: parent.font
                                verticalAlignment: Text.AlignVCenter
                            }
                        }
                    }
                }
            }

            Item {
                id: graphSurface
                objectName: "graphCanvasViewport"
                anchors.fill: parent
                anchors.topMargin: breadcrumbBar.height
                clip: true

                Canvas {
                    id: grid
                    anchors.fill: parent
                    renderTarget: Canvas.FramebufferObject
                    onPaint: {
                        var ctx = getContext("2d");
                        ctx.clearRect(0, 0, width, height);
                        ctx.strokeStyle = Qt.rgba(theme.border.r, theme.border.g, theme.border.b, 0.24);
                        ctx.lineWidth = 1;
                        var spacing = 24;
                        var startX = ((sceneRoot.x % spacing) + spacing) % spacing;
                        var startY = ((sceneRoot.y % spacing) + spacing) % spacing;
                        ctx.beginPath();
                        for (var x = startX; x < width; x += spacing) {
                            ctx.moveTo(Math.round(x) + 0.5, 0);
                            ctx.lineTo(Math.round(x) + 0.5, height);
                        }
                        for (var y = startY; y < height; y += spacing) {
                            ctx.moveTo(0, Math.round(y) + 0.5);
                            ctx.lineTo(width, Math.round(y) + 0.5);
                        }
                        ctx.stroke();
                    }
                }

                Connections {
                    target: theme
                    function onBorderChanged() {
                        grid.requestPaint();
                        wires.requestPaint();
                    }
                    function onAccentChanged() {
                        wires.requestPaint();
                    }
                }

                Canvas {
                    id: wires
                    objectName: "graphWireSurface"
                    anchors.fill: parent
                    z: 1
                    renderTarget: Canvas.FramebufferObject
                    onPaint: {
                        var ctx = getContext("2d");
                        ctx.clearRect(0, 0, width, height);
                        var edges = graphPrototype.activeEdges();
                        for (var i = 0; i < edges.length; ++i) {
                            var edge = edges[i];
                            if (graphPrototype.wireDragging && graphPrototype.wireOldEdge && graphPrototype.sameEdge(edge, graphPrototype.wireOldEdge))
                                continue;
                            var geometry = graphPrototype.edgeCanvasGeometry(edge);
                            if (!geometry)
                                continue;
                            var active = graphPrototype.isSelected(edge.from) || graphPrototype.isSelected(edge.to);
                            var highlighted = (graphPrototype.wireHoverEdge && graphPrototype.sameEdge(edge, graphPrototype.wireHoverEdge)) || (graphPrototype.pipeHoverEdge && graphPrototype.sameEdge(edge, graphPrototype.pipeHoverEdge));
                            ctx.beginPath();
                            ctx.moveTo(geometry.points[0].x, geometry.points[0].y);
                            for (var pointIndex = 1; pointIndex < geometry.points.length; ++pointIndex)
                                ctx.lineTo(geometry.points[pointIndex].x, geometry.points[pointIndex].y);
                            ctx.strokeStyle = highlighted || active ? theme.accent : theme.muted;
                            ctx.globalAlpha = highlighted || active ? 0.95 : 0.7;
                            ctx.lineWidth = highlighted ? 4.0 : active ? 2.0 : 1.35;
                            ctx.stroke();
                            ctx.globalAlpha = 1.0;
                            for (var dotIndex = 1; dotIndex + 1 < geometry.points.length; ++dotIndex) {
                                var dot = geometry.points[dotIndex];
                                ctx.beginPath();
                                ctx.arc(dot.x, dot.y, graphPrototype.rerouteDragging && graphPrototype.rerouteEdge && graphPrototype.sameEdge(edge, graphPrototype.rerouteEdge) && graphPrototype.rerouteIndex === dotIndex - 1 ? 6 : 4, 0, Math.PI * 2);
                                ctx.fillStyle = theme.accent;
                                ctx.globalAlpha = 0.95;
                                ctx.fill();
                            }
                            ctx.globalAlpha = 1.0;
                        }
                        if (!graphPrototype.wireDragging && graphPrototype.pipeHoverEdge) {
                            var hoverGeometry = graphPrototype.edgeCanvasGeometry(graphPrototype.pipeHoverEdge);
                            if (hoverGeometry) {
                                var hoverPoint = graphPrototype.pipeHoverOutput ? hoverGeometry.points[0] : hoverGeometry.points[hoverGeometry.points.length - 1];
                                ctx.beginPath();
                                ctx.arc(hoverPoint.x, hoverPoint.y, 7, 0, Math.PI * 2);
                                ctx.strokeStyle = theme.accent;
                                ctx.globalAlpha = 0.95;
                                ctx.lineWidth = 2;
                                ctx.stroke();
                                ctx.globalAlpha = 1.0;
                            }
                        }
                        if (graphPrototype.wireDragging) {
                            var startPoint;
                            var startPort;
                            if (graphPrototype.wireFromInput) {
                                var targetNode = graphPrototype.nodeById(graphPrototype.wireToId);
                                startPort = targetNode ? graphPrototype.findPort(targetNode, false, graphPrototype.wireInput) : null;
                                startPoint = targetNode && startPort ? graphPrototype.canvasPoint(graphPrototype.portScenePoint(targetNode, startPort, false, 0)) : {
                                    "x": graphPrototype.pointerX,
                                    "y": graphPrototype.pointerY
                                };
                            } else {
                                var sourceNode = graphPrototype.nodeById(graphPrototype.wireFromId);
                                startPort = sourceNode ? graphPrototype.findPort(sourceNode, true, graphPrototype.wireOutput) : null;
                                startPoint = sourceNode && startPort ? graphPrototype.canvasPoint(graphPrototype.portScenePoint(sourceNode, startPort, true, 0)) : {
                                    "x": graphPrototype.pointerX,
                                    "y": graphPrototype.pointerY
                                };
                            }
                            var endPoint = graphPrototype.wireHoverPort || {
                                "x": graphPrototype.pointerX,
                                "y": graphPrototype.pointerY
                            };
                            ctx.beginPath();
                            ctx.moveTo(startPoint.x, startPoint.y);
                            ctx.lineTo(endPoint.x, endPoint.y);
                            ctx.strokeStyle = theme.accent;
                            ctx.globalAlpha = 0.9;
                            ctx.lineWidth = 2.2;
                            ctx.stroke();
                            ctx.globalAlpha = 1.0;
                        }
                    }
                }

                Item {
                    id: sceneRoot
                    z: 2
                    width: graphPrototype.sceneWidth
                    height: graphPrototype.sceneHeight
                    scale: graphPrototype.zoom
                    transformOrigin: Item.TopLeft

                    Repeater {
                        id: graphNodes
                        model: graphPrototype.activeNodes()
                        delegate: Rectangle {
                            id: nodeItem
                            objectName: "graphNode_" + String(modelData.id)
                            property var nodeData: modelData
                            width: graphPrototype.nodeWidth
                            height: graphPrototype.nodeHeight
                            radius: 3
                            x: graphPrototype.nodeSceneX(nodeData.id, nodeData.x, graphPrototype.positionEpoch)
                            y: graphPrototype.nodeSceneY(nodeData.id, nodeData.y, graphPrototype.positionEpoch)
                            color: graphPrototype.nodeCategoryFill(nodeData)
                            border.color: graphPrototype.isSelected(nodeData.id) ? theme.accent : theme.border
                            border.width: graphPrototype.isSelected(nodeData.id) ? 2 : 1

                            Text {
                                anchors.left: parent.left
                                anchors.leftMargin: 7
                                anchors.right: parent.right
                                anchors.rightMargin: nodeData.type === "Subnet" ? 27 : 9
                                anchors.verticalCenter: parent.verticalCenter
                                text: graphPrototype.nodeLabel(nodeData)
                                color: graphPrototype.nodeCategoryText(nodeData)
                                font.pixelSize: theme.fontSize
                                font.weight: Font.Medium
                                horizontalAlignment: Text.AlignHCenter
                                elide: Text.ElideRight
                            }

                            Rectangle {
                                objectName: "graphEnter_" + String(nodeData.id)
                                visible: nodeData.type === "Subnet"
                                x: parent.width - width - 4
                                y: 4
                                width: 20
                                height: 20
                                radius: 3
                                color: theme.raised
                                border.color: theme.border
                                Text {
                                    anchors.centerIn: parent
                                    text: ">"
                                    color: theme.text
                                    font.pixelSize: 13
                                    font.bold: true
                                }
                            }

                            Repeater {
                                model: graphPrototype.inputPorts(nodeItem.nodeData.id)
                                delegate: Rectangle {
                                    id: inputPortVisual
                                    property var portData: modelData
                                    property int fallbackPortIndex: index
                                    objectName: "graphInput_" + String(nodeItem.nodeData.id) + "_" + String(graphPrototype.portId(portData, index))
                                    width: graphPrototype.portGlyphSize
                                    height: graphPrototype.portGlyphSize
                                    radius: width / 2
                                    property var localPort: graphPrototype.portLocalPoint(nodeItem.nodeData, portData, false, index)
                                    x: localPort.x - width / 2
                                    y: localPort.y - height / 2
                                    z: 5
                                    color: graphPrototype.samePort(graphPrototype.wireHoverPort, {
                                            "nodeId": nodeItem.nodeData.id,
                                            "portId": graphPrototype.portId(portData, index),
                                            "output": false
                                        }) ? theme.accent : (portData.type === "mask" ? theme.panel : theme.muted)
                                    border.color: portData.type === "mask" ? theme.muted : theme.node
                                    border.width: 1
                                }
                            }

                            Repeater {
                                model: graphPrototype.outputPorts(nodeItem.nodeData.id)
                                delegate: Rectangle {
                                    id: outputPortVisual
                                    property var portData: modelData
                                    property int fallbackPortIndex: index
                                    objectName: "graphOutput_" + String(nodeItem.nodeData.id) + "_" + String(graphPrototype.portId(portData, index))
                                    width: graphPrototype.portGlyphSize
                                    height: graphPrototype.portGlyphSize
                                    radius: width / 2
                                    property var localPort: graphPrototype.portLocalPoint(nodeItem.nodeData, portData, true, index)
                                    x: localPort.x - width / 2
                                    y: localPort.y - height / 2
                                    z: 5
                                    color: graphPrototype.samePort(graphPrototype.wireHoverPort, {
                                            "nodeId": nodeItem.nodeData.id,
                                            "portId": graphPrototype.portId(portData, index),
                                            "output": true
                                        }) ? theme.accent : (portData.type === "mask" ? theme.raised : graphPrototype.nodeCategoryFill(nodeData))
                                    border.color: theme.node
                                    border.width: 1
                                }
                            }
                        }
                    }
                }

                Rectangle {
                    id: selectionBox
                    objectName: "graphSelectionBox"
                    visible: graphPrototype.gesture === "box"
                    x: Math.min(graphPrototype.boxStartX, graphPrototype.pointerX)
                    y: Math.min(graphPrototype.boxStartY, graphPrototype.pointerY)
                    width: Math.abs(graphPrototype.pointerX - graphPrototype.boxStartX)
                    height: Math.abs(graphPrototype.pointerY - graphPrototype.boxStartY)
                    color: Qt.rgba(theme.accent.r, theme.accent.g, theme.accent.b, 0.12)
                    border.color: theme.accent
                    border.width: 1
                    z: 15
                }

                MouseArea {
                    id: canvasMouse
                    objectName: "graphCanvasSurface"
                    anchors.fill: parent
                    z: 20
                    acceptedButtons: Qt.LeftButton | Qt.MiddleButton | Qt.RightButton
                    hoverEnabled: true
                    preventStealing: true
                    ToolTip.visible: containsMouse && graphPrototype.pipeHoverEdge && !graphPrototype.wireDragging
                    ToolTip.delay: 600
                    ToolTip.text: graphPrototype.pipeHoverOutput ? "Drag source end; Shift-drag destination end" : "Drag destination end; release empty to disconnect"
                    onExited: function () {
                        if (!graphPrototype.wireDragging && !graphPrototype.pipePullPending) {
                            graphPrototype.pipeHoverEdge = null;
                            graphPrototype.wireHoverEdge = null;
                            graphPrototype.wireHoverPort = null;
                            wires.requestPaint();
                        }
                    }

                    onPressed: function (mouse) {
                        graphPrototype.updateModifierIndicator(mouse.modifiers);
                        graphPrototype.updatePointer(mouse.x, mouse.y);
                        graphPrototype.forceActiveFocus();
                        graphPrototype.lastClickMoved = false;
                        graphPrototype.gestureMoved = false;
                        if (mouse.button === Qt.RightButton) {
                            if (graphPrototype.gesture.length || graphPrototype.wireDragging)
                                graphPrototype.cancelInteraction();
                            else {
                                var rightNode = graphPrototype.nodeAt(mouse.x, mouse.y);
                                graphPrototype.openContextMenu(rightNode, mouse.x, mouse.y);
                            }
                            mouse.accepted = true;
                            return;
                        }
                        if (mouse.button === Qt.MiddleButton) {
                            graphPrototype.autoFrame = false;
                            graphPrototype.gesture = "pan";
                            graphPrototype.gesturePressX = mouse.x;
                            graphPrototype.gesturePressY = mouse.y;
                            graphPrototype.panOriginX = sceneRoot.x;
                            graphPrototype.panOriginY = sceneRoot.y;
                            mouse.accepted = true;
                            return;
                        }
                        if (mouse.button !== Qt.LeftButton) {
                            mouse.accepted = true;
                            return;
                        }
                        var pressedScene = graphPrototype.sceneCoordinate(mouse.x, mouse.y);
                        graphPrototype.pressSceneX = pressedScene.x;
                        graphPrototype.pressSceneY = pressedScene.y;
                        graphPrototype.pressSceneValid = true;
                        var enterNode = graphPrototype.enterAt(mouse.x, mouse.y);
                        if (enterNode) {
                            graphPrototype.contextNodeId = enterNode;
                            graphPrototype.gesture = "enter";
                            mouse.accepted = true;
                            return;
                        }
                        var port = graphPrototype.anyPortAt(mouse.x, mouse.y);
                        var endpoint = port ? null : graphPrototype.wireEndpointAt(mouse.x, mouse.y);
                        graphPrototype.gesturePressX = mouse.x;
                        graphPrototype.gesturePressY = mouse.y;
                        if (port) {
                            if (!graphPrototype.isSelected(port.nodeId))
                                graphPrototype.setSelection([port.nodeId]);
                            if (port.output)
                                graphPrototype.beginOutputWire(port.nodeId, port.portId);
                            else
                                graphPrototype.beginInputWire(port.nodeId, port.portId);
                            graphPrototype.gesture = "wire";
                        } else if (endpoint) {
                            if (endpoint.output) {
                                graphPrototype.beginOutputWire(endpoint.edge.from, endpoint.edge.output);
                            } else {
                                graphPrototype.beginInputWire(endpoint.edge.to, endpoint.edge.input);
                            }
                            graphPrototype.gesture = "wire";
                        } else {
                            var nodeId = graphPrototype.nodeAt(mouse.x, mouse.y);
                            var shift = (mouse.modifiers & Qt.ShiftModifier) !== 0;
                            var alt = (mouse.modifiers & Qt.AltModifier) !== 0;
                            graphPrototype.gesturePressX = mouse.x;
                            graphPrototype.gesturePressY = mouse.y;
                            var pipeEdge = graphPrototype.wireAt(mouse.x, mouse.y);
                            if (nodeId) {
                                if (shift) {
                                    graphPrototype.toggleSelection(nodeId);
                                    graphPrototype.gesture = "toggle";
                                } else {
                                    if (!graphPrototype.isSelected(nodeId))
                                        graphPrototype.setSelection([nodeId]);
                                    graphPrototype.beginNodeDrag(nodeId);
                                }
                            } else {
                                var dot = graphPrototype.rerouteDotAt(mouse.x, mouse.y);
                                if (dot) {
                                    graphPrototype.beginReroute(dot.edge, dot.index, alt);
                                } else if (alt && graphPrototype.beginRerouteOnSegment(mouse.x, mouse.y))
                                // Alt-click inserts a point at the nearest segment projection.
                                {
                                } else if (pipeEdge) {
                                    graphPrototype.beginPipePullPress(pipeEdge, !shift);
                                    graphPrototype.gesture = "pipe";
                                } else if (shift) {
                                    graphPrototype.gesture = "box";
                                    graphPrototype.boxStartX = mouse.x;
                                    graphPrototype.boxStartY = mouse.y;
                                    graphPrototype.boxSelectionBase = graphPrototype.currentSelection();
                                } else {
                                    graphPrototype.gesture = "pan";
                                    graphPrototype.autoFrame = false;
                                    graphPrototype.panOriginX = sceneRoot.x;
                                    graphPrototype.panOriginY = sceneRoot.y;
                                }
                            }
                        }
                        mouse.accepted = true;
                    }

                    onPositionChanged: function (mouse) {
                        graphPrototype.updateModifierIndicator(mouse.modifiers);
                        graphPrototype.updatePointer(mouse.x, mouse.y);
                        var dx = mouse.x - graphPrototype.gesturePressX;
                        var dy = mouse.y - graphPrototype.gesturePressY;
                        if (Math.hypot(dx, dy) > 3)
                            graphPrototype.gestureMoved = true;
                        if (graphPrototype.gesture === "pipe" && graphPrototype.pipePullPending && (mouse.buttons & Qt.LeftButton) && Math.hypot(dx, dy) > 3)
                            graphPrototype.beginPipePull();
                        if (graphPrototype.gesture === "nodes" && (mouse.buttons & Qt.LeftButton))
                            graphPrototype.updateNodeDrag(mouse.x, mouse.y);
                        else if (graphPrototype.gesture === "reroute" && (mouse.buttons & Qt.LeftButton))
                            graphPrototype.updateReroutePreview(mouse.x, mouse.y);
                        else if (graphPrototype.gesture === "box" && (mouse.buttons & Qt.LeftButton))
                            wires.requestPaint();
                        else if (graphPrototype.gesture === "pan" && (mouse.buttons & (Qt.LeftButton | Qt.MiddleButton))) {
                            sceneRoot.x = graphPrototype.panOriginX + mouse.x - graphPrototype.gesturePressX;
                            sceneRoot.y = graphPrototype.panOriginY + mouse.y - graphPrototype.gesturePressY;
                            grid.requestPaint();
                            wires.requestPaint();
                        }
                    }

                    onReleased: function (mouse) {
                        graphPrototype.updateModifierIndicator(mouse.modifiers);
                        graphPrototype.updatePointer(mouse.x, mouse.y);
                        graphPrototype.lastClickMoved = graphPrototype.gestureMoved;
                        var rememberClick = mouse.button === Qt.LeftButton && graphPrototype.pressSceneValid && (graphPrototype.gesture !== "pan" || !graphPrototype.gestureMoved);
                        if (rememberClick) {
                            graphPrototype.lastClickSceneX = graphPrototype.pressSceneX;
                            graphPrototype.lastClickSceneY = graphPrototype.pressSceneY;
                            graphPrototype.lastClickValid = true;
                            graphPrototype.persistView();
                        }
                        if (mouse.button === Qt.LeftButton) {
                            if (graphPrototype.gesture === "enter" && graphPrototype.enterAt(mouse.x, mouse.y) === graphPrototype.contextNodeId)
                                graphPrototype.enterSubnet(graphPrototype.contextNodeId);
                            else if (graphPrototype.gesture === "pipe" && graphPrototype.pipePullPending)
                                graphPrototype.clearWireDrag();
                            else if (graphPrototype.gesture === "wire")
                                graphPrototype.releaseWireAt();
                            else if (graphPrototype.gesture === "reroute")
                                graphPrototype.finishReroute();
                            else if (graphPrototype.gesture === "nodes")
                                graphPrototype.finishNodeDrag();
                            else if (graphPrototype.gesture === "box" && graphPrototype.gestureMoved)
                                graphPrototype.finishSelectionBox();
                            else if (graphPrototype.gesture === "pan") {
                                if (!graphPrototype.gestureMoved)
                                    graphPrototype.setSelection([]);
                                graphPrototype.persistView();
                            }
                        } else if (mouse.button === Qt.MiddleButton && graphPrototype.gesture === "pan") {
                            graphPrototype.persistView();
                        }
                        graphPrototype.pressSceneValid = false;
                        graphPrototype.gesture = "";
                        graphPrototype.gestureMoved = false;
                    }

                    onCanceled: graphPrototype.cancelInteraction()

                    onDoubleClicked: function (mouse) {
                        if (mouse.button !== Qt.LeftButton || graphPrototype.lastClickMoved)
                            return;
                        var id = graphPrototype.nodeAt(mouse.x, mouse.y);
                        if (!id)
                            return;
                        var entered = graphPrototype.enterAt(mouse.x, mouse.y);
                        if (entered)
                            graphPrototype.enterSubnet(entered);
                        else {
                            var model = graphPrototype.studioObject();
                            if (model && model.openNodeParameters)
                                model.openNodeParameters(id);
                        }
                    }

                    onWheel: function (wheel) {
                        if (graphPrototype.wireDragging) {
                            wheel.accepted = true;
                            return;
                        }
                        var delta = wheel.pixelDelta && wheel.pixelDelta.y ? wheel.pixelDelta.y : (wheel.angleDelta.y / 120) * 53;
                        if (delta)
                            graphPrototype.queueZoom(Math.exp(delta * 0.002), wheel.x, wheel.y);
                        wheel.accepted = true;
                    }
                }
            }

            Rectangle {
                id: toolsBar
                objectName: "graphToolsBar"
                anchors.top: parent.top
                anchors.left: parent.left
                anchors.right: parent.right
                height: categoryFlow.implicitHeight + 8
                visible: graphPrototype.toolsOpen
                z: 40
                color: Qt.rgba(theme.panel.r, theme.panel.g, theme.panel.b, 0.97)
                border.color: theme.border
                Flow {
                    id: categoryFlow
                    anchors.fill: parent
                    anchors.topMargin: 4
                    anchors.bottomMargin: 4
                    anchors.leftMargin: 6
                    anchors.rightMargin: 6
                    spacing: 3
                    Repeater {
                        model: {
                            var model = graphPrototype.studioObject();
                            return model && model.nodeCategories ? model.nodeCategories : [];
                        }
                        delegate: Button {
                            id: categoryButton
                            property var categoryData: modelData
                            objectName: "toolCategory_" + categoryData.id
                            onClicked: {
                                graphPrototype.captureCreationContext();
                                categoryMenu.open();
                            }
                            implicitHeight: 23
                            implicitWidth: Math.max(48, categoryData.label.length * 7 + 18)
                            padding: 4
                            font.pixelSize: 11
                            background: Rectangle {
                                radius: 4
                                color: parent.down ? theme.hover : parent.hovered ? theme.raised : theme.panel
                                border.color: parent.hovered ? theme.accent : theme.border
                            }
                            contentItem: Text {
                                text: parent.text
                                color: theme.text
                                font: parent.font
                                horizontalAlignment: Text.AlignHCenter
                                verticalAlignment: Text.AlignVCenter
                            }
                            Menu {
                                id: categoryMenu
                                onOpened: graphPrototype.toolMenuOpen = true
                                onClosed: graphPrototype.toolMenuOpen = false
                                y: categoryButton.height
                                Repeater {
                                    model: categoryButton.categoryData.types
                                    delegate: MenuItem {
                                        objectName: "toolNode_" + modelData
                                        text: modelData
                                        onTriggered: {
                                            categoryMenu.close();
                                            graphPrototype.createNodeFromContext(text);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        Text {
            id: graphErrorLabel
            objectName: "graphErrorLabel"
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.bottom: parent.bottom
            anchors.margins: 8
            visible: graphPrototype.graphError.length > 0
            text: graphPrototype.graphError
            color: theme.accent
            font.pixelSize: 11
            elide: Text.ElideRight
            z: 50
        }
    }

    Menu {
        id: graphContextMenu
        objectName: "graphNodeContextMenu"
        MenuItem {
            objectName: "graphCollapseSelection"
            text: "Collapse to subnetwork"
            enabled: graphPrototype.currentSelection().length > 0
            onTriggered: graphPrototype.collapseSelection()
        }
        MenuItem {
            objectName: "graphEnterSelection"
            text: "Enter subnet"
            enabled: !!graphPrototype.nodeById(graphPrototype.contextNodeId) && graphPrototype.nodeById(graphPrototype.contextNodeId).type === "Subnet"
            onTriggered: graphPrototype.enterSubnet(graphPrototype.contextNodeId)
        }
        MenuSeparator {
        }
        MenuItem {
            objectName: "graphDeleteSelection"
            text: "Delete"
            enabled: graphPrototype.currentSelection().length > 0
            onTriggered: graphPrototype.deleteSelection()
        }
        MenuItem {
            objectName: "graphSetViewerSelection"
            text: "Set as Viewer"
            enabled: graphPrototype.currentSelection().length === 1
            onTriggered: {
                var model = graphPrototype.studioObject();
                if (model && model.setViewer)
                    model.setViewer(graphPrototype.panelGroup, graphPrototype.currentSelection()[0]);
            }
        }
    }

    Popup {
        id: addPopup
        objectName: "graphSearchPopup"
        parent: Overlay.overlay
        width: 190
        height: 214
        modal: false
        padding: 6
        x: graphPrototype.popupX()
        y: graphPrototype.popupY()
        closePolicy: Popup.NoAutoClose
        background: Rectangle {
            radius: theme.radius
            color: theme.panel
            border.color: theme.border
        }

        ColumnLayout {
            anchors.fill: parent
            spacing: 5
            TextField {
                id: addSearch
                objectName: "graphSearchField"
                Layout.fillWidth: true
                implicitHeight: 28
                placeholderText: "Search nodes"
                color: theme.text
                placeholderTextColor: theme.muted
                background: Rectangle {
                    radius: theme.smallRadius
                    color: theme.field
                    border.color: addSearch.activeFocus ? theme.accent : theme.border
                }
                onTextChanged: addList.currentIndex = 0
                Keys.onDownPressed: function (event) {
                    addList.incrementCurrentIndex();
                    event.accepted = true;
                }
                Keys.onUpPressed: function (event) {
                    addList.decrementCurrentIndex();
                    event.accepted = true;
                }
                Keys.onEscapePressed: function (event) {
                    event.accepted = true;
                    graphPrototype.closeSearch();
                }
                onAccepted: {
                    if (addList.currentItem) {
                        graphPrototype.createNodeFromContext(addList.currentItem.text);
                        graphPrototype.closeSearch();
                    }
                }
            }
            ListView {
                id: addList
                Layout.fillWidth: true
                Layout.fillHeight: true
                clip: true
                currentIndex: 0
                model: graphPrototype.filteredTypes()
                delegate: ItemDelegate {
                    width: addList.width
                    height: 29
                    text: modelData
                    highlighted: ListView.isCurrentItem
                    onClicked: {
                        graphPrototype.createNodeFromContext(modelData);
                        graphPrototype.closeSearch();
                    }
                    contentItem: Text {
                        text: parent.text
                        color: theme.text
                        font.pixelSize: theme.fontSize
                        verticalAlignment: Text.AlignVCenter
                    }
                    background: Rectangle {
                        radius: theme.smallRadius
                        color: parent.hovered || parent.highlighted ? theme.hover : "transparent"
                    }
                }
            }
        }
    }
}
